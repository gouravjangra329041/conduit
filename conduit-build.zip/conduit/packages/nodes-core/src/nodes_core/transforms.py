"""Data-shaping nodes."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from conduit.domain.nodes import NodeCategory, NodeDefinition, RetryPolicy


class FieldAssignment(BaseModel):
    name: str = Field(title="Field", max_length=200)
    value: str = Field(
        default="",
        title="Value",
        description="Text, or an expression such as {{ $trigger.body.email }}",
        max_length=10_000,
    )
    type: Literal["string", "number", "boolean", "json"] = Field(
        default="string", title="Type"
    )


class SetFieldsConfig(BaseModel):
    fields: list[FieldAssignment] = Field(
        default_factory=list, title="Fields", max_length=100
    )
    keep_existing: bool = Field(
        default=True,
        title="Keep other fields",
        description="Pass through incoming data alongside the fields you set.",
    )


class SetFields(NodeDefinition):
    """Field-level editing with inline expressions.

    Distinct from JSON Transform on purpose: this is the discoverable,
    row-per-field tool that most people reach for, while JSON Transform handles
    structural reshaping. See ADR-001.
    """

    type = "set_fields"
    version = 1
    category = NodeCategory.TRANSFORM
    display_name = "Edit Fields"
    description = "Set, rename, or remove fields on the data passing through."
    icon = "pencil"
    config_schema = SetFieldsConfig
    default_retry_policy = RetryPolicy(max_attempts=1)


class JsonTransformConfig(BaseModel):
    expression: str = Field(
        default="@",
        title="JMESPath expression",
        description=(
            "Reshape the whole payload. For example: "
            "items[].{id: id, name: customer.name}"
        ),
        max_length=10_000,
    )


class JsonTransform(NodeDefinition):
    type = "json_transform"
    version = 1
    category = NodeCategory.TRANSFORM
    display_name = "Transform JSON"
    description = "Reshape data structurally using a JMESPath expression."
    icon = "braces"
    config_schema = JsonTransformConfig
    default_retry_policy = RetryPolicy(max_attempts=1)
