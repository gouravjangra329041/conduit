"""Trigger nodes — the entry points of a workflow."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from conduit.domain.nodes import NodeCategory, NodeDefinition, Port


class ManualTriggerConfig(BaseModel):
    """Starting a run by hand, from the editor or the API."""

    model_config = {"json_schema_extra": {"x-ui-order": ["note"]}}

    note: str | None = Field(
        default=None,
        max_length=500,
        title="Note",
        description="Optional reminder about when this workflow should be run.",
    )


class ManualTrigger(NodeDefinition):
    type = "manual_trigger"
    version = 1
    category = NodeCategory.TRIGGER
    display_name = "Manual"
    description = "Start this workflow yourself, on demand."
    icon = "play"
    config_schema = ManualTriggerConfig
    input_ports = ()
    output_ports = (Port(name="out", label="Out"),)


class WebhookTriggerConfig(BaseModel):
    method: Literal["POST", "GET", "PUT", "PATCH", "DELETE", "ANY"] = Field(
        default="POST",
        title="Method",
        description="Which HTTP method this URL accepts.",
    )
    verify_signature: bool = Field(
        default=False,
        title="Verify signature",
        description=(
            "Require an HMAC signature header. Strongly recommended for any "
            "URL you share outside your own systems."
        ),
    )
    signature_header: str = Field(
        default="X-Signature",
        max_length=100,
        title="Signature header",
    )
    max_body_bytes: int = Field(
        default=1_048_576,
        ge=1024,
        le=16_777_216,
        title="Maximum body size",
        description="Requests larger than this are rejected before parsing.",
    )


class WebhookTrigger(NodeDefinition):
    type = "webhook_trigger"
    version = 1
    category = NodeCategory.TRIGGER
    display_name = "Webhook"
    description = "Start this workflow when another system calls a URL."
    icon = "webhook"
    config_schema = WebhookTriggerConfig
    input_ports = ()
    output_ports = (Port(name="out", label="Out"),)
