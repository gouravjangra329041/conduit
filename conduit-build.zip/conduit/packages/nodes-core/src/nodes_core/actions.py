"""Action nodes — the ones that touch the outside world."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from conduit.domain.nodes import NodeCategory, NodeDefinition, RetryPolicy


class HeaderPair(BaseModel):
    name: str = Field(title="Header", max_length=200)
    value: str = Field(default="", title="Value", max_length=8000)


class HttpRequestConfig(BaseModel):
    method: Literal["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"] = Field(
        default="GET", title="Method"
    )
    url: str = Field(
        default="",
        title="URL",
        description="Supports expressions, e.g. https://api.example.com/users/{{ $trigger.body.id }}",
        max_length=4000,
    )
    headers: list[HeaderPair] = Field(
        default_factory=list, title="Headers", max_length=50
    )
    query: list[HeaderPair] = Field(
        default_factory=list, title="Query parameters", max_length=50
    )
    body_type: Literal["none", "json", "form", "raw"] = Field(
        default="none", title="Body type"
    )
    body: str = Field(default="", title="Body", max_length=100_000)
    timeout_s: float = Field(default=30.0, ge=1, le=300, title="Timeout (seconds)")
    follow_redirects: bool = Field(default=True, title="Follow redirects")


class HttpRequest(NodeDefinition):
    """Calls an external HTTP endpoint.

    Every request goes through the egress guard. An HTTP node is
    user-controlled server-side request forgery by design: without DNS-then-IP
    validation, re-checked after each redirect, any tenant can reach the cloud
    metadata endpoint or internal services. See ARCHITECTURE.md §11.2.
    """

    type = "http_request"
    version = 1
    category = NodeCategory.ACTION
    display_name = "HTTP Request"
    description = "Call an API or website and use what comes back."
    icon = "globe"
    config_schema = HttpRequestConfig
    credential_type = "http_auth"
    default_timeout_s = 30.0
    default_retry_policy = RetryPolicy(max_attempts=3, initial_delay_s=1.0)


class AiPromptConfig(BaseModel):
    provider: Literal["anthropic", "openai"] = Field(
        default="anthropic", title="Provider"
    )
    model: str = Field(default="claude-sonnet-4-6", title="Model", max_length=100)
    system_prompt: str = Field(
        default="",
        title="System instructions",
        description="Sets the assistant's role and rules.",
        max_length=50_000,
    )
    prompt: str = Field(
        default="",
        title="Prompt",
        description="Supports expressions, e.g. Summarise: {{ $node[\"n_1\"].output.body }}",
        max_length=100_000,
    )
    max_output_tokens: int = Field(default=1024, ge=1, le=32_000, title="Maximum length")
    temperature: float = Field(default=1.0, ge=0.0, le=2.0, title="Temperature")
    response_format: Literal["text", "json"] = Field(
        default="text",
        title="Response format",
        description=(
            "Structured JSON is safer for branching: it keeps model output as "
            "data rather than as instructions."
        ),
    )


class AiPrompt(NodeDefinition):
    """Sends a prompt to a language model.

    Two constraints the engine enforces around this node. Cost is metered per
    organization, because an unbounded loop through a paid API is a real denial
    of service. And model output must never directly decide control flow or
    credential use without a deterministic node in between — data flowing in
    from an HTTP node can contain instructions, and prompt injection is not a
    solved problem.
    """

    type = "ai_prompt"
    version = 1
    category = NodeCategory.ACTION
    display_name = "AI Prompt"
    description = "Ask a language model to write, classify, or extract something."
    icon = "sparkles"
    config_schema = AiPromptConfig
    credential_type = "llm_api_key"
    default_timeout_s = 120.0
    default_retry_policy = RetryPolicy(max_attempts=2, initial_delay_s=2.0)


class EmailConfig(BaseModel):
    to: str = Field(
        default="",
        title="To",
        description="Comma-separated addresses. Supports expressions.",
        max_length=2000,
    )
    cc: str = Field(default="", title="Cc", max_length=2000)
    subject: str = Field(default="", title="Subject", max_length=500)
    body: str = Field(default="", title="Message", max_length=200_000)
    body_format: Literal["text", "html"] = Field(default="text", title="Format")
    reply_to: str = Field(default="", title="Reply to", max_length=320)


class Email(NodeDefinition):
    """Sends an email.

    Not idempotent at the provider level, so the engine forwards a
    deterministic idempotency key as the message identifier. With at-least-once
    delivery a worker can crash after sending and before recording success;
    the key is what stops that becoming a duplicate.
    """

    type = "email"
    version = 1
    category = NodeCategory.ACTION
    display_name = "Send Email"
    description = "Send an email to one or more people."
    icon = "mail"
    config_schema = EmailConfig
    credential_type = "smtp"
    default_timeout_s = 30.0
    default_retry_policy = RetryPolicy(max_attempts=3, initial_delay_s=2.0)
