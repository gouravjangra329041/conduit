"""First-party node pack.

Depends on nothing but the node contract. If this package could import
`conduit.infrastructure`, the plugin boundary would be decorative — which is
why an import-linter contract fails the build if it ever does.

Configuration schemas are complete and drive the editor's forms today.
Execution logic arrives in Modules 8–10; until then `execute` raises
NotImplementedError rather than pretending to work.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .actions import AiPrompt, Email, HttpRequest
from .logic import Delay, IfElse
from .transforms import JsonTransform, SetFields
from .triggers import ManualTrigger, WebhookTrigger

__version__ = "0.1.0"

if TYPE_CHECKING:
    from conduit.domain.nodes import NodeRegistry

# Nine node types (ADR-003). `End` was dropped: a node with no outgoing edges
# is already terminal, and run outcome lives on the run's status.
NODES = (
    ManualTrigger,
    WebhookTrigger,
    IfElse,
    Delay,
    SetFields,
    JsonTransform,
    HttpRequest,
    AiPrompt,
    Email,
)


def register(registry: NodeRegistry) -> None:
    """Entry point called once at process start."""
    for node in NODES:
        registry.add(node)


def describe() -> dict[str, Any]:
    return {"pack": "core", "version": __version__, "node_count": len(NODES)}


__all__ = [
    "NODES",
    "AiPrompt",
    "Delay",
    "Email",
    "HttpRequest",
    "IfElse",
    "JsonTransform",
    "ManualTrigger",
    "SetFields",
    "WebhookTrigger",
    "describe",
    "register",
]
