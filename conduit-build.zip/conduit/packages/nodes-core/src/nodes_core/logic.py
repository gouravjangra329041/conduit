"""Branching and timing nodes."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

from conduit.domain.nodes import NodeCategory, NodeDefinition, Port, RetryPolicy


class Condition(BaseModel):
    left: str = Field(
        title="Value",
        description="Usually an expression, e.g. {{ $trigger.body.total }}",
        max_length=2000,
    )
    operator: Literal[
        "equals",
        "not_equals",
        "greater_than",
        "greater_or_equal",
        "less_than",
        "less_or_equal",
        "contains",
        "not_contains",
        "starts_with",
        "ends_with",
        "is_empty",
        "is_not_empty",
        "is_true",
        "is_false",
    ] = Field(default="equals", title="Condition")
    right: str = Field(default="", title="Compare with", max_length=2000)


class IfElseConfig(BaseModel):
    conditions: list[Condition] = Field(
        default_factory=list, title="Conditions", max_length=20
    )
    combinator: Literal["all", "any"] = Field(
        default="all",
        title="Match",
        description="Whether every condition must hold, or just one.",
    )


class IfElse(NodeDefinition):
    type = "if_else"
    version = 1
    category = NodeCategory.LOGIC
    display_name = "If / Else"
    description = "Send the run down one of two paths."
    icon = "git-branch"
    config_schema = IfElseConfig
    output_ports = (
        Port(name="true", label="True", description="Taken when the conditions match."),
        Port(name="false", label="False", description="Taken when they do not."),
    )


class DelayConfig(BaseModel):
    mode: Literal["duration", "until"] = Field(default="duration", title="Wait")
    amount: int = Field(default=5, ge=0, le=1_000_000, title="Amount")
    unit: Literal["seconds", "minutes", "hours", "days"] = Field(
        default="minutes", title="Unit"
    )
    until: str | None = Field(
        default=None,
        title="Until",
        description="An ISO timestamp or expression, when waiting to a fixed time.",
        max_length=200,
    )


class Delay(NodeDefinition):
    type = "delay"
    version = 1
    category = NodeCategory.LOGIC
    display_name = "Delay"
    description = "Pause the workflow, then carry on."
    icon = "clock"
    config_schema = DelayConfig
    # Long waits suspend the run rather than occupying a worker, so retrying a
    # delay is meaningless.
    default_retry_policy = RetryPolicy(max_attempts=1)
