"use client";

import Link from "next/link";
import { useAuth } from "@/features/auth/AuthProvider";
import { ThemeToggle } from "./ThemeToggle";

export function HomeHeaderActions() {
  const { me, loading, signOut } = useAuth();

  return (
    <div className="flex items-center gap-3">
      {loading ? null : me ? (
        <>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>
            {me.user.email}
          </span>
          <button
            type="button"
            onClick={signOut}
            className="text-xs underline underline-offset-2"
            style={{ color: "var(--text-muted)" }}
          >
            Sign out
          </button>
        </>
      ) : (
        <>
          <Link
            href="/login"
            className="text-xs underline underline-offset-2"
            style={{ color: "var(--text-muted)" }}
          >
            Sign in
          </Link>
          <Link
            href="/register"
            className="text-xs underline underline-offset-2"
            style={{ color: "var(--accent)" }}
          >
            Create account
          </Link>
        </>
      )}
      <ThemeToggle />
    </div>
  );
}
