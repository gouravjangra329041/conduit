"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { authApi, type Me, type Session } from "@/lib/auth-client";

type AuthState = {
  session: Session | null;
  me: Me | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<void>;
  signUp: (input: {
    email: string;
    password: string;
    full_name: string | null;
    organization_name: string;
  }) => Promise<void>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [me, setMe] = useState<Me | null>(null);
  const [loading, setLoading] = useState(true);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const loadProfile = useCallback(async (next: Session) => {
    setSession(next);
    try {
      setMe(await authApi.me(next.access_token));
    } catch {
      setMe(null);
    }
  }, []);

  /**
   * Refresh shortly before expiry rather than waiting for a 401. A token that
   * expires mid-edit would otherwise surface as a random failed save.
   */
  const scheduleRefresh = useCallback(
    (next: Session) => {
      if (timer.current) clearTimeout(timer.current);
      const msUntilExpiry = new Date(next.expires_at).getTime() - Date.now();
      const delay = Math.max(10_000, msUntilExpiry - 60_000);
      timer.current = setTimeout(async () => {
        try {
          const refreshed = await authApi.refresh();
          await loadProfile(refreshed);
          scheduleRefresh(refreshed);
        } catch {
          setSession(null);
          setMe(null);
        }
      }, delay);
    },
    [loadProfile],
  );

  // On mount the in-memory token is gone, but the httpOnly cookie survives —
  // so try to restore the session silently.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const restored = await authApi.refresh();
        if (cancelled) return;
        await loadProfile(restored);
        scheduleRefresh(restored);
      } catch {
        // No valid session; the user is simply signed out.
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
      if (timer.current) clearTimeout(timer.current);
    };
  }, [loadProfile, scheduleRefresh]);

  const signIn = useCallback(
    async (email: string, password: string) => {
      const next = await authApi.login({ email, password });
      await loadProfile(next);
      scheduleRefresh(next);
    },
    [loadProfile, scheduleRefresh],
  );

  const signUp = useCallback(
    async (input: {
      email: string;
      password: string;
      full_name: string | null;
      organization_name: string;
    }) => {
      const { session: next } = await authApi.register(input);
      await loadProfile(next);
      scheduleRefresh(next);
    },
    [loadProfile, scheduleRefresh],
  );

  const signOut = useCallback(async () => {
    try {
      await authApi.logout();
    } finally {
      if (timer.current) clearTimeout(timer.current);
      setSession(null);
      setMe(null);
    }
  }, []);

  const value = useMemo(
    () => ({ session, me, loading, signIn, signUp, signOut }),
    [session, me, loading, signIn, signUp, signOut],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthState {
  const context = useContext(AuthContext);
  if (!context) throw new Error("useAuth must be used inside AuthProvider");
  return context;
}
