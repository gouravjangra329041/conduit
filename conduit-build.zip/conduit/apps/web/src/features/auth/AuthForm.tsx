"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ApiError } from "@/lib/auth-client";
import { ThemeToggle } from "@/features/theme/ThemeToggle";
import { useAuth } from "./AuthProvider";

const MIN_PASSWORD_LENGTH = 12;

const field =
  "w-full rounded border px-3 py-2 text-sm outline-none focus:border-[var(--accent)]";

export function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const { signIn, signUp } = useAuth();
  const isRegister = mode === "register";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [organization, setOrganization] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);

    if (isRegister && password.length < MIN_PASSWORD_LENGTH) {
      setError(
        `Use at least ${MIN_PASSWORD_LENGTH} characters. A short phrase works well.`,
      );
      return;
    }

    setBusy(true);
    try {
      if (isRegister) {
        await signUp({
          email,
          password,
          full_name: fullName || null,
          organization_name: organization || "My workspace",
        });
      } else {
        await signIn(email, password);
      }
      router.push("/editor");
    } catch (err) {
      // Errors explain what to do next; they don't apologise and they aren't vague.
      if (err instanceof ApiError) {
        setError(
          err.status === 0 || err.status >= 500
            ? "Can't reach the server. Check that the API is running."
            : err.message,
        );
      } else {
        setError("Can't reach the server. Check that the API is running.");
      }
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center px-6 py-12">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex items-start justify-between">
          <div>
            <Link
              href="/"
              className="font-[family-name:var(--font-display)] text-2xl font-bold tracking-tight"
            >
              Conduit
            </Link>
            <p className="mt-1 text-sm" style={{ color: "var(--text-muted)" }}>
              {isRegister
                ? "Create an account and your first workspace."
                : "Sign in to your workspace."}
            </p>
          </div>
          <ThemeToggle />
        </div>

        <form
          onSubmit={submit}
          className="space-y-4 rounded-[var(--radius-card)] border p-5"
          style={{ borderColor: "var(--border)", backgroundColor: "var(--surface)" }}
        >
          {isRegister && (
            <>
              <label className="block">
                <span className="mb-1 block text-xs font-medium">Your name</span>
                <input
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  autoComplete="name"
                  className={field}
                  style={{ borderColor: "var(--border)" }}
                />
              </label>
              <label className="block">
                <span className="mb-1 block text-xs font-medium">Workspace name</span>
                <input
                  value={organization}
                  onChange={(e) => setOrganization(e.target.value)}
                  placeholder="My workspace"
                  className={field}
                  style={{ borderColor: "var(--border)" }}
                />
              </label>
            </>
          )}

          <label className="block">
            <span className="mb-1 block text-xs font-medium">Email</span>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              className={field}
              style={{ borderColor: "var(--border)" }}
            />
          </label>

          <label className="block">
            <span className="mb-1 block text-xs font-medium">Password</span>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={isRegister ? "new-password" : "current-password"}
              className={field}
              style={{ borderColor: "var(--border)" }}
            />
            {isRegister && (
              <span
                className="mt-1 block text-[11px]"
                style={{ color: "var(--text-muted)" }}
              >
                At least {MIN_PASSWORD_LENGTH} characters. Length beats symbols —
                a short phrase you&apos;ll remember is stronger than P@ssw0rd!
              </span>
            )}
          </label>

          {error && (
            <p
              className="rounded border px-3 py-2 text-xs"
              style={{
                borderColor: "var(--color-status-failed)",
                color: "var(--color-status-failed)",
              }}
              role="alert"
            >
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full rounded px-3 py-2 text-sm font-medium transition-opacity hover:opacity-90 disabled:opacity-50"
            style={{ backgroundColor: "var(--accent)", color: "var(--accent-contrast)" }}
          >
            {busy
              ? isRegister
                ? "Creating account…"
                : "Signing in…"
              : isRegister
                ? "Create account"
                : "Sign in"}
          </button>
        </form>

        <p className="mt-4 text-center text-sm" style={{ color: "var(--text-muted)" }}>
          {isRegister ? "Already have an account? " : "No account yet? "}
          <Link
            href={isRegister ? "/login" : "/register"}
            className="underline underline-offset-2"
            style={{ color: "var(--accent)" }}
          >
            {isRegister ? "Sign in" : "Create one"}
          </Link>
        </p>

        <p className="mt-6 text-center text-xs" style={{ color: "var(--text-faint)" }}>
          Accounts are stored in PostgreSQL. If the API can&apos;t reach a database,
          sign-in will fail.
        </p>
      </div>
    </main>
  );
}
