"use client";

/**
 * Config forms generated from each node's JSON Schema.
 *
 * This component is the proof that the plugin system is real: it has no
 * knowledge of any specific node type. A new node ships from the backend with
 * a Pydantic schema, and its form appears here with no frontend change.
 */

import { effectiveSchema, type JsonSchema } from "@/lib/nodes";

type Props = {
  root: JsonSchema;
  values: Record<string, unknown>;
  onChange: (key: string, value: unknown) => void;
};

const inputClass =
  "w-full rounded border px-2.5 py-1.5 text-sm outline-none focus:border-[var(--accent)]";
const inputStyle = { borderColor: "var(--border)" };

function Label({ text, hint }: { text: string; hint?: string }) {
  return (
    <>
      <span className="block text-xs font-medium">{text}</span>
      {hint && (
        <span
          className="mb-1 block text-[11px] leading-snug"
          style={{ color: "var(--text-muted)" }}
        >
          {hint}
        </span>
      )}
    </>
  );
}

function Field({
  name,
  schema,
  root,
  value,
  onChange,
}: {
  name: string;
  schema: JsonSchema;
  root: JsonSchema;
  value: unknown;
  onChange: (value: unknown) => void;
}) {
  const resolved = effectiveSchema(schema, root);
  const title = resolved.title ?? name;
  const hint = resolved.description;

  if (resolved.enum) {
    return (
      <label className="block">
        <Label text={title} hint={hint} />
        <select
          value={String(value ?? "")}
          onChange={(e) => onChange(e.target.value)}
          className={inputClass}
          style={inputStyle}
        >
          {resolved.enum.map((option) => (
            <option key={option} value={option}>
              {option}
            </option>
          ))}
        </select>
      </label>
    );
  }

  if (resolved.type === "boolean") {
    return (
      <label className="flex items-start gap-2">
        <input
          type="checkbox"
          checked={Boolean(value)}
          onChange={(e) => onChange(e.target.checked)}
          className="mt-0.5"
        />
        <span>
          <Label text={title} hint={hint} />
        </span>
      </label>
    );
  }

  if (resolved.type === "integer" || resolved.type === "number") {
    return (
      <label className="block">
        <Label text={title} hint={hint} />
        <input
          type="number"
          value={Number(value ?? 0)}
          min={resolved.minimum}
          max={resolved.maximum}
          onChange={(e) => onChange(Number(e.target.value))}
          className={`${inputClass} font-mono`}
          style={inputStyle}
        />
      </label>
    );
  }

  if (resolved.type === "array") {
    // Repeating rows (headers, conditions, field assignments) get a dedicated
    // editor in Module 12. Until then the shape is shown honestly rather than
    // rendered as a broken text box.
    const items = Array.isArray(value) ? value : [];
    return (
      <div>
        <Label text={title} hint={hint} />
        <p
          className="rounded border border-dashed px-2.5 py-2 text-xs"
          style={{ borderColor: "var(--border)", color: "var(--text-muted)" }}
        >
          {items.length} item{items.length === 1 ? "" : "s"} · row editor arrives
          with workflow saving
        </p>
      </div>
    );
  }

  // Long-form text and anything expression-bearing gets a monospace textarea:
  // half of what people type here is {{ ... }}.
  const long = (resolved.maxLength ?? 0) > 2000;
  return (
    <label className="block">
      <Label text={title} hint={hint} />
      {long ? (
        <textarea
          value={String(value ?? "")}
          rows={4}
          onChange={(e) => onChange(e.target.value)}
          className={`${inputClass} font-mono resize-y`}
          style={inputStyle}
        />
      ) : (
        <input
          type="text"
          value={String(value ?? "")}
          onChange={(e) => onChange(e.target.value)}
          className={inputClass}
          style={inputStyle}
        />
      )}
    </label>
  );
}

export function SchemaForm({ root, values, onChange }: Props) {
  const properties = Object.entries(root.properties ?? {});
  if (properties.length === 0) {
    return (
      <p className="text-sm" style={{ color: "var(--text-muted)" }}>
        This node has nothing to configure.
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {properties.map(([name, schema]) => (
        <Field
          key={name}
          name={name}
          schema={schema}
          root={root}
          value={values[name]}
          onChange={(v) => onChange(name, v)}
        />
      ))}
    </div>
  );
}
