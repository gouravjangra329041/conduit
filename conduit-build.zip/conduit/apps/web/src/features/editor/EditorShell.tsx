"use client";

import Link from "next/link";
import { useAuth } from "@/features/auth/AuthProvider";
import { ThemeToggle } from "@/features/theme/ThemeToggle";
import type { NodeCatalog } from "@/lib/nodes";
import { Canvas } from "./Canvas";

function Message({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="flex flex-1 items-center justify-center p-6">
      <div className="max-w-sm text-center">
        <p className="text-sm font-medium">{title}</p>
        <div className="mt-2 text-sm" style={{ color: "var(--text-muted)" }}>
          {children}
        </div>
      </div>
    </div>
  );
}

export function EditorShell({ catalog }: { catalog: NodeCatalog | null }) {
  const { me, loading, signOut } = useAuth();

  return (
    <div className="flex h-screen flex-col">
      <header
        className="flex h-14 shrink-0 items-center justify-between border-b px-4"
        style={{ borderColor: "var(--border)", backgroundColor: "var(--surface)" }}
      >
        <div className="flex items-baseline gap-3">
          <Link
            href="/"
            className="font-[family-name:var(--font-display)] text-base font-bold tracking-tight"
          >
            Conduit
          </Link>
          <span className="text-sm" style={{ color: "var(--text-muted)" }}>
            Untitled workflow
          </span>
        </div>

        <div className="flex items-center gap-3">
          {catalog && (
            <span
              className="hidden font-mono text-[11px] sm:inline"
              style={{ color: "var(--text-faint)" }}
            >
              {catalog.count} node types · {catalog.fingerprint}
            </span>
          )}
          {me ? (
            <>
              <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                {me.user.email}
              </span>
              <button
                type="button"
                onClick={signOut}
                className="text-xs underline underline-offset-2"
                style={{ color: "var(--text-muted)" }}
              >
                Sign out
              </button>
            </>
          ) : (
            !loading && (
              <Link
                href="/login"
                className="text-xs underline underline-offset-2"
                style={{ color: "var(--accent)" }}
              >
                Sign in
              </Link>
            )
          )}
          <ThemeToggle />
        </div>
      </header>

      {!catalog ? (
        <Message title="Can't reach the API">
          The palette is built from the node catalogue the backend serves, so
          there is nothing to show until it is running. Start it with{" "}
          <code className="font-mono">python -m conduit.entrypoints.api</code>.
        </Message>
      ) : (
        // The canvas is deliberately usable while signed out: nothing is saved
        // yet, so there is nothing to protect. Once workflows persist
        // (Module 4) this becomes a real gate.
        <Canvas catalog={catalog} />
      )}
    </div>
  );
}
