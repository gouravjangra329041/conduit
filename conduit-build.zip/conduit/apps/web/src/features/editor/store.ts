"use client";

import { create } from "zustand";
import {
  addEdge,
  applyEdgeChanges,
  applyNodeChanges,
  type Connection,
  type Edge,
  type EdgeChange,
  type Node,
  type NodeChange,
} from "@xyflow/react";
import { defaultConfig, type NodeSpec } from "@/lib/nodes";

export type WorkflowNodeData = {
  spec: NodeSpec;
  label: string;
  config: Record<string, unknown>;
};

export type WorkflowNode = Node<WorkflowNodeData, "workflow">;

let counter = 0;

/**
 * Node ids are stable and opaque (`n_1`, `n_2`), never the display name.
 * Expressions reference nodes by this id, so renaming a node on the canvas
 * can never break a downstream expression. The editor shows friendly names;
 * the saved definition stores ids. See ADR-001.
 */
function nextId(): string {
  counter += 1;
  return `n_${counter}`;
}

type EditorState = {
  nodes: WorkflowNode[];
  edges: Edge[];
  selectedId: string | null;
  onNodesChange: (changes: NodeChange<WorkflowNode>[]) => void;
  onEdgesChange: (changes: EdgeChange[]) => void;
  onConnect: (connection: Connection) => void;
  addNode: (spec: NodeSpec, position: { x: number; y: number }) => void;
  select: (id: string | null) => void;
  rename: (id: string, label: string) => void;
  updateConfig: (id: string, key: string, value: unknown) => void;
  remove: (id: string) => void;
  clear: () => void;
};

export const useEditor = create<EditorState>((set, get) => ({
  nodes: [],
  edges: [],
  selectedId: null,

  onNodesChange: (changes) =>
    set({ nodes: applyNodeChanges(changes, get().nodes) }),

  onEdgesChange: (changes) =>
    set({ edges: applyEdgeChanges(changes, get().edges) }),

  onConnect: (connection) =>
    set({ edges: addEdge({ ...connection, type: "smoothstep" }, get().edges) }),

  addNode: (spec, position) => {
    const id = nextId();
    set({
      nodes: [
        ...get().nodes,
        {
          id,
          type: "workflow",
          position,
          data: { spec, label: spec.display_name, config: defaultConfig(spec) },
        },
      ],
      selectedId: id,
    });
  },

  select: (id) => set({ selectedId: id }),

  rename: (id, label) =>
    set({
      nodes: get().nodes.map((n) =>
        n.id === id ? { ...n, data: { ...n.data, label } } : n,
      ),
    }),

  updateConfig: (id, key, value) =>
    set({
      nodes: get().nodes.map((n) =>
        n.id === id
          ? { ...n, data: { ...n.data, config: { ...n.data.config, [key]: value } } }
          : n,
      ),
    }),

  remove: (id) =>
    set({
      nodes: get().nodes.filter((n) => n.id !== id),
      edges: get().edges.filter((e) => e.source !== id && e.target !== id),
      selectedId: get().selectedId === id ? null : get().selectedId,
    }),

  clear: () => set({ nodes: [], edges: [], selectedId: null }),
}));
