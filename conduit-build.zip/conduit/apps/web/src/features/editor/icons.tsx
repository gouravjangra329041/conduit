/**
 * Node icons.
 *
 * Categories are distinguished by icon and label, never by colour. The six
 * status hues are reserved for run state, and a canvas that spends colour on
 * decoration leaves nothing to say "this node failed".
 */
import type { JSX } from "react";

const paths: Record<string, JSX.Element> = {
  play: <path d="M6 4l12 8-12 8V4z" />,
  webhook: (
    <>
      <circle cx="12" cy="7" r="3" />
      <path d="M12 10v4M9 20l3-6 3 6M5 20h14" />
    </>
  ),
  "git-branch": (
    <>
      <circle cx="7" cy="6" r="2.5" />
      <circle cx="17" cy="6" r="2.5" />
      <circle cx="12" cy="18" r="2.5" />
      <path d="M7 8.5v2a3 3 0 003 3h4a3 3 0 003-3v-2" />
    </>
  ),
  clock: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7v5l3.5 2" />
    </>
  ),
  pencil: <path d="M4 20l4-1 11-11-3-3L5 16l-1 4zM14 6l3 3" />,
  braces: (
    <path d="M8 4c-2 0-2 3-2 4s0 3-2 4c2 1 2 3 2 4s0 4 2 4M16 4c2 0 2 3 2 4s0 3 2 4c-2 1-2 3-2 4s0 4-2 4" />
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M3.5 12h17M12 3.5c2.5 2.7 2.5 14.3 0 17M12 3.5c-2.5 2.7-2.5 14.3 0 17" />
    </>
  ),
  sparkles: (
    <path d="M12 3l1.8 4.7L18.5 9.5l-4.7 1.8L12 16l-1.8-4.7L5.5 9.5l4.7-1.8L12 3zM18 16l.9 2.1L21 19l-2.1.9L18 22l-.9-2.1L15 19l2.1-.9L18 16z" />
  ),
  mail: (
    <>
      <rect x="3" y="5.5" width="18" height="13" rx="2" />
      <path d="M3.5 7l8.5 6 8.5-6" />
    </>
  ),
  circle: <circle cx="12" cy="12" r="8.5" />,
};

export function NodeIcon({ name, size = 16 }: { name: string; size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      {paths[name] ?? paths.circle}
    </svg>
  );
}
