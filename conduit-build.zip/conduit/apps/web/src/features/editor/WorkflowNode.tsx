"use client";

import { Handle, Position, type NodeProps } from "@xyflow/react";
import { NodeIcon } from "./icons";
import type { WorkflowNode as WorkflowNodeType } from "./store";

const CATEGORY_LABEL: Record<string, string> = {
  trigger: "Trigger",
  action: "Action",
  logic: "Logic",
  transform: "Transform",
};

const handleStyle = { background: "var(--border-strong)" };

export function WorkflowNode({ data, selected }: NodeProps<WorkflowNodeType>) {
  const { spec, label } = data;
  const outputs = spec.output_ports;
  const edge = selected ? "var(--accent)" : "var(--border)";

  return (
    <div
      className="min-w-[190px] rounded-[var(--radius-card)] border-solid shadow-sm transition-shadow"
      style={{
        backgroundColor: "var(--surface)",
        boxShadow: selected ? "0 0 0 3px var(--accent-soft)" : undefined,
        // Each side is set explicitly. Mixing the `borderColor` shorthand with
        // `borderLeftColor` in one style object makes the applied value depend
        // on property order, which React warns about and which silently breaks
        // on re-render.
        borderTopWidth: 1,
        borderRightWidth: 1,
        borderBottomWidth: 1,
        // Triggers start the run, so they get a heavier left edge — a shape
        // cue, not a colour cue, since colour belongs to run status.
        borderLeftWidth: spec.is_trigger ? 3 : 1,
        borderTopColor: edge,
        borderRightColor: edge,
        borderBottomColor: edge,
        borderLeftColor: spec.is_trigger ? "var(--accent)" : edge,
      }}
    >
      {spec.input_ports.map((port) => (
        <Handle
          key={port.name}
          id={port.name}
          type="target"
          position={Position.Left}
          className="!h-2.5 !w-2.5 !border-2"
          style={{ ...handleStyle, borderColor: "var(--surface)" }}
        />
      ))}

      <div className="flex items-start gap-2.5 px-3 py-2.5">
        <span className="mt-0.5 shrink-0" style={{ color: "var(--text-muted)" }}>
          <NodeIcon name={spec.icon} />
        </span>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium leading-tight">{label}</p>
          <p
            className="mt-0.5 font-mono text-[10px] uppercase tracking-wider"
            style={{ color: "var(--text-faint)" }}
          >
            {CATEGORY_LABEL[spec.category] ?? spec.category}
          </p>
        </div>
      </div>

      {/* Multi-output nodes label their branches. An unlabelled second handle
          is the most common way people wire an If/Else backwards. */}
      {outputs.length > 1 ? (
        <div
          className="flex flex-col gap-1 border-t px-3 py-1.5"
          style={{ borderColor: "var(--border)" }}
        >
          {outputs.map((port) => (
            <div key={port.name} className="relative flex justify-end">
              <span
                className="font-mono text-[10px]"
                style={{ color: "var(--text-muted)" }}
              >
                {port.label}
              </span>
              <Handle
                id={port.name}
                type="source"
                position={Position.Right}
                className="!h-2.5 !w-2.5 !border-2"
                style={{
                  ...handleStyle,
                  borderColor: "var(--surface)",
                  top: "50%",
                  right: -18,
                }}
              />
            </div>
          ))}
        </div>
      ) : (
        outputs.map((port) => (
          <Handle
            key={port.name}
            id={port.name}
            type="source"
            position={Position.Right}
            className="!h-2.5 !w-2.5 !border-2"
            style={{ ...handleStyle, borderColor: "var(--surface)" }}
          />
        ))
      )}
    </div>
  );
}
