"use client";

import { useMemo, useState } from "react";
import type { NodeSpec } from "@/lib/nodes";
import { NodeIcon } from "./icons";
import { useEditor } from "./store";

const GROUP_ORDER: Array<[string, string]> = [
  ["trigger", "Triggers"],
  ["action", "Actions"],
  ["logic", "Logic"],
  ["transform", "Transform"],
];

export function NodePalette({ specs }: { specs: NodeSpec[] }) {
  const [query, setQuery] = useState("");
  const addNode = useEditor((s) => s.addNode);
  const nodeCount = useEditor((s) => s.nodes.length);

  const groups = useMemo(() => {
    const needle = query.trim().toLowerCase();
    const matches = specs.filter(
      (s) =>
        !needle ||
        s.display_name.toLowerCase().includes(needle) ||
        s.description.toLowerCase().includes(needle),
    );
    return GROUP_ORDER.map(([key, title]) => ({
      title,
      items: matches.filter((s) => s.category === key),
    })).filter((g) => g.items.length > 0);
  }, [specs, query]);

  // Stagger placement so consecutive clicks don't stack nodes on top of
  // each other and look like nothing happened.
  const place = () => ({ x: 80 + (nodeCount % 4) * 60, y: 80 + nodeCount * 40 });

  return (
    <aside
      className="flex w-64 shrink-0 flex-col border-r"
      style={{ borderColor: "var(--border)", backgroundColor: "var(--surface)" }}
    >
      <div className="border-b p-3" style={{ borderColor: "var(--border)" }}>
        <label htmlFor="node-search" className="sr-only">
          Search nodes
        </label>
        <input
          id="node-search"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search nodes"
          className="w-full rounded border px-2.5 py-1.5 text-sm outline-none"
          style={{ borderColor: "var(--border)" }}
        />
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        {groups.length === 0 && (
          <p className="px-1 text-sm" style={{ color: "var(--text-muted)" }}>
            No nodes match that search.
          </p>
        )}

        {groups.map((group) => (
          <section key={group.title} className="mb-5">
            <h3
              className="mb-2 px-1 font-mono text-[10px] uppercase tracking-[0.18em]"
              style={{ color: "var(--text-faint)" }}
            >
              {group.title}
            </h3>
            <ul className="space-y-1">
              {group.items.map((spec) => (
                <li key={spec.key}>
                  <button
                    type="button"
                    onClick={() => addNode(spec, place())}
                    className="flex w-full items-start gap-2.5 rounded px-2 py-2 text-left transition-colors hover:bg-[var(--surface-hover)]"
                  >
                    <span
                      className="mt-0.5 shrink-0"
                      style={{ color: "var(--text-muted)" }}
                    >
                      <NodeIcon name={spec.icon} />
                    </span>
                    <span className="min-w-0">
                      <span className="block text-sm font-medium">
                        {spec.display_name}
                      </span>
                      <span
                        className="block text-xs leading-snug"
                        style={{ color: "var(--text-muted)" }}
                      >
                        {spec.description}
                      </span>
                    </span>
                  </button>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
    </aside>
  );
}
