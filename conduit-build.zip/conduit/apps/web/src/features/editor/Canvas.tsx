"use client";

import { useCallback } from "react";
import {
  Background,
  Controls,
  MiniMap,
  ReactFlow,
  ReactFlowProvider,
  type NodeMouseHandler,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";

import type { NodeCatalog } from "@/lib/nodes";
import { ConfigPanel } from "./ConfigPanel";
import { NodePalette } from "./NodePalette";
import { WorkflowNode } from "./WorkflowNode";
import { useEditor, type WorkflowNode as WorkflowNodeType } from "./store";

const nodeTypes = { workflow: WorkflowNode };

function CanvasInner({ catalog }: { catalog: NodeCatalog }) {
  const nodes = useEditor((s) => s.nodes);
  const edges = useEditor((s) => s.edges);
  const onNodesChange = useEditor((s) => s.onNodesChange);
  const onEdgesChange = useEditor((s) => s.onEdgesChange);
  const onConnect = useEditor((s) => s.onConnect);
  const select = useEditor((s) => s.select);
  const clear = useEditor((s) => s.clear);

  const onNodeClick = useCallback<NodeMouseHandler<WorkflowNodeType>>(
    (_event, node) => select(node.id),
    [select],
  );

  return (
    <div className="flex h-[calc(100vh-3.5rem)]">
      <NodePalette specs={catalog.nodes} />

      <div className="relative flex-1">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={nodeTypes}
          onNodesChange={onNodesChange}
          onEdgesChange={onEdgesChange}
          onConnect={onConnect}
          onNodeClick={onNodeClick}
          onPaneClick={() => select(null)}
          fitView
          proOptions={{ hideAttribution: false }}
        >
          <Background gap={16} size={1} color="var(--canvas-dots)" />
          <Controls showInteractive={false} />
          <MiniMap pannable zoomable />
        </ReactFlow>

        {nodes.length === 0 && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
            <div className="max-w-xs text-center">
              <p className="text-sm font-medium">Start with a trigger</p>
              <p
                className="mt-1 text-sm leading-snug"
                style={{ color: "var(--text-muted)" }}
              >
                Pick a node from the left to add it, then drag from one node&apos;s
                right edge to another to connect them.
              </p>
            </div>
          </div>
        )}

        {nodes.length > 0 && (
          <button
            type="button"
            onClick={clear}
            className="absolute right-4 top-4 rounded border px-2.5 py-1.5 text-xs font-medium"
            style={{ borderColor: "var(--border)", backgroundColor: "var(--surface)" }}
          >
            Clear canvas
          </button>
        )}
      </div>

      <ConfigPanel />
    </div>
  );
}

export function Canvas({ catalog }: { catalog: NodeCatalog }) {
  return (
    <ReactFlowProvider>
      <CanvasInner catalog={catalog} />
    </ReactFlowProvider>
  );
}
