"use client";

import { SchemaForm } from "./SchemaForm";
import { useEditor } from "./store";

export function ConfigPanel() {
  const selectedId = useEditor((s) => s.selectedId);
  const node = useEditor((s) => s.nodes.find((n) => n.id === s.selectedId));
  const rename = useEditor((s) => s.rename);
  const updateConfig = useEditor((s) => s.updateConfig);
  const remove = useEditor((s) => s.remove);

  if (!node || !selectedId) {
    return (
      <aside
        className="w-80 shrink-0 border-l p-4"
        style={{ borderColor: "var(--border)" }}
      >
        <p className="text-sm" style={{ color: "var(--text-muted)" }}>
          Select a node to configure it.
        </p>
      </aside>
    );
  }

  const { spec, label, config } = node.data;

  return (
    <aside
      className="flex w-80 shrink-0 flex-col border-l"
      style={{ borderColor: "var(--border)", backgroundColor: "var(--surface)" }}
    >
      <div className="border-b p-4" style={{ borderColor: "var(--border)" }}>
        <label className="block">
          <span className="block text-xs font-medium">Name</span>
          <input
            value={label}
            onChange={(e) => rename(selectedId, e.target.value)}
            className="mt-1 w-full rounded border px-2.5 py-1.5 text-sm outline-none focus:border-[var(--accent)]"
            style={{ borderColor: "var(--border)" }}
          />
        </label>
        <p
          className="mt-2 font-mono text-[11px]"
          style={{ color: "var(--text-faint)" }}
        >
          {spec.key} · id {selectedId}
        </p>
      </div>

      <div className="flex-1 overflow-y-auto p-4">
        <SchemaForm
          root={spec.config_schema}
          values={config}
          onChange={(key, value) => updateConfig(selectedId, key, value)}
        />

        {spec.credential_type && (
          <p
            className="mt-5 rounded border border-dashed px-2.5 py-2 text-xs"
            style={{
              borderColor: "var(--border)",
              color: "var(--text-muted)",
            }}
          >
            Needs a {spec.credential_type} credential. Credentials are stored
            separately from the workflow and never appear in its definition.
          </p>
        )}
      </div>

      <div className="border-t p-4" style={{ borderColor: "var(--border)" }}>
        <button
          type="button"
          onClick={() => remove(selectedId)}
          className="text-xs font-medium underline underline-offset-2"
          style={{ color: "var(--color-status-failed)" }}
        >
          Remove node
        </button>
      </div>
    </aside>
  );
}
