const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export type ServiceHealth = {
  reachable: boolean;
  version?: string;
  environment?: string;
};

export async function fetchHealth(): Promise<ServiceHealth> {
  try {
    const response = await fetch(`${API_URL}/healthz`, { cache: "no-store" });
    if (!response.ok) return { reachable: false };
    const body = (await response.json()) as {
      version: string;
      environment: string;
    };
    return {
      reachable: true,
      version: body.version,
      environment: body.environment,
    };
  } catch {
    return { reachable: false };
  }
}
