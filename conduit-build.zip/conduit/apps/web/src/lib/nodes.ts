/**
 * Node catalog client.
 *
 * The editor holds no hardcoded knowledge of node types. Everything —
 * the palette, the ports on each node, the fields in each config form —
 * comes from this endpoint. Adding a node is a backend change only.
 */

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export type NodeCategory = "trigger" | "action" | "logic" | "transform";

export type PortSpec = {
  name: string;
  label: string;
  kind: "main" | "error";
  description?: string | null;
};

export type JsonSchema = {
  type?: string;
  title?: string;
  description?: string;
  default?: unknown;
  enum?: string[];
  properties?: Record<string, JsonSchema>;
  items?: JsonSchema;
  anyOf?: JsonSchema[];
  $ref?: string;
  $defs?: Record<string, JsonSchema>;
  minimum?: number;
  maximum?: number;
  maxLength?: number;
};

export type NodeSpec = {
  type: string;
  version: number;
  key: string;
  category: NodeCategory;
  display_name: string;
  description: string;
  icon: string;
  is_trigger: boolean;
  credential_type: string | null;
  config_schema: JsonSchema;
  input_ports: PortSpec[];
  output_ports: PortSpec[];
};

export type NodeCatalog = {
  fingerprint: string;
  count: number;
  nodes: NodeSpec[];
};

export async function fetchNodeCatalog(): Promise<NodeCatalog | null> {
  try {
    const response = await fetch(`${API_URL}/api/v1/nodes`, { cache: "no-store" });
    if (!response.ok) return null;
    return (await response.json()) as NodeCatalog;
  } catch {
    return null;
  }
}

/** Resolve a $ref against the schema's own $defs. */
export function resolveRef(schema: JsonSchema, root: JsonSchema): JsonSchema {
  if (!schema.$ref) return schema;
  const name = schema.$ref.split("/").pop();
  if (!name) return schema;
  return root.$defs?.[name] ?? schema;
}

/**
 * Pydantic emits optional fields as `anyOf: [{type: X}, {type: null}]`.
 * Unwrap to the meaningful branch so the form renders a real control
 * rather than falling through to a generic text box.
 */
export function effectiveSchema(schema: JsonSchema, root: JsonSchema): JsonSchema {
  const resolved = resolveRef(schema, root);
  if (!resolved.anyOf) return resolved;
  const branch = resolved.anyOf.find((s) => s.type !== "null");
  return branch ? { ...resolveRef(branch, root), title: resolved.title ?? branch.title, description: resolved.description ?? branch.description } : resolved;
}

export function defaultConfig(spec: NodeSpec): Record<string, unknown> {
  const root = spec.config_schema;
  const out: Record<string, unknown> = {};
  for (const [name, raw] of Object.entries(root.properties ?? {})) {
    const schema = effectiveSchema(raw, root);
    if (raw.default !== undefined) out[name] = raw.default;
    else if (schema.default !== undefined) out[name] = schema.default;
    else if (schema.type === "array") out[name] = [];
    else if (schema.type === "boolean") out[name] = false;
    else if (schema.type === "integer" || schema.type === "number") out[name] = 0;
    else out[name] = "";
  }
  return out;
}
