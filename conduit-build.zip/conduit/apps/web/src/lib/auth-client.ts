/**
 * Auth client.
 *
 * The access token is held in memory only — never in localStorage, which any
 * injected script can read. It is short-lived by design; the refresh token
 * lives in an httpOnly cookie the browser sends automatically and JavaScript
 * cannot touch.
 *
 * Because the access token is in memory, a page reload loses it. That is the
 * intended trade: on mount we call /auth/refresh, and the cookie silently
 * restores the session.
 */

const API_URL = process.env.NEXT_PUBLIC_API_URL ?? "http://localhost:8000";

export type Session = {
  access_token: string;
  expires_at: string;
  organization_id: string;
  role: "owner" | "admin" | "editor" | "viewer";
};

export type Me = {
  user: { id: string; email: string; full_name: string | null };
  organization_id: string;
  role: string;
  permissions: string[];
};

export class ApiError extends Error {
  constructor(
    message: string,
    readonly status: number,
  ) {
    super(message);
  }
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_URL}/api/v1${path}`, {
    ...init,
    // Required for the refresh cookie to be sent and set cross-origin.
    credentials: "include",
    headers: { "Content-Type": "application/json", ...(init.headers ?? {}) },
  });

  if (!response.ok) {
    let detail = "Something went wrong.";
    try {
      const body = await response.json();
      detail = body.detail ?? detail;
    } catch {
      // Non-JSON error body; keep the generic message.
    }
    throw new ApiError(detail, response.status);
  }

  return response.status === 204 ? (undefined as T) : ((await response.json()) as T);
}

export const authApi = {
  register: (input: {
    email: string;
    password: string;
    full_name: string | null;
    organization_name: string;
  }) =>
    request<{ session: Session }>("/auth/register", {
      method: "POST",
      body: JSON.stringify(input),
    }),

  login: (input: { email: string; password: string }) =>
    request<Session>("/auth/login", {
      method: "POST",
      body: JSON.stringify(input),
    }),

  refresh: () => request<Session>("/auth/refresh", { method: "POST" }),

  logout: () => request<void>("/auth/logout", { method: "POST" }),

  me: (token: string) =>
    request<Me>("/auth/me", { headers: { Authorization: `Bearer ${token}` } }),
};
