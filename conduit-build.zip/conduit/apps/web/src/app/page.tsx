import Link from "next/link";
import { fetchHealth } from "@/lib/api";
import { HomeHeaderActions } from "@/features/theme/HomeHeaderActions";

/**
 * Module 1 landing page: a build-status board, not a marketing page.
 *
 * It exists to answer one question during setup — "is the stack actually
 * wired up?" — and to prove the API connection and the token system work
 * end to end before the editor is built in Module 12.
 */

const MODULES = [
  { n: 1, name: "Foundation", detail: "Repo, Docker, config, logging, CI", done: true },
  { n: 2, name: "Identity", detail: "Users, orgs, JWT, RBAC", done: true },
  { n: 3, name: "Node contract", detail: "Registry, plugin entry points", done: true },
  { n: 4, name: "Workflow domain", detail: "Graph model, versions, validation", done: false },
  { n: 5, name: "Expressions", detail: "Parser and restricted evaluator", done: false },
  { n: 6, name: "Execution engine", detail: "Pure state machine", done: false },
  { n: 7, name: "Persistence", detail: "Repositories, queue, leases", done: false },
  { n: 8, name: "Core nodes I", detail: "Triggers, transforms, branching", done: false },
  { n: 9, name: "Suspension", detail: "Timers, delay, scheduler", done: false },
  { n: 10, name: "Core nodes II", detail: "HTTP, email, AI prompt", done: false },
  { n: 11, name: "Credentials", detail: "Envelope encryption", done: false },
  { n: 12, name: "Editor", detail: "React Flow canvas", done: false },
  { n: 13, name: "Run history", detail: "Timeline, payload inspector", done: false },
  { n: 14, name: "Hardening", detail: "Limits, RLS, load test", done: false },
];

export default async function Page() {
  const health = await fetchHealth();

  return (
    <main className="mx-auto max-w-3xl px-6 py-20">
      <header className="mb-14">
        <div className="mb-3 flex justify-end">
          <HomeHeaderActions />
        </div>
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-[var(--text-muted)]">
          Build status
        </p>
        <h1 className="mt-3 font-[family-name:var(--font-display)] text-4xl font-bold tracking-tight">
          Conduit
        </h1>
        <p className="mt-3 max-w-lg text-[var(--text-muted)]">
          Workflow automation platform. This page reports the state of the local
          stack while the product is under construction.
        </p>
      </header>

      <section
        className="mb-14 rounded-[var(--radius-card)] border p-5" style={{ borderColor: "var(--border)", backgroundColor: "var(--surface)" }}
        aria-labelledby="api-status"
      >
        <div className="flex items-center justify-between gap-4">
          <div>
            <h2 id="api-status" className="text-sm font-medium">
              API service
            </h2>
            <p className="mt-1 font-mono text-xs text-[var(--text-muted)]">
              {health.reachable
                ? `v${health.version} · ${health.environment}`
                : "No response — start the stack with `make up`"}
            </p>
          </div>
          <span
            className="inline-flex items-center gap-2 font-mono text-xs"
            style={{
              color: health.reachable
                ? "var(--color-status-succeeded)"
                : "var(--color-status-failed)",
            }}
          >
            <span
              aria-hidden
              className="h-2 w-2 rounded-full"
              style={{ backgroundColor: "currentColor" }}
            />
            {health.reachable ? "Reachable" : "Unreachable"}
          </span>
        </div>
      </section>

      <section className="mb-14">
        <Link
          href="/editor"
          className="inline-flex items-center gap-2 rounded-[var(--radius-card)] px-4 py-2.5 text-sm font-medium text-white transition-opacity hover:opacity-90"
          style={{ backgroundColor: "var(--accent)" }}
        >
          Open the workflow editor
        </Link>
        <p className="mt-2 text-xs" style={{ color: "var(--text-muted)" }}>
          Build a workflow on the canvas. Running it comes with the engine.
        </p>
      </section>

      <section aria-labelledby="modules">
        <h2
          id="modules"
          className="mb-5 font-mono text-xs uppercase tracking-[0.2em] text-[var(--text-muted)]"
        >
          Delivery plan
        </h2>
        {/*
          Numbered because the order genuinely carries information: each module
          depends on the ones before it. Decoration would not earn the numerals.
        */}
        <ol className="border-t border-[var(--border)]">
          {MODULES.map((module) => (
            <li
              key={module.n}
              className="flex items-baseline gap-4 border-b border-[var(--border)] py-3"
            >
              <span className="w-6 shrink-0 font-mono text-xs text-[var(--text-faint)]">
                {String(module.n).padStart(2, "0")}
              </span>
              <span
                className={
                  module.done
                    ? "text-sm font-medium"
                    : "text-sm text-[var(--text-muted)]"
                }
              >
                {module.name}
              </span>
              <span className="ml-auto text-right text-xs text-[var(--text-faint)]">
                {module.detail}
              </span>
              {module.done && (
                <span
                  className="ml-3 font-mono text-[10px] uppercase tracking-wider"
                  style={{ color: "var(--color-status-succeeded)" }}
                >
                  Done
                </span>
              )}
            </li>
          ))}
        </ol>
      </section>
    </main>
  );
}
