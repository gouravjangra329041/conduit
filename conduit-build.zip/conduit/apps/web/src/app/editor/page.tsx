import { EditorShell } from "@/features/editor/EditorShell";
import { fetchNodeCatalog } from "@/lib/nodes";

export const dynamic = "force-dynamic";

export default async function EditorPage() {
  const catalog = await fetchNodeCatalog();
  return <EditorShell catalog={catalog} />;
}
