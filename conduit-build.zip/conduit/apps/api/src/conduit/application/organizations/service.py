"""Organization membership use cases."""

from __future__ import annotations

import uuid
from dataclasses import dataclass

from conduit.domain.identity import (
    LastOwnerError,
    NotAMemberError,
    Principal,
    Role,
    RoleAssignmentError,
    can_assign_role,
)
from conduit.infrastructure.db.models.identity import Membership, User
from conduit.infrastructure.db.repositories.identity import (
    MembershipRepository,
    UserRepository,
)
from conduit.infrastructure.telemetry import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True, slots=True)
class MemberView:
    user_id: uuid.UUID
    email: str
    full_name: str | None
    role: Role
    created_at: object


class OrganizationService:
    def __init__(self, *, memberships: MembershipRepository, users: UserRepository) -> None:
        self._memberships = memberships
        self._users = users

    async def list_members(self, organization_id: uuid.UUID) -> list[MemberView]:
        members = await self._memberships.list_for_organization(organization_id)
        views: list[MemberView] = []
        for member in members:
            user = await self._users.get_by_id(member.user_id)
            if user is None:
                continue
            views.append(
                MemberView(
                    user_id=user.id,
                    email=user.email,
                    full_name=user.full_name,
                    role=member.role,
                    created_at=member.created_at,
                )
            )
        return views

    async def add_member(self, *, actor: Principal, email: str, role: Role) -> Membership:
        if not can_assign_role(actor.role, role):
            raise RoleAssignmentError(f"A {actor.role.value} cannot grant the {role.value} role.")

        user: User | None = await self._users.get_by_email(email.strip().lower())
        if user is None:
            # Invitation flow for unregistered addresses is deliberately out of
            # MVP scope — it needs email delivery, which lands in Module 10.
            raise NotAMemberError("No account exists with that email address.")

        existing = await self._memberships.get(actor.organization_id, user.id)
        if existing is not None:
            existing.role = role
            return existing

        membership = self._memberships.add(
            Membership(organization_id=actor.organization_id, user_id=user.id, role=role)
        )
        logger.info(
            "member_added",
            organization_id=str(actor.organization_id),
            user_id=str(user.id),
            role=role.value,
        )
        return membership

    async def change_role(self, *, actor: Principal, user_id: uuid.UUID, role: Role) -> Membership:
        membership = await self._memberships.get(actor.organization_id, user_id)
        if membership is None:
            raise NotAMemberError(str(user_id))

        # Both the old and the new role must be within the actor's authority.
        # Checking only the target role would let an admin demote an owner.
        if not can_assign_role(actor.role, role) or not can_assign_role(
            actor.role, membership.role
        ):
            raise RoleAssignmentError("You cannot change this member's role.")

        if membership.role is Role.OWNER and role is not Role.OWNER:
            await self._assert_not_last_owner(actor.organization_id)

        membership.role = role
        logger.info(
            "member_role_changed",
            organization_id=str(actor.organization_id),
            user_id=str(user_id),
            role=role.value,
        )
        return membership

    async def remove_member(self, *, actor: Principal, user_id: uuid.UUID) -> None:
        membership = await self._memberships.get(actor.organization_id, user_id)
        if membership is None:
            raise NotAMemberError(str(user_id))

        if not can_assign_role(actor.role, membership.role):
            raise RoleAssignmentError("You cannot remove this member.")

        if membership.role is Role.OWNER:
            await self._assert_not_last_owner(actor.organization_id)

        await self._memberships.delete(membership)
        logger.info(
            "member_removed",
            organization_id=str(actor.organization_id),
            user_id=str(user_id),
        )

    async def _assert_not_last_owner(self, organization_id: uuid.UUID) -> None:
        """An organization with no owner is unadministrable and unrecoverable.

        Nobody could manage members, rotate credentials, or delete it. Refusing
        here is far kinder than a support ticket.
        """
        if await self._memberships.count_owners(organization_id) <= 1:
            raise LastOwnerError("This is the only owner. Promote another member to owner first.")
