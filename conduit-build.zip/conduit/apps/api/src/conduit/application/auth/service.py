"""Authentication use cases.

Orchestration only. Every security *decision* lives in the domain
(`decide_refresh`, `has_permission`, `can_assign_role`); this layer wires those
decisions to storage and transactions.
"""

from __future__ import annotations

import re
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from conduit.application.unit_of_work import UnitOfWork
from conduit.config import SecuritySettings
from conduit.domain.identity import (
    AccountInactiveError,
    EmailAlreadyRegisteredError,
    InvalidCredentialsError,
    InvalidTokenError,
    NotAMemberError,
    RefreshOutcome,
    Role,
    SlugAlreadyTakenError,
    StoredRefreshToken,
    TokenReuseError,
    decide_refresh,
)
from conduit.infrastructure.crypto import (
    JWTService,
    PasswordService,
    generate_token,
    hash_token,
)
from conduit.infrastructure.crypto.passwords import (
    MAX_PASSWORD_LENGTH,
    MIN_PASSWORD_LENGTH,
)
from conduit.infrastructure.db.models.identity import (
    Membership,
    Organization,
    RefreshToken,
    User,
)
from conduit.infrastructure.db.repositories.identity import (
    MembershipRepository,
    OrganizationRepository,
    RefreshTokenRepository,
    UserRepository,
)
from conduit.infrastructure.telemetry import get_logger

logger = get_logger(__name__)

_SLUG_RE = re.compile(r"[^a-z0-9]+")


@dataclass(frozen=True, slots=True)
class TokenPair:
    access_token: str
    access_expires_at: datetime
    refresh_token: str
    refresh_expires_at: datetime
    organization_id: uuid.UUID
    role: Role


@dataclass(frozen=True, slots=True)
class ClientInfo:
    user_agent: str | None = None
    ip_address: str | None = None


def slugify(value: str) -> str:
    slug = _SLUG_RE.sub("-", value.strip().lower()).strip("-")
    return slug[:100] or "workspace"


def validate_password(password: str) -> None:
    """Length-based policy only, deliberately.

    Composition rules ("one uppercase, one symbol") measurably push people
    toward predictable substitutions and password reuse. Length is the
    property that actually resists guessing, and it is the current NIST
    guidance.
    """
    if len(password) < MIN_PASSWORD_LENGTH:
        raise ValueError(f"Password must be at least {MIN_PASSWORD_LENGTH} characters.")
    if len(password) > MAX_PASSWORD_LENGTH:
        raise ValueError(f"Password must be under {MAX_PASSWORD_LENGTH} characters.")


class AuthService:
    def __init__(
        self,
        *,
        users: UserRepository,
        organizations: OrganizationRepository,
        memberships: MembershipRepository,
        refresh_tokens: RefreshTokenRepository,
        passwords: PasswordService,
        jwt: JWTService,
        settings: SecuritySettings,
        uow: UnitOfWork,
    ) -> None:
        self._users = users
        self._organizations = organizations
        self._memberships = memberships
        self._refresh_tokens = refresh_tokens
        self._passwords = passwords
        self._jwt = jwt
        self._settings = settings
        self._uow = uow

    # ---------------------------------------------------------------- register

    async def register(
        self,
        *,
        email: str,
        password: str,
        full_name: str | None,
        organization_name: str,
        client: ClientInfo,
    ) -> tuple[User, Organization, TokenPair]:
        """Create a user, their first organization, and an owner membership.

        All three in one transaction. A user without an organization cannot do
        anything in this product, so a partial success would leave an account
        permanently stuck.
        """
        validate_password(password)
        email = email.strip().lower()

        if await self._users.email_exists(email):
            raise EmailAlreadyRegisteredError(email)

        slug = slugify(organization_name)
        if await self._organizations.slug_exists(slug):
            slug = f"{slug}-{uuid.uuid4().hex[:6]}"
            if await self._organizations.slug_exists(slug):
                raise SlugAlreadyTakenError(slug)

        user = self._users.add(
            User(
                email=email,
                password_hash=self._passwords.hash(password),
                full_name=full_name,
                is_active=True,
            )
        )
        organization = self._organizations.add(
            Organization(name=organization_name.strip(), slug=slug)
        )
        self._memberships.add(
            Membership(
                organization=organization,
                user=user,
                role=Role.OWNER,
            )
        )

        # Flush so PostgreSQL assigns identifiers and created_at before these
        # entities are serialised into the response.
        await self._uow.flush()
        await self._uow.refresh(user, organization)

        tokens = await self._issue_pair(
            user_id=user.id, organization_id=organization.id, role=Role.OWNER, client=client
        )
        logger.info("user_registered", user_id=str(user.id), organization_id=str(organization.id))
        return user, organization, tokens

    # ------------------------------------------------------------------- login

    async def login(
        self,
        *,
        email: str,
        password: str,
        organization_id: uuid.UUID | None,
        client: ClientInfo,
    ) -> tuple[User, TokenPair]:
        email = email.strip().lower()
        user = await self._users.get_by_email(email)

        if user is None or user.password_hash is None:
            # Equalise timing so a missing account is indistinguishable from a
            # wrong password. Without this, response latency enumerates users.
            self._passwords.verify_dummy()
            raise InvalidCredentialsError

        if not self._passwords.verify(user.password_hash, password):
            raise InvalidCredentialsError

        if not user.is_active:
            raise AccountInactiveError

        memberships = await self._memberships.list_for_user(user.id)
        if not memberships:
            raise NotAMemberError("User belongs to no organization")

        if organization_id is not None:
            selected = next((m for m in memberships if m.organization_id == organization_id), None)
            if selected is None:
                raise NotAMemberError(str(organization_id))
        else:
            selected = memberships[0]

        if self._passwords.needs_rehash(user.password_hash):
            # Transparent upgrade when cost parameters are raised.
            await self._users.update_password_hash(user.id, self._passwords.hash(password))

        await self._users.touch_login(user.id)
        tokens = await self._issue_pair(
            user_id=user.id,
            organization_id=selected.organization_id,
            role=selected.role,
            client=client,
        )
        logger.info(
            "user_logged_in",
            user_id=str(user.id),
            organization_id=str(selected.organization_id),
        )
        return user, tokens

    # ----------------------------------------------------------------- refresh

    async def refresh(self, *, refresh_token: str, client: ClientInfo) -> TokenPair:
        stored = await self._refresh_tokens.get_by_hash(hash_token(refresh_token))
        if stored is None:
            raise InvalidTokenError("Unknown refresh token")

        decision = decide_refresh(
            StoredRefreshToken(
                id=stored.id,
                user_id=stored.user_id,
                family_id=stored.family_id,
                expires_at=stored.expires_at,
                revoked_at=stored.revoked_at,
                consumed=stored.consumed_at is not None,
            ),
            now=datetime.now(UTC),
        )

        if decision.outcome is RefreshOutcome.REVOKE_FAMILY:
            assert decision.family_id is not None
            revoked = await self._refresh_tokens.revoke_family(decision.family_id)
            # Commit before raising. The error response unwinds the request
            # scope, which rolls the transaction back — silently undoing the
            # revocation. The security action must outlive the failure that
            # triggered it.
            await self._uow.commit()
            logger.warning(
                "refresh_token_reuse_detected",
                user_id=str(stored.user_id),
                family_id=str(decision.family_id),
                tokens_revoked=revoked,
            )
            raise TokenReuseError("Refresh token was already used; session revoked")

        if not decision.is_success:
            raise InvalidTokenError(f"Refresh token rejected: {decision.outcome.value}")

        # Losing this race means another request already exchanged the token.
        if not await self._refresh_tokens.consume(stored.id):
            raise TokenReuseError("Refresh token was already used")

        user = await self._users.get_by_id(stored.user_id)
        if user is None or not user.is_active:
            raise AccountInactiveError

        memberships = await self._memberships.list_for_user(user.id)
        if not memberships:
            raise NotAMemberError("User belongs to no organization")
        membership = memberships[0]

        return await self._issue_pair(
            user_id=user.id,
            organization_id=membership.organization_id,
            role=membership.role,
            client=client,
            family_id=stored.family_id,
        )

    # ------------------------------------------------------------------ logout

    async def logout(self, *, refresh_token: str) -> None:
        stored = await self._refresh_tokens.get_by_hash(hash_token(refresh_token))
        if stored is None:
            return  # Idempotent: logging out twice is not an error.
        await self._refresh_tokens.revoke_family(stored.family_id)

    async def logout_everywhere(self, *, user_id: uuid.UUID) -> int:
        return await self._refresh_tokens.revoke_all_for_user(user_id)

    # ----------------------------------------------------------------- helpers

    async def _issue_pair(
        self,
        *,
        user_id: uuid.UUID,
        organization_id: uuid.UUID,
        role: Role,
        client: ClientInfo,
        family_id: uuid.UUID | None = None,
    ) -> TokenPair:
        access_token, access_expires_at = self._jwt.issue(
            user_id=user_id, organization_id=organization_id, role=role
        )
        raw_refresh = generate_token()
        refresh_expires_at = datetime.now(UTC) + timedelta(
            seconds=self._settings.refresh_token_ttl_s
        )
        self._refresh_tokens.add(
            RefreshToken(
                user_id=user_id,
                token_hash=hash_token(raw_refresh),
                family_id=family_id or uuid.uuid4(),
                expires_at=refresh_expires_at,
                user_agent=client.user_agent,
                ip_address=client.ip_address,
            )
        )
        return TokenPair(
            access_token=access_token,
            access_expires_at=access_expires_at,
            refresh_token=raw_refresh,
            refresh_expires_at=refresh_expires_at,
            organization_id=organization_id,
            role=role,
        )
