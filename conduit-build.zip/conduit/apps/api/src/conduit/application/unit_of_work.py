"""Transaction control for use cases.

Repositories own queries; the unit of work owns *when* work is written. Keeping
them separate means a service can force a flush to obtain database-assigned
values (identifiers, server-side timestamps) without any repository needing to
know about transaction boundaries.

Flush is not commit. Flushing sends pending SQL so the database populates
defaults; the surrounding request or worker scope still decides whether to
commit or roll back.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy.ext.asyncio import AsyncSession


class UnitOfWork:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def flush(self) -> None:
        """Send pending changes so server-side defaults are assigned."""
        await self._session.flush()

    async def refresh(self, *instances: Any) -> None:
        """Reload instances so server-generated columns are readable."""
        for instance in instances:
            await self._session.refresh(instance)

    async def commit(self) -> None:
        await self._session.commit()

    async def rollback(self) -> None:
        await self._session.rollback()
