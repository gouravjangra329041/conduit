"""Worker process entrypoint.

Module 1 ships the process shell only: lifecycle, signal handling, graceful
drain. The execution engine lands in Module 6 and is wired to this loop in
Module 7.

Graceful shutdown is here from the start rather than added later, because the
lease mechanism depends on it. A worker that dies without releasing its leases
leaves every run it held stalled until the scheduler reclaims them — correct,
but a needless multi-second delay on every single deploy.
"""

from __future__ import annotations

import asyncio
import contextlib
import os
import signal
import socket

from conduit.config import get_settings
from conduit.infrastructure.db.session import dispose_engine, init_engine
from conduit.infrastructure.telemetry import configure_logging, get_logger

logger = get_logger(__name__)


class Worker:
    def __init__(self, worker_id: str) -> None:
        self.worker_id = worker_id
        self._shutdown = asyncio.Event()
        self._draining = False

    def request_shutdown(self, sig: signal.Signals) -> None:
        if self._draining:
            logger.warning("worker_force_exit", signal=sig.name)
            raise SystemExit(1)
        self._draining = True
        logger.info("worker_draining", signal=sig.name, worker_id=self.worker_id)
        self._shutdown.set()

    async def run(self) -> None:
        settings = get_settings()
        logger.info(
            "worker_started",
            worker_id=self.worker_id,
            claim_batch_size=settings.engine.claim_batch_size,
            lease_duration_s=settings.engine.lease_duration_s,
        )
        poll = settings.engine.claim_poll_interval_s
        while not self._shutdown.is_set():
            # Module 7 replaces this with:
            #   batch = await queue.claim(self.worker_id, size, lease)
            #   await asyncio.gather(*(self._execute(run) for run in batch))
            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(self._shutdown.wait(), timeout=poll)
        logger.info("worker_stopped", worker_id=self.worker_id)


async def _main() -> None:
    settings = get_settings()
    configure_logging(
        settings.telemetry, service=f"{settings.service_name}-worker", version=settings.version
    )
    settings.assert_production_ready()
    init_engine(settings.database)

    worker_id = settings.engine.worker_id or f"{socket.gethostname()}-{os.getpid()}"
    worker = Worker(worker_id)

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, worker.request_shutdown, sig)

    try:
        await worker.run()
    finally:
        await dispose_engine()


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
