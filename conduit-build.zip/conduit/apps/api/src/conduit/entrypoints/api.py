"""API process entrypoint."""

from __future__ import annotations

from conduit.config import get_settings
from conduit.interface.api.app import create_app

app = create_app()


def main() -> None:
    import uvicorn

    settings = get_settings()
    uvicorn.run(
        "conduit.entrypoints.api:app",
        host=settings.api_host,
        port=settings.api_port,
        reload=settings.environment == "local",
        access_log=False,  # RequestContextMiddleware owns access logging
        log_config=None,  # structlog owns formatting
    )


if __name__ == "__main__":
    main()
