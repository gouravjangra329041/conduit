"""Scheduler process entrypoint.

Singleton responsibilities, all of which must run exactly once cluster-wide:
timer scanning, stale-lease reclaim, partition creation, retention GC.

Leadership uses a Postgres advisory lock rather than a leader-election
sidecar. The lock is tied to the session, so a crashed leader releases it
automatically when its connection drops — no lease timeout to tune, no
split-brain window, no extra infrastructure.
"""

from __future__ import annotations

import asyncio
import contextlib
import signal

from sqlalchemy import text

from conduit.config import get_settings
from conduit.infrastructure.db.session import dispose_engine, get_engine, init_engine
from conduit.infrastructure.telemetry import configure_logging, get_logger

logger = get_logger(__name__)

LEADER_LOCK_KEY = 0x_C0FFEE_01


class Scheduler:
    def __init__(self) -> None:
        self._shutdown = asyncio.Event()

    def request_shutdown(self, sig: signal.Signals) -> None:
        logger.info("scheduler_stopping", signal=sig.name)
        self._shutdown.set()

    async def run(self) -> None:
        engine = get_engine()
        async with engine.connect() as conn:
            acquired = await conn.scalar(
                text("SELECT pg_try_advisory_lock(:key)"), {"key": LEADER_LOCK_KEY}
            )
            if not acquired:
                logger.info("scheduler_standby", reason="another instance holds leadership")
                await self._shutdown.wait()
                return

            logger.info("scheduler_leader_acquired")
            while not self._shutdown.is_set():
                # Module 9 adds: timer scan, lease reclaim, partition rotation,
                # payload retention GC.
                with contextlib.suppress(TimeoutError):
                    await asyncio.wait_for(self._shutdown.wait(), timeout=1.0)
            logger.info("scheduler_stopped")


async def _main() -> None:
    settings = get_settings()
    configure_logging(
        settings.telemetry,
        service=f"{settings.service_name}-scheduler",
        version=settings.version,
    )
    settings.assert_production_ready()
    init_engine(settings.database)

    scheduler = Scheduler()
    loop = asyncio.get_running_loop()
    for sig in (signal.SIGTERM, signal.SIGINT):
        loop.add_signal_handler(sig, scheduler.request_shutdown, sig)

    try:
        await scheduler.run()
    finally:
        await dispose_engine()


def main() -> None:
    asyncio.run(_main())


if __name__ == "__main__":
    main()
