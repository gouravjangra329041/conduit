"""FastAPI application factory."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from conduit.config import Settings, get_settings
from conduit.domain.nodes import build_registry
from conduit.infrastructure.db.session import dispose_engine, init_engine
from conduit.infrastructure.telemetry import configure_logging, get_logger

from .errors import register_exception_handlers
from .middleware.request_context import RequestContextMiddleware
from .middleware.security_headers import SecurityHeadersMiddleware
from .v1.routers import api_router
from .v1.routers.health import router as health_router

logger = get_logger(__name__)


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or get_settings()
    configure_logging(
        settings.telemetry, service=f"{settings.service_name}-api", version=settings.version
    )
    settings.assert_production_ready()

    @asynccontextmanager
    async def lifespan(app_: FastAPI) -> AsyncIterator[None]:
        init_engine(settings.database)
        # Built once, then frozen. The fingerprint is logged so a partial
        # deploy — API and workers disagreeing about the node set — is visible
        # rather than surfacing as mysterious runtime errors.
        registry = build_registry()
        app_.state.node_registry = registry
        logger.info(
            "api_started",
            environment=settings.environment,
            version=settings.version,
            node_count=len(registry),
            node_fingerprint=registry.fingerprint(),
        )
        yield
        await dispose_engine()
        logger.info("api_stopped")

    app = FastAPI(
        title="Conduit API",
        version=settings.version,
        description="AI workflow automation platform",
        root_path=settings.api_root_path,
        lifespan=lifespan,
        docs_url=None if settings.is_production else "/docs",
        redoc_url=None,
        openapi_url=None if settings.is_production else "/openapi.json",
    )

    app.add_middleware(SecurityHeadersMiddleware, hsts=settings.is_production)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
        allow_headers=["Authorization", "Content-Type", "X-Request-Id", "X-Organization-Id"],
        expose_headers=["X-Request-Id"],
    )
    # Outermost so every request — including ones rejected by CORS or auth —
    # gets a correlation ID and an access log line.
    app.add_middleware(RequestContextMiddleware)

    register_exception_handlers(app)
    app.include_router(api_router, prefix="/api/v1")
    # Health endpoints only are also mounted unprefixed, so orchestrator
    # probes need not know about API versioning. Mounting the whole router
    # twice would duplicate every auth route and give the refresh cookie two
    # possible paths — one of which would silently never be sent.
    app.include_router(health_router)
    return app
