"""Node catalog.

This endpoint is what makes the plugin system real rather than notional: the
editor renders its palette and every config form from what this returns. The
frontend holds no hardcoded knowledge of node types, so adding a node is a
backend package change and no frontend change at all.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Request

from conduit.domain.nodes import NodeRegistry, UnknownNodeError
from conduit.interface.api.errors import NotFoundError

router = APIRouter(prefix="/nodes", tags=["nodes"])


def _registry(request: Request) -> NodeRegistry:
    registry: NodeRegistry = request.app.state.node_registry
    return registry


@router.get("")
async def list_nodes(request: Request) -> dict[str, Any]:
    registry = _registry(request)
    return {
        "fingerprint": registry.fingerprint(),
        "count": len(registry),
        "nodes": registry.catalog(),
    }


@router.get("/{node_type}/{version}")
async def get_node(node_type: str, version: int, request: Request) -> dict[str, Any]:
    registry = _registry(request)
    try:
        return registry.describe(registry.get(node_type, version))
    except UnknownNodeError as exc:
        raise NotFoundError(f"No node type {node_type}@{version}.") from exc
