"""Request and response models for authentication."""

from __future__ import annotations

import uuid
from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field

from conduit.domain.identity import Role
from conduit.infrastructure.crypto.passwords import (
    MAX_PASSWORD_LENGTH,
    MIN_PASSWORD_LENGTH,
)


class RegisterRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=MIN_PASSWORD_LENGTH, max_length=MAX_PASSWORD_LENGTH)
    full_name: str | None = Field(default=None, max_length=200)
    organization_name: str = Field(min_length=1, max_length=200)


class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(max_length=MAX_PASSWORD_LENGTH)
    organization_id: uuid.UUID | None = None


class UserResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    email: str
    full_name: str | None
    is_active: bool
    created_at: datetime


class OrganizationResponse(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: uuid.UUID
    name: str
    slug: str
    plan: str


class SessionResponse(BaseModel):
    """The refresh token is deliberately absent.

    It is delivered as an httpOnly cookie so JavaScript cannot read it, which
    removes the entire class of XSS-based session theft. The access token is
    returned in the body for the client to hold in memory only — never in
    localStorage, which is readable by any injected script.
    """

    access_token: str
    token_type: str = "bearer"  # noqa: S105 — a scheme name, not a secret
    expires_at: datetime
    organization_id: uuid.UUID
    role: Role


class RegisterResponse(BaseModel):
    user: UserResponse
    organization: OrganizationResponse
    session: SessionResponse


class MeResponse(BaseModel):
    user: UserResponse
    organization_id: uuid.UUID
    role: Role
    permissions: list[str]


class MembershipResponse(BaseModel):
    user_id: uuid.UUID
    email: str
    full_name: str | None
    role: Role
    created_at: datetime


class UpdateMemberRoleRequest(BaseModel):
    role: Role
