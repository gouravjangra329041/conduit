from fastapi import APIRouter

from . import auth, health, nodes, organizations

api_router = APIRouter()
api_router.include_router(health.router)
api_router.include_router(auth.router)
api_router.include_router(organizations.router)
api_router.include_router(nodes.router)

__all__ = ["api_router"]
