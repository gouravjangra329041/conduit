"""Binds a request ID and emits one access log line per request."""

from __future__ import annotations

import time
from collections.abc import Awaitable, Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from conduit.infrastructure.telemetry import bind, get_logger, new_request_id

logger = get_logger("http")

REQUEST_ID_HEADER = "X-Request-Id"


class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(
        self, request: Request, call_next: Callable[[Request], Awaitable[Response]]
    ) -> Response:
        # Honour an inbound ID so a trace survives across service hops, but
        # cap the length — this value lands in logs and must not be a vector.
        incoming = request.headers.get(REQUEST_ID_HEADER)
        request_id = incoming[:64] if incoming else new_request_id()

        started = time.perf_counter()
        with bind(request_id=request_id):
            request.state.request_id = request_id
            try:
                response = await call_next(request)
            except Exception:
                duration_ms = round((time.perf_counter() - started) * 1000, 2)
                logger.exception(
                    "request_failed",
                    method=request.method,
                    path=request.url.path,
                    duration_ms=duration_ms,
                )
                raise

            duration_ms = round((time.perf_counter() - started) * 1000, 2)
            response.headers[REQUEST_ID_HEADER] = request_id
            logger.info(
                "request_completed",
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                duration_ms=duration_ms,
            )
            return response
