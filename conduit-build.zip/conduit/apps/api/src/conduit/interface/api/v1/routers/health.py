"""Health and readiness.

Deliberately two endpoints with different meanings:

- /healthz  liveness. "This process is not wedged." Never touches the database.
  If it did, a brief DB blip would cause the orchestrator to kill every healthy
  replica at once and turn a degradation into an outage.
- /readyz   readiness. "This process can serve traffic." Checks dependencies.
"""

from __future__ import annotations

from typing import Any, Literal

from fastapi import APIRouter, Request, Response, status
from pydantic import BaseModel
from sqlalchemy import text

from conduit.config import get_settings
from conduit.infrastructure.db.session import get_session_factory
from conduit.infrastructure.telemetry import get_logger

logger = get_logger(__name__)
router = APIRouter(tags=["health"])


class HealthResponse(BaseModel):
    status: Literal["ok"]
    service: str
    version: str
    environment: str


class ReadinessResponse(BaseModel):
    status: Literal["ready", "degraded"]
    checks: dict[str, str]


@router.get("/healthz", response_model=HealthResponse)
async def liveness() -> HealthResponse:
    settings = get_settings()
    return HealthResponse(
        status="ok",
        service=settings.service_name,
        version=settings.version,
        environment=settings.environment,
    )


@router.get("/readyz", response_model=ReadinessResponse)
async def readiness(request: Request, response: Response) -> ReadinessResponse:
    checks: dict[str, str] = {}

    try:
        async with get_session_factory()() as session:
            await session.execute(text("SELECT 1"))
        checks["database"] = "ok"
    except Exception as exc:  # noqa: BLE001 — readiness must never raise
        logger.warning("readiness_check_failed", check="database", error=str(exc))
        checks["database"] = "unavailable"

    # Compared across replicas: a partial deploy where the API offers a node
    # the workers cannot execute should fail readiness, not surface later as a
    # mysterious runtime error.
    registry = getattr(request.app.state, "node_registry", None)
    checks["node_registry"] = (
        f"{len(registry)} nodes @ {registry.fingerprint()}" if registry else "not_loaded"
    )

    ready = checks["database"] == "ok" and registry is not None
    if not ready:
        response.status_code = status.HTTP_503_SERVICE_UNAVAILABLE
    return ReadinessResponse(status="ready" if ready else "degraded", checks=checks)


@router.get("/version")
async def version() -> dict[str, Any]:
    settings = get_settings()
    return {"version": settings.version, "service": settings.service_name}
