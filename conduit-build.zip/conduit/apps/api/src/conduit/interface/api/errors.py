"""RFC 7807 problem details.

Stable, machine-readable `type` URIs so the frontend can branch on specific
errors instead of string-matching messages. Internal detail never crosses the
boundary: tenants get a correlation ID to quote at support, operators get the
traceback in the logs.
"""

from __future__ import annotations

from typing import Any

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from conduit.infrastructure.telemetry import current_request_id, get_logger

logger = get_logger(__name__)

PROBLEM_BASE = "https://errors.conduit.dev"
CONTENT_TYPE = "application/problem+json"


class ProblemError(Exception):
    """Base for all errors that are safe to render to a client."""

    status_code: int = status.HTTP_400_BAD_REQUEST
    problem_type: str = "about:blank"
    title: str = "Request failed"

    def __init__(self, detail: str | None = None, **extra: Any) -> None:
        self.detail = detail or self.title
        self.extra = extra
        super().__init__(self.detail)


# Literal 422 rather than the Starlette constant: the constant was renamed
# (UNPROCESSABLE_ENTITY -> UNPROCESSABLE_CONTENT) and pinning to either name
# couples us to a Starlette version for no benefit. The number is stable.
class ValidationFailedError(ProblemError):
    status_code = 422
    problem_type = f"{PROBLEM_BASE}/validation-failed"
    title = "Validation failed"


class AuthenticationRequiredError(ProblemError):
    status_code = status.HTTP_401_UNAUTHORIZED
    problem_type = f"{PROBLEM_BASE}/authentication-required"
    title = "Authentication required"


class PermissionDeniedError(ProblemError):
    status_code = status.HTTP_403_FORBIDDEN
    problem_type = f"{PROBLEM_BASE}/permission-denied"
    title = "Permission denied"


class NotFoundError(ProblemError):
    status_code = status.HTTP_404_NOT_FOUND
    problem_type = f"{PROBLEM_BASE}/not-found"
    title = "Resource not found"


class ConflictError(ProblemError):
    status_code = status.HTTP_409_CONFLICT
    problem_type = f"{PROBLEM_BASE}/conflict"
    title = "Conflict"


class RateLimitedError(ProblemError):
    status_code = status.HTTP_429_TOO_MANY_REQUESTS
    problem_type = f"{PROBLEM_BASE}/rate-limited"
    title = "Too many requests"


def _problem_response(
    status_code: int, problem_type: str, title: str, detail: str, **extra: Any
) -> JSONResponse:
    body: dict[str, Any] = {
        "type": problem_type,
        "title": title,
        "status": status_code,
        "detail": detail,
        "request_id": current_request_id(),
        **extra,
    }
    return JSONResponse(status_code=status_code, content=body, media_type=CONTENT_TYPE)


def register_exception_handlers(app: FastAPI) -> None:
    @app.exception_handler(ProblemError)
    async def _problem(_r: Request, exc: ProblemError) -> JSONResponse:
        return _problem_response(
            exc.status_code, exc.problem_type, exc.title, exc.detail, **exc.extra
        )

    @app.exception_handler(RequestValidationError)
    async def _validation(_r: Request, exc: RequestValidationError) -> JSONResponse:
        errors = [
            {
                "field": ".".join(str(p) for p in err["loc"][1:]) or str(err["loc"][0]),
                "message": err["msg"],
                "code": err["type"],
            }
            for err in exc.errors()
        ]
        return _problem_response(
            422,
            ValidationFailedError.problem_type,
            ValidationFailedError.title,
            "One or more fields are invalid.",
            errors=errors,
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http(_r: Request, exc: StarletteHTTPException) -> JSONResponse:
        return _problem_response(
            exc.status_code,
            f"{PROBLEM_BASE}/http-{exc.status_code}",
            str(exc.detail),
            str(exc.detail),
        )

    @app.exception_handler(Exception)
    async def _unhandled(_r: Request, exc: Exception) -> JSONResponse:
        # Full detail to operators, correlation ID only to the caller.
        logger.exception("unhandled_exception", error_type=type(exc).__name__)
        return _problem_response(
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            f"{PROBLEM_BASE}/internal",
            "Internal server error",
            "Something went wrong on our side. Quote the request ID if you contact support.",
        )
