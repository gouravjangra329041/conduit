"""Authentication endpoints."""

from __future__ import annotations

from typing import Annotated

from fastapi import APIRouter, Cookie, Response, status

from conduit.application.auth.service import TokenPair
from conduit.config import Settings, get_settings
from conduit.domain.identity import (
    AccountInactiveError,
    EmailAlreadyRegisteredError,
    IdentityError,
    InvalidCredentialsError,
    InvalidTokenError,
    NotAMemberError,
    TokenReuseError,
    permissions_for,
)
from conduit.infrastructure.db.repositories.identity import UserRepository
from conduit.interface.api.deps import (
    AuthServiceDep,
    ClientInfoDep,
    PrincipalDep,
    SessionDep,
)
from conduit.interface.api.errors import (
    AuthenticationRequiredError,
    ConflictError,
    ValidationFailedError,
)
from conduit.interface.api.schemas.auth import (
    LoginRequest,
    MeResponse,
    OrganizationResponse,
    RegisterRequest,
    RegisterResponse,
    SessionResponse,
    UserResponse,
)

router = APIRouter(prefix="/auth", tags=["auth"])

REFRESH_COOKIE = "conduit_refresh"


def _set_refresh_cookie(response: Response, tokens: TokenPair, settings: Settings) -> None:
    response.set_cookie(
        key=REFRESH_COOKIE,
        value=tokens.refresh_token,
        # httpOnly: unreadable from JavaScript, so XSS cannot exfiltrate the session.
        httponly=True,
        # Secure everywhere except local http development.
        secure=settings.environment != "local",
        # Lax rather than Strict: Strict breaks the common case of following a
        # link into the app from email and finding yourself logged out.
        samesite="lax",
        max_age=settings.security.refresh_token_ttl_s,
        path="/api/v1/auth",
    )


def _session_response(tokens: TokenPair) -> SessionResponse:
    return SessionResponse(
        access_token=tokens.access_token,
        expires_at=tokens.access_expires_at,
        organization_id=tokens.organization_id,
        role=tokens.role,
    )


@router.post("/register", status_code=status.HTTP_201_CREATED)
async def register(
    payload: RegisterRequest,
    response: Response,
    service: AuthServiceDep,
    client: ClientInfoDep,
) -> RegisterResponse:
    try:
        user, organization, tokens = await service.register(
            email=str(payload.email),
            password=payload.password,
            full_name=payload.full_name,
            organization_name=payload.organization_name,
            client=client,
        )
    except EmailAlreadyRegisteredError as exc:
        raise ConflictError("An account with that email already exists.") from exc
    except ValueError as exc:
        raise ValidationFailedError(str(exc)) from exc

    _set_refresh_cookie(response, tokens, get_settings())
    return RegisterResponse(
        user=UserResponse.model_validate(user),
        organization=OrganizationResponse.model_validate(organization),
        session=_session_response(tokens),
    )


@router.post("/login")
async def login(
    payload: LoginRequest,
    response: Response,
    service: AuthServiceDep,
    client: ClientInfoDep,
) -> SessionResponse:
    try:
        _, tokens = await service.login(
            email=str(payload.email),
            password=payload.password,
            organization_id=payload.organization_id,
            client=client,
        )
    except (InvalidCredentialsError, NotAMemberError) as exc:
        # One message for both. Distinguishing them tells an attacker which
        # email addresses are registered.
        raise AuthenticationRequiredError("Incorrect email or password.") from exc
    except AccountInactiveError as exc:
        raise AuthenticationRequiredError("This account is not active.") from exc

    _set_refresh_cookie(response, tokens, get_settings())
    return _session_response(tokens)


@router.post("/refresh")
async def refresh(
    response: Response,
    service: AuthServiceDep,
    client: ClientInfoDep,
    conduit_refresh: Annotated[str | None, Cookie()] = None,
) -> SessionResponse:
    if not conduit_refresh:
        raise AuthenticationRequiredError("No session to refresh.")

    try:
        tokens = await service.refresh(refresh_token=conduit_refresh, client=client)
    except TokenReuseError as exc:
        response.delete_cookie(REFRESH_COOKIE, path="/api/v1/auth")
        raise AuthenticationRequiredError(
            "This session was ended for security reasons. Sign in again."
        ) from exc
    except (InvalidTokenError, AccountInactiveError, IdentityError) as exc:
        response.delete_cookie(REFRESH_COOKIE, path="/api/v1/auth")
        raise AuthenticationRequiredError("Session expired. Sign in again.") from exc

    _set_refresh_cookie(response, tokens, get_settings())
    return _session_response(tokens)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
async def logout(
    response: Response,
    service: AuthServiceDep,
    conduit_refresh: Annotated[str | None, Cookie()] = None,
) -> None:
    if conduit_refresh:
        await service.logout(refresh_token=conduit_refresh)
    response.delete_cookie(REFRESH_COOKIE, path="/api/v1/auth")


@router.get("/me")
async def me(principal: PrincipalDep, session: SessionDep) -> MeResponse:
    user = await UserRepository(session).get_by_id(principal.subject_id)
    if user is None:
        raise AuthenticationRequiredError("Account no longer exists.")
    return MeResponse(
        user=UserResponse.model_validate(user),
        organization_id=principal.organization_id,
        role=principal.role,
        permissions=sorted(p.value for p in permissions_for(principal.role)),
    )
