"""Organization and membership endpoints."""

from __future__ import annotations

import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, status

from conduit.application.organizations.service import OrganizationService
from conduit.domain.identity import (
    LastOwnerError,
    NotAMemberError,
    Permission,
    Principal,
    RoleAssignmentError,
)
from conduit.infrastructure.db.repositories.identity import (
    MembershipRepository,
    UserRepository,
)
from conduit.interface.api.deps import SessionDep, require
from conduit.interface.api.errors import (
    ConflictError,
    NotFoundError,
    PermissionDeniedError,
)
from conduit.interface.api.schemas.auth import (
    MembershipResponse,
    UpdateMemberRoleRequest,
)

router = APIRouter(prefix="/organizations", tags=["organizations"])


def _service(session: SessionDep) -> OrganizationService:
    return OrganizationService(
        memberships=MembershipRepository(session), users=UserRepository(session)
    )


ServiceDep = Annotated[OrganizationService, Depends(_service)]


@router.get("/current/members")
async def list_members(
    service: ServiceDep,
    principal: Annotated[Principal, Depends(require(Permission.MEMBER_READ))],
) -> list[MembershipResponse]:
    members = await service.list_members(principal.organization_id)
    return [
        MembershipResponse(
            user_id=m.user_id,
            email=m.email,
            full_name=m.full_name,
            role=m.role,
            created_at=m.created_at,
        )
        for m in members
    ]


@router.patch("/current/members/{user_id}")
async def update_member_role(
    user_id: uuid.UUID,
    payload: UpdateMemberRoleRequest,
    service: ServiceDep,
    principal: Annotated[Principal, Depends(require(Permission.MEMBER_WRITE))],
) -> dict[str, str]:
    try:
        membership = await service.change_role(actor=principal, user_id=user_id, role=payload.role)
    except NotAMemberError as exc:
        raise NotFoundError("That member is not part of this organization.") from exc
    except RoleAssignmentError as exc:
        raise PermissionDeniedError(str(exc)) from exc
    except LastOwnerError as exc:
        raise ConflictError(str(exc)) from exc
    return {"user_id": str(user_id), "role": membership.role.value}


@router.delete("/current/members/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def remove_member(
    user_id: uuid.UUID,
    service: ServiceDep,
    principal: Annotated[Principal, Depends(require(Permission.MEMBER_WRITE))],
) -> None:
    try:
        await service.remove_member(actor=principal, user_id=user_id)
    except NotAMemberError as exc:
        raise NotFoundError("That member is not part of this organization.") from exc
    except RoleAssignmentError as exc:
        raise PermissionDeniedError(str(exc)) from exc
    except LastOwnerError as exc:
        raise ConflictError(str(exc)) from exc
