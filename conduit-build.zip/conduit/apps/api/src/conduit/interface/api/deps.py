"""Request dependencies: authentication, tenancy, and authorisation.

The `require(...)` factory is the only sanctioned way to guard an endpoint.
Hand-written role checks inside handlers drift out of sync with the policy
matrix; routing every check through the domain keeps one source of truth.
"""

from __future__ import annotations

import ipaddress
import uuid
from collections.abc import AsyncIterator, Callable, Coroutine
from typing import Annotated, Any

from fastapi import Depends, Header, Request
from sqlalchemy.ext.asyncio import AsyncSession

from conduit.application.auth.service import AuthService, ClientInfo
from conduit.application.unit_of_work import UnitOfWork
from conduit.config import Settings, get_settings
from conduit.domain.identity import (
    InvalidTokenError,
    Permission,
    Principal,
    PrincipalKind,
)
from conduit.infrastructure.crypto import JWTService, PasswordService
from conduit.infrastructure.db.repositories.identity import (
    MembershipRepository,
    OrganizationRepository,
    RefreshTokenRepository,
    UserRepository,
)
from conduit.infrastructure.db.session import get_session_factory

from .errors import AuthenticationRequiredError, PermissionDeniedError

# Built once per process — the password hasher and JWT service are stateless
# and constructing a PasswordHasher per request wastes measurable CPU.
_password_service: PasswordService | None = None
_jwt_service: JWTService | None = None


def get_password_service(
    settings: Annotated[Settings, Depends(get_settings)],
) -> PasswordService:
    global _password_service
    if _password_service is None:
        _password_service = PasswordService(settings.security)
    return _password_service


def get_jwt_service(
    settings: Annotated[Settings, Depends(get_settings)],
) -> JWTService:
    global _jwt_service
    if _jwt_service is None:
        _jwt_service = JWTService(settings.security, is_production=settings.is_production)
    return _jwt_service


async def get_session() -> AsyncIterator[AsyncSession]:
    async with get_session_factory()() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise


SessionDep = Annotated[AsyncSession, Depends(get_session)]


def get_auth_service(
    session: SessionDep,
    settings: Annotated[Settings, Depends(get_settings)],
    passwords: Annotated[PasswordService, Depends(get_password_service)],
    jwt: Annotated[JWTService, Depends(get_jwt_service)],
) -> AuthService:
    return AuthService(
        users=UserRepository(session),
        organizations=OrganizationRepository(session),
        memberships=MembershipRepository(session),
        refresh_tokens=RefreshTokenRepository(session),
        passwords=passwords,
        jwt=jwt,
        settings=settings.security,
        uow=UnitOfWork(session),
    )


AuthServiceDep = Annotated[AuthService, Depends(get_auth_service)]


def _valid_ip(value: str | None) -> str | None:
    """Return the value only if it parses as an IP address.

    `request.client.host` is not guaranteed to be one — unix-socket transports
    and some proxy configurations put a hostname there. The column is INET, so
    an unparseable value would raise mid-login and take the endpoint down.
    Session metadata is diagnostic; dropping it is strictly better than
    failing authentication over it.
    """
    if not value:
        return None
    try:
        ipaddress.ip_address(value)
    except ValueError:
        return None
    return value


def get_client_info(request: Request) -> ClientInfo:
    return ClientInfo(
        user_agent=(request.headers.get("user-agent") or "")[:500] or None,
        ip_address=_valid_ip(request.client.host if request.client else None),
    )


ClientInfoDep = Annotated[ClientInfo, Depends(get_client_info)]


async def get_principal(
    request: Request,
    jwt: Annotated[JWTService, Depends(get_jwt_service)],
    session: SessionDep,
    x_organization_id: Annotated[str | None, Header()] = None,
) -> Principal:
    header = request.headers.get("authorization")
    if not header or not header.lower().startswith("bearer "):
        raise AuthenticationRequiredError("Provide a bearer token.")

    try:
        claims = jwt.verify(header.split(" ", 1)[1].strip())
    except InvalidTokenError as exc:
        raise AuthenticationRequiredError(str(exc)) from exc

    organization_id = claims.organization_id
    role = claims.role

    # Switching organization is re-verified against the database rather than
    # trusted from the header. The token proves who you are; it does not prove
    # you are a member of whichever organization you name in a header.
    if x_organization_id:
        try:
            requested = uuid.UUID(x_organization_id)
        except ValueError as exc:
            raise AuthenticationRequiredError("Invalid organization identifier.") from exc

        if requested != organization_id:
            membership = await MembershipRepository(session).get(requested, claims.user_id)
            if membership is None:
                # 403, not 404: the caller is authenticated, and the resource
                # here is their own membership, so no existence is leaked.
                raise PermissionDeniedError("You are not a member of that organization.")
            organization_id = requested
            role = membership.role

    return Principal(
        kind=PrincipalKind.USER,
        subject_id=claims.user_id,
        organization_id=organization_id,
        role=role,
    )


PrincipalDep = Annotated[Principal, Depends(get_principal)]


def require(
    *permissions: Permission,
) -> Callable[[Principal], Coroutine[Any, Any, Principal]]:
    """Guard an endpoint with one or more permissions (all required)."""

    async def _guard(principal: PrincipalDep) -> Principal:
        missing = [p for p in permissions if not principal.can(p)]
        if missing:
            raise PermissionDeniedError(
                "Your role does not permit this action: " + ", ".join(p.value for p in missing)
            )
        return principal

    return _guard
