"""Conduit — AI workflow automation platform."""

__version__ = "0.1.0"
