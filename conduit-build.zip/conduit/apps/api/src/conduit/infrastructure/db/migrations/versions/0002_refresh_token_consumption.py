"""Track refresh token consumption for reuse detection.

Revision ID: 0002
Revises: 0001
Create Date: 2026-08-05
"""

from __future__ import annotations

from collections.abc import Sequence

import sqlalchemy as sa
from alembic import op
from sqlalchemy.dialects import postgresql

revision: str = "0002"
down_revision: str | None = "0001"
branch_labels: str | Sequence[str] | None = None
depends_on: str | Sequence[str] | None = None


def upgrade() -> None:
    op.add_column(
        "refresh_tokens",
        sa.Column("consumed_at", postgresql.TIMESTAMP(timezone=True), nullable=True),
    )
    # Partial index: the refresh path only ever looks up live tokens, and the
    # table accumulates dead rows quickly at one row per refresh.
    op.create_index(
        "ix_refresh_tokens_live",
        "refresh_tokens",
        ["token_hash"],
        postgresql_where=sa.text("revoked_at IS NULL AND consumed_at IS NULL"),
    )


def downgrade() -> None:
    op.drop_index("ix_refresh_tokens_live", table_name="refresh_tokens")
    op.drop_column("refresh_tokens", "consumed_at")
