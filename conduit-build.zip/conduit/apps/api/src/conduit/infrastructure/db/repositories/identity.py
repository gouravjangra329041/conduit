"""Identity repositories.

Data access only — no policy decisions. Every method that touches a
tenant-scoped table takes an `organization_id` as a required argument rather
than an optional filter, so forgetting tenant scoping is a type error at the
call site rather than a silent cross-tenant read.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import Any

from sqlalchemy import CursorResult, func, select, update
from sqlalchemy.ext.asyncio import AsyncSession

from conduit.domain.identity import Role
from conduit.infrastructure.db.models.identity import (
    Membership,
    Organization,
    RefreshToken,
    User,
)


class UserRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_id(self, user_id: uuid.UUID) -> User | None:
        return await self._session.get(User, user_id)

    async def get_by_email(self, email: str) -> User | None:
        result = await self._session.execute(select(User).where(User.email == email))
        return result.scalar_one_or_none()

    async def email_exists(self, email: str) -> bool:
        result = await self._session.execute(
            select(func.count()).select_from(User).where(User.email == email)
        )
        return (result.scalar_one() or 0) > 0

    def add(self, user: User) -> User:
        self._session.add(user)
        return user

    async def touch_login(self, user_id: uuid.UUID) -> None:
        await self._session.execute(
            update(User).where(User.id == user_id).values(last_login_at=datetime.now(UTC))
        )

    async def update_password_hash(self, user_id: uuid.UUID, password_hash: str) -> None:
        await self._session.execute(
            update(User).where(User.id == user_id).values(password_hash=password_hash)
        )


class OrganizationRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_id(self, organization_id: uuid.UUID) -> Organization | None:
        return await self._session.get(Organization, organization_id)

    async def slug_exists(self, slug: str) -> bool:
        result = await self._session.execute(
            select(func.count()).select_from(Organization).where(Organization.slug == slug)
        )
        return (result.scalar_one() or 0) > 0

    def add(self, organization: Organization) -> Organization:
        self._session.add(organization)
        return organization


class MembershipRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get(self, organization_id: uuid.UUID, user_id: uuid.UUID) -> Membership | None:
        result = await self._session.execute(
            select(Membership).where(
                Membership.organization_id == organization_id,
                Membership.user_id == user_id,
            )
        )
        return result.scalar_one_or_none()

    async def list_for_user(self, user_id: uuid.UUID) -> list[Membership]:
        result = await self._session.execute(
            select(Membership).where(Membership.user_id == user_id)
        )
        return list(result.scalars().all())

    async def list_for_organization(self, organization_id: uuid.UUID) -> list[Membership]:
        result = await self._session.execute(
            select(Membership).where(Membership.organization_id == organization_id)
        )
        return list(result.scalars().all())

    async def count_owners(self, organization_id: uuid.UUID) -> int:
        result = await self._session.execute(
            select(func.count())
            .select_from(Membership)
            .where(
                Membership.organization_id == organization_id,
                Membership.role == Role.OWNER,
            )
        )
        return result.scalar_one() or 0

    def add(self, membership: Membership) -> Membership:
        self._session.add(membership)
        return membership

    async def delete(self, membership: Membership) -> None:
        await self._session.delete(membership)


class RefreshTokenRepository:
    def __init__(self, session: AsyncSession) -> None:
        self._session = session

    async def get_by_hash(self, token_hash: bytes) -> RefreshToken | None:
        result = await self._session.execute(
            select(RefreshToken).where(RefreshToken.token_hash == token_hash)
        )
        return result.scalar_one_or_none()

    def add(self, token: RefreshToken) -> RefreshToken:
        self._session.add(token)
        return token

    async def revoke(self, token_id: uuid.UUID) -> None:
        await self._session.execute(
            update(RefreshToken)
            .where(RefreshToken.id == token_id, RefreshToken.revoked_at.is_(None))
            .values(revoked_at=datetime.now(UTC))
        )

    async def consume(self, token_id: uuid.UUID) -> bool:
        """Mark a token as exchanged.

        Guarded on `consumed_at IS NULL` so two concurrent refreshes with the
        same token cannot both succeed — the database, not application logic,
        decides the winner. Returns False if it was already consumed.
        """
        result: CursorResult[Any] = await self._session.execute(  # type: ignore[assignment]
            update(RefreshToken)
            .where(RefreshToken.id == token_id, RefreshToken.consumed_at.is_(None))
            .values(consumed_at=datetime.now(UTC))
        )
        return (result.rowcount or 0) == 1

    async def revoke_family(self, family_id: uuid.UUID) -> int:
        """Revoke every live token in a family. Used on reuse detection."""
        result: CursorResult[Any] = await self._session.execute(  # type: ignore[assignment]
            update(RefreshToken)
            .where(
                RefreshToken.family_id == family_id,
                RefreshToken.revoked_at.is_(None),
            )
            .values(revoked_at=datetime.now(UTC))
        )
        return result.rowcount or 0

    async def revoke_all_for_user(self, user_id: uuid.UUID) -> int:
        result: CursorResult[Any] = await self._session.execute(  # type: ignore[assignment]
            update(RefreshToken)
            .where(RefreshToken.user_id == user_id, RefreshToken.revoked_at.is_(None))
            .values(revoked_at=datetime.now(UTC))
        )
        return result.rowcount or 0
