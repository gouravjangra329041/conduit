"""SQLAlchemy models.

Every model module must be imported here so Alembic autogenerate sees the
full metadata. A model that is not imported is silently invisible to
migrations — a failure mode that only surfaces in production.
"""

from conduit.domain.identity.roles import Role
from conduit.infrastructure.db.base import Base
from conduit.infrastructure.db.models.identity import (
    ApiKey,
    AuditLog,
    Membership,
    Organization,
    RefreshToken,
    User,
)

__all__ = [
    "ApiKey",
    "AuditLog",
    "Base",
    "Membership",
    "Organization",
    "RefreshToken",
    "Role",
    "User",
]
