"""Secret redaction for the logging pipeline.

This processor is not bypassable and not opt-in. Two layers:

1. Key-based — any log key whose name looks secret is masked.
2. Value-based — concrete secret values registered at credential-decrypt
   time are masked wherever they appear, including inside nested payloads
   and free-text error strings.

Layer 2 is the important one. Layer 1 alone fails the moment a credential
is interpolated into a URL or echoed back inside an upstream error message.
"""

from __future__ import annotations

from contextvars import ContextVar
from typing import Any

MASK = "***REDACTED***"

SENSITIVE_KEYS: frozenset[str] = frozenset(
    {
        "password",
        "passwd",
        "secret",
        "token",
        "api_key",
        "apikey",
        "authorization",
        "auth",
        "credential",
        "credentials",
        "private_key",
        "access_token",
        "refresh_token",
        "client_secret",
        "session",
        "cookie",
        "kek",
        "dek",
        "signature",
        "x-api-key",
    }
)

# Minimum length before a registered value is masked by substring match.
# Short secrets would otherwise mask innocuous text everywhere.
_MIN_MASKABLE_LENGTH = 8

_active_secrets: ContextVar[frozenset[str]] = ContextVar("active_secrets", default=frozenset())


def register_secrets(*values: str | None) -> None:
    """Register decrypted secret values for masking in the current context."""
    additions = {v for v in values if v and len(v) >= _MIN_MASKABLE_LENGTH}
    if additions:
        _active_secrets.set(_active_secrets.get() | additions)


def _is_sensitive_key(key: str) -> bool:
    lowered = key.lower()
    return any(marker in lowered for marker in SENSITIVE_KEYS)


def _is_maskable(value: Any) -> bool:
    """Only str and bytes can carry a secret.

    Without this, a diagnostic like `tokens_revoked=3` is masked purely
    because its key contains "token", and operators lose the numbers they
    need during an incident. Over-redaction erodes trust in the logs and
    pushes people toward disabling redaction entirely.
    """
    return isinstance(value, (str, bytes))


def _mask_value(value: str) -> str:
    for secret in _active_secrets.get():
        if secret in value:
            value = value.replace(secret, MASK)
    return value


def scrub(value: Any, *, _depth: int = 0) -> Any:
    """Recursively redact a value. Safe for arbitrary JSON-ish structures."""
    if _depth > 12:
        return "<max-depth>"
    if isinstance(value, str):
        return _mask_value(value)
    if isinstance(value, dict):
        return {
            k: MASK
            if (_is_sensitive_key(str(k)) and _is_maskable(v))
            else scrub(v, _depth=_depth + 1)
            for k, v in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [scrub(v, _depth=_depth + 1) for v in value]
    return value


def redaction_processor(_logger: Any, _method: str, event_dict: dict[str, Any]) -> dict[str, Any]:
    return {
        key: MASK if (_is_sensitive_key(key) and _is_maskable(val)) else scrub(val)
        for key, val in event_dict.items()
    }
