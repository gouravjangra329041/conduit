"""Structured logging setup.

Application logs only — user-facing execution logs are a separate stream
stored in Postgres (see ARCHITECTURE.md §10.1). Conflating them makes tenant
isolation a query-filter problem instead of a schema problem, and gets
expensive fast at volume.

Everything routes through the stdlib root handler via `ProcessorFormatter`.
That indirection is deliberate: it means logs from uvicorn, SQLAlchemy and
Alembic pass through the *same* processor chain — including redaction — as
our own. A parallel pipeline for third-party logs is how secrets escape.
"""

from __future__ import annotations

import logging
import sys
from typing import Any

import structlog

from conduit.config import TelemetrySettings

from .context import snapshot
from .redaction import redaction_processor


def _correlation_processor(
    _logger: Any, _method: str, event_dict: dict[str, Any]
) -> dict[str, Any]:
    """Merge bound correlation IDs into every event."""
    for key, value in snapshot().items():
        event_dict.setdefault(key, value)
    return event_dict


def configure_logging(settings: TelemetrySettings, *, service: str, version: str) -> None:
    # Applied to events from both structlog and stdlib loggers.
    shared: list[Any] = [
        structlog.contextvars.merge_contextvars,
        _correlation_processor,
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
        # Redaction runs last among transforms, immediately before rendering,
        # so nothing added by an earlier processor can slip past it.
        redaction_processor,
    ]

    renderer: Any = (
        structlog.processors.JSONRenderer()
        if settings.log_format == "json"
        else structlog.dev.ConsoleRenderer(colors=True)
    )

    structlog.configure(
        processors=[
            *shared,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        wrapper_class=structlog.make_filtering_bound_logger(
            logging.getLevelNamesMapping()[settings.log_level]
        ),
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )

    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared,
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            structlog.processors.format_exc_info,
            renderer,
        ],
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root = logging.getLogger()
    root.handlers = [handler]
    root.setLevel(settings.log_level)

    # uvicorn installs its own handlers; clear them so records reach our root
    # handler exactly once instead of being emitted twice in two formats.
    for name in ("uvicorn", "uvicorn.error", "uvicorn.access", "sqlalchemy.engine.Engine"):
        third_party = logging.getLogger(name)
        third_party.handlers.clear()
        third_party.propagate = True

    structlog.contextvars.clear_contextvars()
    structlog.contextvars.bind_contextvars(service=service, version=version)


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    return structlog.get_logger(name)  # type: ignore[no-any-return]
