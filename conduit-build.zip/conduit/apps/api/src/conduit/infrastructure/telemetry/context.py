"""Correlation context.

Correlation IDs are bound once at the edge (HTTP middleware or worker run
claim) and inherited automatically by every log line emitted downstream.
They are never threaded through function signatures by hand — that approach
always develops gaps, and a gap in a correlation ID is an unreadable incident.
"""

from __future__ import annotations

import uuid
from contextvars import ContextVar, Token
from dataclasses import dataclass, field
from typing import Any

_request_id: ContextVar[str | None] = ContextVar("request_id", default=None)
_organization_id: ContextVar[str | None] = ContextVar("organization_id", default=None)
_user_id: ContextVar[str | None] = ContextVar("user_id", default=None)
_run_id: ContextVar[str | None] = ContextVar("run_id", default=None)
_node_id: ContextVar[str | None] = ContextVar("node_id", default=None)
_node_execution_id: ContextVar[str | None] = ContextVar("node_execution_id", default=None)

_VARS: dict[str, ContextVar[str | None]] = {
    "request_id": _request_id,
    "organization_id": _organization_id,
    "user_id": _user_id,
    "run_id": _run_id,
    "node_id": _node_id,
    "node_execution_id": _node_execution_id,
}


def new_request_id() -> str:
    return uuid.uuid4().hex


def current_request_id() -> str | None:
    return _request_id.get()


def snapshot() -> dict[str, Any]:
    """All currently bound correlation values, omitting unset ones."""
    return {name: var.get() for name, var in _VARS.items() if var.get() is not None}


@dataclass(slots=True)
class _Binding:
    tokens: list[tuple[ContextVar[str | None], Token[str | None]]] = field(default_factory=list)

    def __enter__(self) -> _Binding:
        return self

    def __exit__(self, *_exc: object) -> None:
        for var, token in reversed(self.tokens):
            var.reset(token)


def bind(**values: str | None) -> _Binding:
    """Bind correlation values for the enclosing scope.

    Usage:
        with bind(run_id=str(run.id), organization_id=str(run.organization_id)):
            ...
    """
    binding = _Binding()
    for name, value in values.items():
        if value is None:
            continue
        var = _VARS.get(name)
        if var is None:
            raise KeyError(f"Unknown correlation field: {name!r}")
        binding.tokens.append((var, var.set(value)))
    return binding
