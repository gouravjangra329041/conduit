"""Password hashing.

Argon2id, the current password-hashing recommendation. Two properties matter
beyond the algorithm choice:

1. `verify_dummy()` exists so the login path costs the same whether or not the
   email exists. Without it, response timing tells an attacker which addresses
   are registered — an enumeration oracle that no amount of careful error
   wording can close.
2. `needs_rehash()` lets cost parameters be raised later; users are upgraded
   transparently on their next successful login.
"""

from __future__ import annotations

import contextlib

from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerificationError, VerifyMismatchError

from conduit.config import SecuritySettings

# Precomputed hash of a value nobody can log in with, used to burn equivalent
# CPU time on the "user not found" branch.
_DUMMY_PASSWORD = "conduit-timing-equalisation-placeholder"  # noqa: S105

MIN_PASSWORD_LENGTH = 12
MAX_PASSWORD_LENGTH = 256


class PasswordHashingError(Exception):
    pass


class PasswordService:
    def __init__(self, settings: SecuritySettings) -> None:
        self._hasher = PasswordHasher(
            time_cost=settings.password_hash_time_cost,
            memory_cost=settings.password_hash_memory_cost_kib,
            parallelism=settings.password_hash_parallelism,
        )
        self._dummy_hash = self._hasher.hash(_DUMMY_PASSWORD)

    def hash(self, password: str) -> str:
        return self._hasher.hash(password)

    def verify(self, password_hash: str, password: str) -> bool:
        try:
            self._hasher.verify(password_hash, password)
        except (VerifyMismatchError, VerificationError, InvalidHashError):
            return False
        return True

    def verify_dummy(self) -> None:
        """Burn the same CPU as a real verification. Never raises."""
        # Suppressing is the point: the CPU cost is the desired effect and
        # the result is meaningless.
        with contextlib.suppress(Exception):
            self._hasher.verify(self._dummy_hash, "definitely-not-the-password")

    def needs_rehash(self, password_hash: str) -> bool:
        try:
            return self._hasher.check_needs_rehash(password_hash)
        except InvalidHashError:
            return True
