"""Access-token signing and verification.

RS256 in production, so workers and any future service can verify tokens with
the public key alone and never hold the signing key. Local development falls
back to HS256 with a development secret — `Settings.assert_production_ready()`
refuses to boot production in that state, so the convenience cannot escape.

Access tokens are short-lived and deliberately *not* revocable. Revocation
lives on the refresh token, which is persisted. Trying to make both stateless
and revocable is how people end up querying a denylist on every request and
losing the only benefit stateless tokens had.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from typing import Any, Final

import jwt

from conduit.config import SecuritySettings
from conduit.domain.identity import (
    InvalidTokenError,
    Role,
    TokenExpiredError,
)
from conduit.infrastructure.telemetry import get_logger

logger = get_logger(__name__)

ISSUER: Final[str] = "conduit"
AUDIENCE: Final[str] = "conduit-api"
_LEEWAY_SECONDS: Final[int] = 30


@dataclass(frozen=True, slots=True)
class AccessTokenClaims:
    user_id: uuid.UUID
    organization_id: uuid.UUID
    role: Role
    token_id: uuid.UUID
    expires_at: datetime


class JWTService:
    def __init__(self, settings: SecuritySettings, *, is_production: bool) -> None:
        self._settings = settings
        self._ttl = timedelta(seconds=settings.access_token_ttl_s)

        use_rsa = (
            settings.jwt_algorithm == "RS256"
            and settings.jwt_private_key is not None
            and settings.jwt_public_key is not None
        )
        if use_rsa:
            assert settings.jwt_private_key is not None
            assert settings.jwt_public_key is not None
            self._algorithm = "RS256"
            self._signing_key: str = settings.jwt_private_key.get_secret_value()
            self._verify_key: str = settings.jwt_public_key.get_secret_value()
        else:
            if is_production:
                raise RuntimeError(
                    "Production requires SECURITY_JWT_PRIVATE_KEY and "
                    "SECURITY_JWT_PUBLIC_KEY with RS256"
                )
            self._algorithm = "HS256"
            self._signing_key = settings.jwt_dev_secret.get_secret_value()
            self._verify_key = self._signing_key
            logger.warning(
                "jwt_using_development_signing",
                detail="HS256 with a shared development secret; not valid for production",
            )

    def issue(
        self, *, user_id: uuid.UUID, organization_id: uuid.UUID, role: Role
    ) -> tuple[str, datetime]:
        now = datetime.now(UTC)
        expires_at = now + self._ttl
        payload: dict[str, Any] = {
            "iss": ISSUER,
            "aud": AUDIENCE,
            "sub": str(user_id),
            "org": str(organization_id),
            "role": role.value,
            "jti": str(uuid.uuid4()),
            "iat": int(now.timestamp()),
            "exp": int(expires_at.timestamp()),
        }
        return jwt.encode(payload, self._signing_key, algorithm=self._algorithm), expires_at

    def verify(self, token: str) -> AccessTokenClaims:
        try:
            payload = jwt.decode(
                token,
                self._verify_key,
                # Pinning the algorithm list is essential. Accepting whatever
                # the token's header claims is the classic JWT confusion
                # attack — an attacker re-signs with "none" or with HS256
                # using the public key as the shared secret.
                algorithms=[self._algorithm],
                audience=AUDIENCE,
                issuer=ISSUER,
                leeway=_LEEWAY_SECONDS,
                options={"require": ["exp", "iat", "sub", "org", "role", "jti"]},
            )
        except jwt.ExpiredSignatureError as exc:
            raise TokenExpiredError("Access token has expired") from exc
        except jwt.InvalidTokenError as exc:
            raise InvalidTokenError("Access token is invalid") from exc

        try:
            return AccessTokenClaims(
                user_id=uuid.UUID(payload["sub"]),
                organization_id=uuid.UUID(payload["org"]),
                role=Role(payload["role"]),
                token_id=uuid.UUID(payload["jti"]),
                expires_at=datetime.fromtimestamp(payload["exp"], tz=UTC),
            )
        except (ValueError, KeyError) as exc:
            raise InvalidTokenError("Access token claims are malformed") from exc
