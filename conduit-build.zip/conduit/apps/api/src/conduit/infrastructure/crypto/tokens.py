"""Opaque token generation and hashing.

Refresh tokens and API keys are random secrets, not signed claims. They are
stored as SHA-256 digests so a database dump does not yield usable
credentials, and compared in constant time so comparison latency does not leak
digest content.

SHA-256 rather than Argon2 here, deliberately: these are 256-bit random values,
not user-chosen passwords. There is no dictionary to attack, so key stretching
buys nothing and would add real cost to every authenticated request.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets

REFRESH_TOKEN_BYTES = 32
API_KEY_BYTES = 32
API_KEY_PREFIX = "cdt"
_PREFIX_DISPLAY_LENGTH = 8


def generate_token(n_bytes: int = REFRESH_TOKEN_BYTES) -> str:
    return secrets.token_urlsafe(n_bytes)


def hash_token(token: str) -> bytes:
    return hashlib.sha256(token.encode("utf-8")).digest()


def verify_token(token: str, expected_hash: bytes) -> bool:
    return hmac.compare_digest(hash_token(token), expected_hash)


def generate_api_key() -> tuple[str, str, bytes]:
    """Return (full_key, display_prefix, hash).

    The full key is shown to the user exactly once. The prefix is stored in
    clear so keys can be identified in a list UI and looked up cheaply without
    scanning every hash.
    """
    secret = secrets.token_urlsafe(API_KEY_BYTES)
    full_key = f"{API_KEY_PREFIX}_{secret}"
    return full_key, full_key[:_PREFIX_DISPLAY_LENGTH], hash_token(full_key)
