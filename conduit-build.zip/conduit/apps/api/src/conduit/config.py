"""Application configuration.

Single source of truth for every runtime setting. Values come from the
environment; nothing is hardcoded per-environment and nothing is read from
`os.environ` anywhere else in the codebase.
"""

from __future__ import annotations

from functools import lru_cache
from typing import Literal

from pydantic import Field, PostgresDsn, SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

Environment = Literal["local", "test", "staging", "production"]


class DatabaseSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="DB_")

    dsn: PostgresDsn = Field(
        default=PostgresDsn("postgresql+asyncpg://conduit:conduit@localhost:5432/conduit")
    )
    pool_size: int = 10
    max_overflow: int = 5
    pool_timeout_s: int = 30
    pool_recycle_s: int = 1800
    echo: bool = False


class StorageSettings(BaseSettings):
    """Payload storage. See ARCHITECTURE.md §0.4 — the PayloadRef indirection."""

    model_config = SettingsConfigDict(env_prefix="STORAGE_")

    backend: Literal["inline", "s3"] = "inline"
    inline_threshold_bytes: int = 64 * 1024
    max_payload_bytes: int = 16 * 1024 * 1024
    s3_endpoint_url: str | None = None
    s3_bucket: str = "conduit-payloads"
    s3_access_key: SecretStr | None = None
    s3_secret_key: SecretStr | None = None
    s3_region: str = "us-east-1"


class SecuritySettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="SECURITY_")

    # Access tokens are deliberately short-lived; revocation lives on the
    # refresh token, which is persisted and revocable. See ARCHITECTURE.md §11.8.
    access_token_ttl_s: int = 15 * 60
    refresh_token_ttl_s: int = 30 * 24 * 3600
    jwt_algorithm: Literal["RS256", "HS256"] = "RS256"
    jwt_private_key: SecretStr | None = None
    jwt_public_key: SecretStr | None = None
    jwt_dev_secret: SecretStr = SecretStr(
        # >= 32 bytes per RFC 7518 §3.2 for HS256. Local development only;
        # production requires RS256 keys and refuses to boot without them.
        "dev-only-not-for-production-hs256-signing-secret"
    )

    # Envelope encryption key for credentials (§11.3).
    credential_kek: SecretStr = SecretStr("dev-only-not-for-production-kek-32b")

    password_hash_time_cost: int = 3
    password_hash_memory_cost_kib: int = 65536
    password_hash_parallelism: int = 4


class EngineSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="ENGINE_")

    worker_id: str | None = None
    claim_batch_size: int = 10
    claim_poll_interval_s: float = 1.0
    lease_duration_s: int = 60
    lease_renew_margin_s: int = 20
    max_concurrent_runs_per_worker: int = 25

    # Guardrails against runaway graphs (NFR-11).
    max_steps_per_run: int = 1000
    max_loop_iterations: int = 1000

    # Delays shorter than this sleep inline; longer ones suspend the run
    # rather than occupying a worker. See ARCHITECTURE.md §0.2.
    inline_delay_threshold_s: float = 5.0

    default_node_timeout_s: float = 60.0


class EgressSettings(BaseSettings):
    """SSRF controls for outbound requests made by nodes. See §11.2."""

    model_config = SettingsConfigDict(env_prefix="EGRESS_")

    enabled: bool = True
    allow_private_networks: bool = False  # local dev may flip this ON deliberately
    max_redirects: int = 5
    connect_timeout_s: float = 10.0
    read_timeout_s: float = 30.0
    max_response_bytes: int = 16 * 1024 * 1024
    extra_denied_cidrs: list[str] = Field(default_factory=list)


class TelemetrySettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="TELEMETRY_")

    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"
    log_format: Literal["json", "console"] = "json"
    log_ai_payloads: bool = False  # prompts contain customer PII (§10.3)
    metrics_enabled: bool = True
    tracing_enabled: bool = False
    otlp_endpoint: str | None = None


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    environment: Environment = "local"
    service_name: str = "conduit"
    version: str = "0.1.0"

    api_host: str = "0.0.0.0"  # noqa: S104 — bound inside a container
    api_port: int = 8000
    api_root_path: str = ""
    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:3000"])

    database: DatabaseSettings = Field(default_factory=DatabaseSettings)
    storage: StorageSettings = Field(default_factory=StorageSettings)
    security: SecuritySettings = Field(default_factory=SecuritySettings)
    engine: EngineSettings = Field(default_factory=EngineSettings)
    egress: EgressSettings = Field(default_factory=EgressSettings)
    telemetry: TelemetrySettings = Field(default_factory=TelemetrySettings)

    @property
    def is_production(self) -> bool:
        return self.environment == "production"

    @field_validator("cors_origins", mode="before")
    @classmethod
    def _split_origins(cls, v: object) -> object:
        if isinstance(v, str):
            return [o.strip() for o in v.split(",") if o.strip()]
        return v

    def assert_production_ready(self) -> None:
        """Fail fast at startup rather than quietly running insecure in prod."""
        if not self.is_production:
            return
        problems: list[str] = []
        if self.security.jwt_algorithm == "RS256" and not self.security.jwt_private_key:
            problems.append("SECURITY_JWT_PRIVATE_KEY is required in production")
        if "dev-only" in self.security.credential_kek.get_secret_value():
            problems.append("SECURITY_CREDENTIAL_KEK must be set in production")
        if self.egress.allow_private_networks:
            problems.append("EGRESS_ALLOW_PRIVATE_NETWORKS must be false in production")
        if self.storage.backend == "inline":
            problems.append("STORAGE_BACKEND must be 's3' in production")
        if problems:
            raise RuntimeError("Unsafe production configuration:\n  - " + "\n  - ".join(problems))


@lru_cache
def get_settings() -> Settings:
    return Settings()
