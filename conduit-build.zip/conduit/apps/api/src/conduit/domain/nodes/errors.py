"""Node registry errors."""

from __future__ import annotations


class RegistryError(Exception):
    pass


class DuplicateNodeError(RegistryError):
    pass


class UnknownNodeError(RegistryError):
    pass


class RegistryFrozenError(RegistryError):
    pass


class InvalidNodeDefinitionError(RegistryError):
    pass
