"""Node registry.

Built once at process start from packaging entry points, then frozen. Three
properties matter:

1. **Frozen after startup.** A registry that can change at runtime means two
   requests can disagree about what a node is.
2. **Hashed.** Every replica computes the same hash from the same installed
   packages. A mismatch means a partial deploy — the API offering a node the
   workers cannot execute — and should fail readiness rather than surface as
   mysterious runtime errors.
3. **Discovered via entry points, not a directory scan.** The deployed node set
   is described by the lockfile, and nothing executes merely because it landed
   on disk.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Iterator
from importlib.metadata import entry_points
from typing import Any

from .contract import NodeCategory, NodeDefinition
from .errors import (
    DuplicateNodeError,
    InvalidNodeDefinitionError,
    RegistryFrozenError,
    UnknownNodeError,
)

ENTRY_POINT_GROUP = "conduit.nodes"


class NodeRegistry:
    def __init__(self) -> None:
        self._nodes: dict[str, NodeDefinition] = {}
        self._frozen = False

    # ------------------------------------------------------------ registration

    def add(self, definition: NodeDefinition | type[NodeDefinition]) -> None:
        if self._frozen:
            raise RegistryFrozenError("Cannot register nodes after startup")

        instance = definition() if isinstance(definition, type) else definition
        self._validate(instance)

        if instance.key in self._nodes:
            raise DuplicateNodeError(f"{instance.key} is already registered")
        self._nodes[instance.key] = instance

    def _validate(self, node: NodeDefinition) -> None:
        for attribute in ("type", "category", "display_name", "config_schema"):
            if not getattr(node, attribute, None):
                raise InvalidNodeDefinitionError(
                    f"{type(node).__name__} is missing required attribute {attribute!r}"
                )
        if not node.output_ports and node.category is not NodeCategory.ACTION:
            raise InvalidNodeDefinitionError(
                f"{node.key} declares no output ports and cannot be reached past"
            )
        if node.is_trigger and node.input_ports:
            raise InvalidNodeDefinitionError(
                f"{node.key} is a trigger and must not declare input ports"
            )
        names = [p.name for p in node.output_ports]
        if len(names) != len(set(names)):
            raise InvalidNodeDefinitionError(f"{node.key} has duplicate output port names")

    def freeze(self) -> None:
        self._frozen = True

    @property
    def is_frozen(self) -> bool:
        return self._frozen

    # ---------------------------------------------------------------- querying

    def get(self, node_type: str, version: int) -> NodeDefinition:
        try:
            return self._nodes[f"{node_type}@{version}"]
        except KeyError as exc:
            raise UnknownNodeError(f"{node_type}@{version} is not registered") from exc

    def latest(self, node_type: str) -> NodeDefinition:
        candidates = [n for n in self._nodes.values() if n.type == node_type]
        if not candidates:
            raise UnknownNodeError(f"{node_type} is not registered")
        return max(candidates, key=lambda n: n.version)

    def has(self, node_type: str, version: int) -> bool:
        return f"{node_type}@{version}" in self._nodes

    def __iter__(self) -> Iterator[NodeDefinition]:
        return iter(sorted(self._nodes.values(), key=lambda n: (n.category, n.type)))

    def __len__(self) -> int:
        return len(self._nodes)

    # ----------------------------------------------------------------- catalog

    def describe(self, node: NodeDefinition) -> dict[str, Any]:
        """Serialise a node for the catalog API.

        The JSON Schema in here is what the editor renders config forms from,
        which is why adding a node requires no frontend change.
        """
        return {
            "type": node.type,
            "version": node.version,
            "key": node.key,
            "category": node.category.value,
            "display_name": node.display_name,
            "description": node.description,
            "icon": node.icon,
            "is_trigger": node.is_trigger,
            "credential_type": node.credential_type,
            "default_timeout_s": node.default_timeout_s,
            "config_schema": node.config_schema.model_json_schema(),
            "input_ports": [
                {"name": p.name, "label": p.label, "kind": p.kind.value} for p in node.input_ports
            ],
            "output_ports": [
                {
                    "name": p.name,
                    "label": p.label,
                    "kind": p.kind.value,
                    "description": p.description,
                }
                for p in node.output_ports
            ],
        }

    def catalog(self) -> list[dict[str, Any]]:
        return [self.describe(node) for node in self]

    def fingerprint(self) -> str:
        """Stable hash of the registered node set and their schemas."""
        material = json.dumps(self.catalog(), sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(material.encode("utf-8")).hexdigest()[:16]


def build_registry() -> NodeRegistry:
    """Discover every installed node pack and return a frozen registry."""
    registry = NodeRegistry()
    for entry_point in entry_points(group=ENTRY_POINT_GROUP):
        entry_point.load()(registry)
    registry.freeze()
    return registry
