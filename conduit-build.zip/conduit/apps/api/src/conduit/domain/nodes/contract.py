"""The node contract.

This is the entire public surface a node author touches. Everything the
engine knows about a node is expressed here, which is what allows new node
types to be added without the engine changing: the engine branches on the
*result variant*, never on the node type.

Pure domain — no framework, no I/O. `NodeContext` is declared as a Protocol so
the domain can describe what a node is handed without depending on the
infrastructure that supplies it.
"""

from __future__ import annotations

import enum
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel

# Aliased at module scope, where `type` is still the builtin. Inside
# NodeDefinition the class attribute `type: str` shadows it, so a later
# annotation of `type[BaseModel]` would resolve to the attribute instead.
ConfigSchema = type[BaseModel]


class NodeCategory(enum.StrEnum):
    TRIGGER = "trigger"
    ACTION = "action"
    LOGIC = "logic"
    TRANSFORM = "transform"


class PortKind(enum.StrEnum):
    MAIN = "main"
    # Taken when the node fails and its failure policy is `error_output`.
    ERROR = "error"


@dataclass(frozen=True, slots=True)
class Port:
    name: str
    label: str
    kind: PortKind = PortKind.MAIN
    description: str | None = None


@dataclass(frozen=True, slots=True)
class RetryPolicy:
    max_attempts: int = 3
    initial_delay_s: float = 1.0
    multiplier: float = 2.0
    max_delay_s: float = 60.0
    # Full jitter is not optional. Without it, a thousand runs failing against
    # the same host retry in lockstep and hammer it back down.
    jitter: bool = True

    def delay_for(self, attempt: int) -> float:
        raw = self.initial_delay_s * (self.multiplier ** max(0, attempt - 1))
        return min(raw, self.max_delay_s)


class FailurePolicy(enum.StrEnum):
    STOP = "stop"
    CONTINUE = "continue"
    ERROR_OUTPUT = "error_output"


# --------------------------------------------------------------------- results


@dataclass(frozen=True, slots=True)
class Success:
    """One payload per output port. Arrays are values, not fan-out signals."""

    outputs: dict[str, Any] = field(default_factory=dict)


class SuspendKind(enum.StrEnum):
    TIMER = "timer"
    EVENT = "event"


@dataclass(frozen=True, slots=True)
class Suspend:
    """Park the run without occupying a worker.

    Only Delay uses this in the MVP, but it is the same primitive that later
    powers wait-for-approval and wait-for-webhook — which makes those node
    additions rather than engine changes.
    """

    kind: SuspendKind
    resume_at: datetime | None = None
    resume_token: str | None = None


@dataclass(frozen=True, slots=True)
class Failure:
    message: str
    error_class: str = "PermanentError"
    retryable: bool = False
    details: dict[str, Any] = field(default_factory=dict)


NodeResult = Success | Suspend | Failure


# --------------------------------------------------------------------- context


@dataclass(frozen=True, slots=True)
class RunInfo:
    id: uuid.UUID
    workflow_id: uuid.UUID
    organization_id: uuid.UUID


@dataclass(frozen=True, slots=True)
class NodeInfo:
    id: str
    name: str
    type: str
    version: int


@runtime_checkable
class NodeContext(Protocol):
    """A node's only access to the outside world.

    Note what is absent: no database session, no queue handle, no filesystem,
    no raw sockets. A badly written node cannot corrupt run state, leak across
    tenants, or exhaust the connection pool, because it never holds the objects
    that would let it. The boundary is enforced by what is passed in, not by
    convention.
    """

    config: BaseModel
    input: dict[str, Any]
    run: RunInfo
    node: NodeInfo
    idempotency_key: str
    cancelled: bool
    deadline: datetime


# ------------------------------------------------------------------ definition


class NodeDefinition:
    """Base class for every node type.

    Subclasses set the class attributes and implement `execute`. Identity is
    `type@version`: a breaking schema change ships a new version and leaves the
    old one registered, because saved workflows reference it forever.
    """

    type: str
    version: int = 1
    category: NodeCategory
    display_name: str
    description: str = ""
    icon: str = "circle"
    config_schema: ConfigSchema
    credential_type: str | None = None
    default_timeout_s: float = 60.0
    default_retry_policy: RetryPolicy = RetryPolicy()

    input_ports: tuple[Port, ...] = (Port(name="in", label="In"),)
    output_ports: tuple[Port, ...] = (Port(name="out", label="Out"),)

    @property
    def key(self) -> str:
        return f"{self.type}@{self.version}"

    @property
    def is_trigger(self) -> bool:
        """Trigger-ness is a capability, not a hardcoded list in the engine."""
        return self.category is NodeCategory.TRIGGER

    async def execute(self, ctx: NodeContext) -> NodeResult:
        raise NotImplementedError

    def validate_config(self, config: BaseModel) -> None:
        """Optional save-time checks beyond the schema.

        Runs when a workflow is saved, so a bad URL or an unreachable
        credential is a validation error the author sees immediately rather
        than a runtime failure three days later.
        """
        return None
