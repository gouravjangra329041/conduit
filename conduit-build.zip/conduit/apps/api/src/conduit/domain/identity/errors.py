"""Domain-level identity errors.

Deliberately framework-free: the interface layer maps these to HTTP status
codes. The domain does not know what an HTTP status code is.
"""

from __future__ import annotations


class IdentityError(Exception):
    """Base for identity domain errors."""


class InvalidCredentialsError(IdentityError):
    """Wrong email or password.

    Intentionally one error for both cases. Distinguishing them turns the
    login endpoint into an account enumeration oracle.
    """


class AccountInactiveError(IdentityError):
    pass


class EmailAlreadyRegisteredError(IdentityError):
    pass


class SlugAlreadyTakenError(IdentityError):
    pass


class NotAMemberError(IdentityError):
    pass


class PermissionDeniedError(IdentityError):
    pass


class RoleAssignmentError(IdentityError):
    pass


class LastOwnerError(IdentityError):
    """Refused: an organization must always retain at least one owner."""


class InvalidTokenError(IdentityError):
    pass


class TokenExpiredError(InvalidTokenError):
    pass


class TokenReuseError(InvalidTokenError):
    """A refresh token was presented after it had already been rotated.

    Treated as theft, not as a mistake: the entire token family is revoked.
    """
