"""The authenticated caller.

One type for both humans and machines. Downstream authorisation code should
never branch on "is this a user or an API key" — it asks whether the caller
holds a permission within an organization, and the answer is the same shape
either way.
"""

from __future__ import annotations

import enum
import uuid
from dataclasses import dataclass

from .roles import Permission, Role, has_permission


class PrincipalKind(enum.StrEnum):
    USER = "user"
    API_KEY = "api_key"


@dataclass(frozen=True, slots=True)
class Principal:
    kind: PrincipalKind
    subject_id: uuid.UUID
    organization_id: uuid.UUID
    role: Role
    # API keys may be scoped more narrowly than their organization role.
    # `None` means "no additional narrowing".
    scopes: frozenset[Permission] | None = None

    @property
    def is_user(self) -> bool:
        return self.kind is PrincipalKind.USER

    def can(self, permission: Permission) -> bool:
        if not has_permission(self.role, permission):
            return False
        # Scopes can only ever subtract. A scope must never grant a permission
        # the underlying role lacks, or an API key becomes a privilege
        # escalation path.
        return self.scopes is None or permission in self.scopes
