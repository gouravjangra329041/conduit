"""Roles and permissions.

Pure policy. No database, no framework, no I/O — which means the entire
authorisation matrix is testable in milliseconds, and a permission bug is a
failing unit test rather than a production incident.

Authorisation is expressed as an explicit matrix rather than as scattered
`if role == "admin"` checks. Scattered checks drift: someone adds an endpoint,
copies the wrong guard, and nobody notices until a viewer deletes a workflow.
A single table can be read in one sitting and asserted against in one test.
"""

from __future__ import annotations

import enum
from types import MappingProxyType
from typing import Final


class Role(enum.StrEnum):
    OWNER = "owner"
    ADMIN = "admin"
    EDITOR = "editor"
    VIEWER = "viewer"


class Permission(enum.StrEnum):
    # Workflows
    WORKFLOW_READ = "workflow:read"
    WORKFLOW_WRITE = "workflow:write"
    WORKFLOW_DELETE = "workflow:delete"
    WORKFLOW_ACTIVATE = "workflow:activate"

    # Runs
    RUN_READ = "run:read"
    RUN_TRIGGER = "run:trigger"
    RUN_CANCEL = "run:cancel"

    # Credentials — separated from workflow editing on purpose. An editor
    # builds automations; handing them the secrets those automations use is a
    # different and larger grant.
    CREDENTIAL_READ = "credential:read"
    CREDENTIAL_WRITE = "credential:write"

    # Organization
    MEMBER_READ = "member:read"
    MEMBER_WRITE = "member:write"
    ORG_SETTINGS_WRITE = "org:settings:write"
    ORG_DELETE = "org:delete"

    # API keys
    API_KEY_READ = "api_key:read"
    API_KEY_WRITE = "api_key:write"


_VIEWER: Final[frozenset[Permission]] = frozenset(
    {
        Permission.WORKFLOW_READ,
        Permission.RUN_READ,
        Permission.MEMBER_READ,
    }
)

_EDITOR: Final[frozenset[Permission]] = _VIEWER | {
    Permission.WORKFLOW_WRITE,
    Permission.WORKFLOW_DELETE,
    Permission.WORKFLOW_ACTIVATE,
    Permission.RUN_TRIGGER,
    Permission.RUN_CANCEL,
    Permission.CREDENTIAL_READ,
}

_ADMIN: Final[frozenset[Permission]] = _EDITOR | {
    Permission.CREDENTIAL_WRITE,
    Permission.MEMBER_WRITE,
    Permission.ORG_SETTINGS_WRITE,
    Permission.API_KEY_READ,
    Permission.API_KEY_WRITE,
}

_OWNER: Final[frozenset[Permission]] = _ADMIN | {Permission.ORG_DELETE}

ROLE_PERMISSIONS: Final[MappingProxyType[Role, frozenset[Permission]]] = MappingProxyType(
    {
        Role.VIEWER: _VIEWER,
        Role.EDITOR: _EDITOR,
        Role.ADMIN: _ADMIN,
        Role.OWNER: _OWNER,
    }
)

# Roles are strictly nested here (viewer ⊂ editor ⊂ admin ⊂ owner). That is a
# deliberate simplification for the MVP: it keeps the mental model trivial.
# If a future role needs permissions outside this chain, the matrix stays
# expressive enough — only `role_rank` and this comment stop applying.
_RANK: Final[MappingProxyType[Role, int]] = MappingProxyType(
    {Role.VIEWER: 0, Role.EDITOR: 1, Role.ADMIN: 2, Role.OWNER: 3}
)


def permissions_for(role: Role) -> frozenset[Permission]:
    return ROLE_PERMISSIONS[role]


def has_permission(role: Role, permission: Permission) -> bool:
    return permission in ROLE_PERMISSIONS[role]


def role_rank(role: Role) -> int:
    return _RANK[role]


def can_assign_role(actor: Role, target: Role) -> bool:
    """Whether `actor` may grant or revoke `target`.

    A member may never grant a role above their own — otherwise an admin
    promotes themselves to owner and privilege escalation is a feature.
    Owners are the only role able to create other owners.
    """
    if not has_permission(actor, Permission.MEMBER_WRITE):
        return False
    return role_rank(actor) >= role_rank(target)
