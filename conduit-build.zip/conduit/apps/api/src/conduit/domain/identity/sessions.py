"""Refresh-token rotation policy.

Pure decision logic, deliberately separated from storage. Rotation with reuse
detection is the security-critical part of session handling, and it is exactly
the kind of logic that is painful to test when it is entangled with a database.
Here it is a function over a small record, so every branch is a unit test.

The model:

- Each login starts a token *family*.
- Every refresh rotates: the presented token is consumed, a new one issued
  into the same family.
- Presenting a token that was already consumed means two parties hold the
  same token — the legitimate user and a thief. We cannot tell which one is
  calling, so we revoke the whole family and force re-authentication.
"""

from __future__ import annotations

import enum
import uuid
from dataclasses import dataclass
from datetime import datetime


class RefreshOutcome(enum.StrEnum):
    ROTATE = "rotate"
    REJECT_EXPIRED = "reject_expired"
    REJECT_REVOKED = "reject_revoked"
    REVOKE_FAMILY = "revoke_family"


@dataclass(frozen=True, slots=True)
class StoredRefreshToken:
    id: uuid.UUID
    user_id: uuid.UUID
    family_id: uuid.UUID
    expires_at: datetime
    revoked_at: datetime | None
    consumed: bool


@dataclass(frozen=True, slots=True)
class RefreshDecision:
    outcome: RefreshOutcome
    family_id: uuid.UUID | None = None

    @property
    def is_success(self) -> bool:
        return self.outcome is RefreshOutcome.ROTATE


def decide_refresh(token: StoredRefreshToken, now: datetime) -> RefreshDecision:
    """Decide what to do with a presented refresh token.

    Order matters. Reuse is checked before expiry: a *stolen* token that has
    also expired is still evidence of compromise, and the family should be
    revoked rather than the request being dismissed as a routine timeout.
    """
    if token.consumed:
        return RefreshDecision(RefreshOutcome.REVOKE_FAMILY, token.family_id)
    if token.revoked_at is not None:
        return RefreshDecision(RefreshOutcome.REJECT_REVOKED, token.family_id)
    if token.expires_at <= now:
        return RefreshDecision(RefreshOutcome.REJECT_EXPIRED, token.family_id)
    return RefreshDecision(RefreshOutcome.ROTATE, token.family_id)
