"""Identifier generation.

UUIDv7 everywhere, not UUIDv4. v7 is time-ordered, so inserts land at the
right-hand edge of the B-tree instead of scattering across it. On the tables
that matter — `node_executions` above all — v4 causes index fragmentation and
write amplification that shows up as a mysterious throughput ceiling months in.
The ordering is also a free `created_at` for debugging.
"""

from __future__ import annotations

import uuid

import uuid_utils


def new_id() -> uuid.UUID:
    """Generate a time-ordered UUIDv7."""
    return uuid.UUID(str(uuid_utils.uuid7()))


def timestamp_of(value: uuid.UUID) -> int:
    """Milliseconds since epoch encoded in a UUIDv7. Returns 0 for other versions."""
    if value.version != 7:
        return 0
    return int.from_bytes(value.bytes[:6], byteorder="big")
