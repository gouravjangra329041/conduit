from __future__ import annotations

import asyncio
from collections.abc import Iterator

import pytest
from fastapi.testclient import TestClient
from sqlalchemy.ext.asyncio import create_async_engine

from conduit.config import Settings
from conduit.infrastructure.db.session import dispose_engine, init_engine
from conduit.interface.api.app import create_app


@pytest.fixture(scope="session")
def settings() -> Settings:
    s = Settings(environment="test")
    # Keep hashing cheap in tests; production cost comes from config.
    s.security.password_hash_time_cost = 1
    s.security.password_hash_memory_cost_kib = 8192
    s.security.password_hash_parallelism = 1
    return s


@pytest.fixture
def client(settings: Settings) -> TestClient:
    return TestClient(create_app(settings))


def _database_available(settings: Settings) -> bool:
    async def probe() -> bool:
        engine = create_async_engine(str(settings.database.dsn))
        try:
            async with engine.connect():
                return True
        except Exception:
            return False
        finally:
            await engine.dispose()

    try:
        return asyncio.run(probe())
    except Exception:
        return False


@pytest.fixture(scope="session")
def database_url(settings: Settings) -> str:
    """Skip database-backed tests when no PostgreSQL is running.

    Skipping rather than failing is deliberate: the security-critical logic
    lives in the pure domain and is covered without a database, so a developer
    with no local PostgreSQL still gets meaningful signal from `pytest`.
    """
    if not _database_available(settings):
        pytest.skip("PostgreSQL not available — start it to run integration tests")
    return str(settings.database.dsn)


@pytest.fixture
def db_client(settings: Settings, database_url: str) -> Iterator[TestClient]:
    init_engine(settings.database)
    with TestClient(create_app(settings)) as client:
        yield client
    asyncio.run(dispose_engine())
