"""End-to-end authentication behaviour.

Requires PostgreSQL with migrations applied:
    alembic upgrade head
Skipped automatically when no database is reachable.
"""

from __future__ import annotations

import uuid

from fastapi.testclient import TestClient

PASSWORD = "correct horse battery staple"


def _unique_email() -> str:
    return f"user-{uuid.uuid4().hex[:12]}@example.com"


def register(client: TestClient, email: str | None = None) -> dict[str, object]:
    response = client.post(
        "/api/v1/auth/register",
        json={
            "email": email or _unique_email(),
            "password": PASSWORD,
            "full_name": "Test Person",
            "organization_name": "Test Workspace",
        },
    )
    assert response.status_code == 201, response.text
    return response.json()


class TestRegistration:
    def test_creates_user_organization_and_session(self, db_client: TestClient) -> None:
        body = register(db_client)
        assert body["user"]["email"]
        assert body["organization"]["slug"]
        assert body["session"]["role"] == "owner"

    def test_refresh_token_is_httponly_and_not_in_the_body(self, db_client: TestClient) -> None:
        """The refresh token must be unreadable by JavaScript, which removes
        XSS-based session theft entirely."""
        email = _unique_email()
        response = db_client.post(
            "/api/v1/auth/register",
            json={
                "email": email,
                "password": PASSWORD,
                "full_name": None,
                "organization_name": "Cookie Test",
            },
        )
        assert "refresh_token" not in response.text
        cookie_header = response.headers.get("set-cookie", "")
        assert "conduit_refresh" in cookie_header
        assert "HttpOnly" in cookie_header
        assert "SameSite=lax" in cookie_header.replace("samesite", "SameSite")

    def test_duplicate_email_is_rejected(self, db_client: TestClient) -> None:
        email = _unique_email()
        register(db_client, email)
        response = db_client.post(
            "/api/v1/auth/register",
            json={
                "email": email,
                "password": PASSWORD,
                "full_name": None,
                "organization_name": "Second",
            },
        )
        assert response.status_code == 409

    def test_short_password_is_rejected(self, db_client: TestClient) -> None:
        response = db_client.post(
            "/api/v1/auth/register",
            json={
                "email": _unique_email(),
                "password": "short",
                "full_name": None,
                "organization_name": "Weak",
            },
        )
        assert response.status_code == 422


class TestLogin:
    def test_valid_credentials_succeed(self, db_client: TestClient) -> None:
        email = _unique_email()
        register(db_client, email)
        response = db_client.post("/api/v1/auth/login", json={"email": email, "password": PASSWORD})
        assert response.status_code == 200
        assert response.json()["access_token"]

    def test_unknown_and_wrong_password_are_indistinguishable(self, db_client: TestClient) -> None:
        """Different responses here would turn login into an account
        enumeration oracle."""
        email = _unique_email()
        register(db_client, email)

        wrong = db_client.post(
            "/api/v1/auth/login", json={"email": email, "password": "wrong-password-here"}
        )
        missing = db_client.post(
            "/api/v1/auth/login",
            json={"email": _unique_email(), "password": PASSWORD},
        )
        assert wrong.status_code == missing.status_code == 401
        assert wrong.json()["detail"] == missing.json()["detail"]


class TestSessionLifecycle:
    def test_me_requires_a_token(self, db_client: TestClient) -> None:
        assert db_client.get("/api/v1/auth/me").status_code == 401

    def test_me_returns_role_and_permissions(self, db_client: TestClient) -> None:
        body = register(db_client)
        token = body["session"]["access_token"]  # type: ignore[index]
        response = db_client.get("/api/v1/auth/me", headers={"Authorization": f"Bearer {token}"})
        assert response.status_code == 200
        payload = response.json()
        assert payload["role"] == "owner"
        assert "workflow:write" in payload["permissions"]
        assert "org:delete" in payload["permissions"]

    def test_garbage_token_is_rejected(self, db_client: TestClient) -> None:
        response = db_client.get(
            "/api/v1/auth/me", headers={"Authorization": "Bearer not-a-real-token"}
        )
        assert response.status_code == 401

    def test_refresh_rotates_the_token(self, db_client: TestClient) -> None:
        register(db_client)
        first = db_client.cookies.get("conduit_refresh")
        response = db_client.post("/api/v1/auth/refresh")
        assert response.status_code == 200
        assert db_client.cookies.get("conduit_refresh") != first

    def test_reusing_a_rotated_token_kills_the_session(self, db_client: TestClient) -> None:
        """The theft-detection path: presenting a consumed token means two
        parties hold it, so the whole family is revoked."""
        register(db_client)
        stolen = db_client.cookies.get("conduit_refresh")
        assert stolen

        assert db_client.post("/api/v1/auth/refresh").status_code == 200

        replay = db_client.post("/api/v1/auth/refresh", cookies={"conduit_refresh": stolen})
        assert replay.status_code == 401

        # And the legitimate holder is logged out too — we cannot tell the
        # thief from the victim, so both must re-authenticate.
        assert db_client.post("/api/v1/auth/refresh").status_code == 401

    def test_logout_invalidates_refresh(self, db_client: TestClient) -> None:
        register(db_client)
        assert db_client.post("/api/v1/auth/logout").status_code == 204
        assert db_client.post("/api/v1/auth/refresh").status_code == 401


class TestAuthorization:
    def test_members_endpoint_requires_authentication(self, db_client: TestClient) -> None:
        assert db_client.get("/api/v1/organizations/current/members").status_code == 401

    def test_owner_can_list_members(self, db_client: TestClient) -> None:
        body = register(db_client)
        token = body["session"]["access_token"]  # type: ignore[index]
        response = db_client.get(
            "/api/v1/organizations/current/members",
            headers={"Authorization": f"Bearer {token}"},
        )
        assert response.status_code == 200
        assert len(response.json()) == 1

    def test_cannot_switch_to_an_organization_you_do_not_belong_to(
        self, db_client: TestClient
    ) -> None:
        """The token proves identity. It does not prove membership of whatever
        organization a header names."""
        body = register(db_client)
        token = body["session"]["access_token"]  # type: ignore[index]
        other = register(db_client)
        other_org = other["organization"]["id"]  # type: ignore[index]

        response = db_client.get(
            "/api/v1/auth/me",
            headers={
                "Authorization": f"Bearer {token}",
                "X-Organization-Id": str(other_org),
            },
        )
        assert response.status_code == 403

    def test_last_owner_cannot_be_demoted(self, db_client: TestClient) -> None:
        body = register(db_client)
        token = body["session"]["access_token"]  # type: ignore[index]
        user_id = body["user"]["id"]  # type: ignore[index]

        response = db_client.patch(
            f"/api/v1/organizations/current/members/{user_id}",
            headers={"Authorization": f"Bearer {token}"},
            json={"role": "viewer"},
        )
        assert response.status_code == 409


class TestReuseRevocationDurability:
    def test_revocation_survives_the_error_response(self, db_client: TestClient) -> None:
        """Regression: the 401 raised on reuse detection unwound the request
        transaction and rolled back the revocation itself. The security action
        must outlive the failure that triggered it."""
        register(db_client)
        stolen = db_client.cookies.get("conduit_refresh")
        assert stolen

        db_client.post("/api/v1/auth/refresh")  # rotate; `stolen` now consumed
        db_client.post("/api/v1/auth/refresh", cookies={"conduit_refresh": stolen})

        # A brand-new request, well after the failed one committed.
        assert db_client.post("/api/v1/auth/refresh").status_code == 401
