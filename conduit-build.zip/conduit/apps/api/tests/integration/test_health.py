from __future__ import annotations

from fastapi.testclient import TestClient


def test_liveness_does_not_touch_the_database(client: TestClient) -> None:
    """Liveness must stay green during a DB outage. If it did not, a brief
    blip would cause the orchestrator to kill every healthy replica at once."""
    r = client.get("/healthz")
    assert r.status_code == 200
    assert r.json()["status"] == "ok"


def test_readiness_reports_dependency_status(client: TestClient) -> None:
    r = client.get("/readyz")
    assert r.status_code in (200, 503)
    assert "database" in r.json()["checks"]


def test_request_id_header_is_returned(client: TestClient) -> None:
    r = client.get("/healthz")
    assert r.headers["X-Request-Id"]


def test_inbound_request_id_is_honoured(client: TestClient) -> None:
    r = client.get("/healthz", headers={"X-Request-Id": "trace-abc"})
    assert r.headers["X-Request-Id"] == "trace-abc"


def test_security_headers_present(client: TestClient) -> None:
    h = client.get("/healthz").headers
    assert h["X-Content-Type-Options"] == "nosniff"
    assert h["X-Frame-Options"] == "DENY"


def test_unknown_route_returns_problem_json(client: TestClient) -> None:
    r = client.get("/api/v1/does-not-exist")
    assert r.status_code == 404
    assert r.headers["content-type"].startswith("application/problem+json")
    assert r.json()["request_id"]
