from __future__ import annotations

import pytest

from conduit.config import Settings


def test_defaults_are_local() -> None:
    s = Settings()
    assert s.environment == "local"
    assert not s.is_production


def test_cors_origins_accepts_comma_separated_string() -> None:
    s = Settings(cors_origins="http://a.test, http://b.test")  # type: ignore[arg-type]
    assert s.cors_origins == ["http://a.test", "http://b.test"]


def test_production_rejects_dev_credential_key() -> None:
    s = Settings(environment="production")
    with pytest.raises(RuntimeError, match="CREDENTIAL_KEK"):
        s.assert_production_ready()


def test_production_rejects_private_network_egress() -> None:
    """The SSRF guard must not be disabled in production, even deliberately."""
    s = Settings(environment="production")
    s.egress.allow_private_networks = True
    with pytest.raises(RuntimeError, match="ALLOW_PRIVATE_NETWORKS"):
        s.assert_production_ready()


def test_local_never_raises() -> None:
    Settings(environment="local").assert_production_ready()
