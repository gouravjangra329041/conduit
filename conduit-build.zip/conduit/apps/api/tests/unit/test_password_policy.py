from __future__ import annotations

import pytest

from conduit.application.auth.service import slugify, validate_password


@pytest.mark.parametrize("password", ["short", "", "a" * 11])
def test_rejects_short_passwords(password: str) -> None:
    with pytest.raises(ValueError, match="at least"):
        validate_password(password)


def test_accepts_a_long_simple_passphrase() -> None:
    """Length, not composition rules. Forced symbols push people toward
    predictable substitutions and reuse."""
    validate_password("correct horse battery staple")


def test_rejects_absurdly_long_passwords() -> None:
    with pytest.raises(ValueError, match="under"):
        validate_password("a" * 500)


@pytest.mark.parametrize(
    ("name", "expected"),
    [
        ("Acme Corp", "acme-corp"),
        ("  Spaced  Out  ", "spaced-out"),
        ("Weird!!!Chars###", "weird-chars"),
        ("---", "workspace"),
        ("", "workspace"),
    ],
)
def test_slugify(name: str, expected: str) -> None:
    assert slugify(name) == expected


def test_slug_is_length_capped() -> None:
    assert len(slugify("a" * 500)) <= 100
