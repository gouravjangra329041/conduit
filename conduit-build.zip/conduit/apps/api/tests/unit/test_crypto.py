"""Password hashing, opaque tokens, and JWT handling."""

from __future__ import annotations

import time
import uuid

import jwt
import pytest

from conduit.config import SecuritySettings
from conduit.domain.identity import InvalidTokenError, Role, TokenExpiredError
from conduit.infrastructure.crypto import (
    JWTService,
    PasswordService,
    generate_api_key,
    generate_token,
    hash_token,
    verify_token,
)


@pytest.fixture(scope="module")
def security() -> SecuritySettings:
    # Low cost so the suite stays fast; production values come from config.
    return SecuritySettings(
        password_hash_time_cost=1,
        password_hash_memory_cost_kib=8192,
        password_hash_parallelism=1,
    )


@pytest.fixture(scope="module")
def passwords(security: SecuritySettings) -> PasswordService:
    return PasswordService(security)


@pytest.fixture(scope="module")
def jwt_service(security: SecuritySettings) -> JWTService:
    return JWTService(security, is_production=False)


class TestPasswords:
    def test_hash_verifies(self, passwords: PasswordService) -> None:
        h = passwords.hash("correct horse battery staple")
        assert passwords.verify(h, "correct horse battery staple")

    def test_wrong_password_fails(self, passwords: PasswordService) -> None:
        h = passwords.hash("correct horse battery staple")
        assert not passwords.verify(h, "Correct horse battery staple")

    def test_salted_so_hashes_differ(self, passwords: PasswordService) -> None:
        secret = "correct horse battery staple"
        assert passwords.hash(secret) != passwords.hash(secret)

    def test_malformed_hash_returns_false_not_raises(self, passwords: PasswordService) -> None:
        assert not passwords.verify("not-a-hash", "anything")

    def test_verify_dummy_never_raises(self, passwords: PasswordService) -> None:
        passwords.verify_dummy()

    def test_dummy_verification_costs_comparable_time(self, passwords: PasswordService) -> None:
        """The login path must not reveal whether an email exists via timing."""
        h = passwords.hash("correct horse battery staple")

        start = time.perf_counter()
        passwords.verify(h, "wrong-password-entirely")
        real = time.perf_counter() - start

        start = time.perf_counter()
        passwords.verify_dummy()
        dummy = time.perf_counter() - start

        # Generous bound — this asserts the same order of magnitude, which is
        # what defeats a remote timing oracle, not microsecond parity.
        assert 0.2 < (dummy / real) < 5.0


class TestOpaqueTokens:
    def test_tokens_are_unique(self) -> None:
        assert len({generate_token() for _ in range(1000)}) == 1000

    def test_hash_is_stable_and_verifiable(self) -> None:
        token = generate_token()
        assert verify_token(token, hash_token(token))

    def test_wrong_token_fails_verification(self) -> None:
        assert not verify_token(generate_token(), hash_token(generate_token()))

    def test_api_key_prefix_matches_the_key(self) -> None:
        full, prefix, digest = generate_api_key()
        assert full.startswith("cdt_")
        assert full.startswith(prefix)
        assert verify_token(full, digest)


class TestJWT:
    def test_roundtrip(self, jwt_service: JWTService) -> None:
        user_id, org_id = uuid.uuid4(), uuid.uuid4()
        token, _ = jwt_service.issue(user_id=user_id, organization_id=org_id, role=Role.ADMIN)
        claims = jwt_service.verify(token)
        assert claims.user_id == user_id
        assert claims.organization_id == org_id
        assert claims.role is Role.ADMIN

    def test_tampered_token_is_rejected(self, jwt_service: JWTService) -> None:
        token, _ = jwt_service.issue(
            user_id=uuid.uuid4(), organization_id=uuid.uuid4(), role=Role.VIEWER
        )
        head, payload, sig = token.split(".")
        with pytest.raises(InvalidTokenError):
            jwt_service.verify(f"{head}.{payload}.{sig[:-4]}AAAA")

    def test_alg_none_is_rejected(self, jwt_service: JWTService) -> None:
        """The classic JWT confusion attack: re-sign with 'none' and walk in."""
        forged = jwt.encode(
            {
                "iss": "conduit",
                "aud": "conduit-api",
                "sub": str(uuid.uuid4()),
                "org": str(uuid.uuid4()),
                "role": "owner",
                "jti": str(uuid.uuid4()),
                "iat": int(time.time()),
                "exp": int(time.time()) + 900,
            },
            key="",
            algorithm="none",
        )
        with pytest.raises(InvalidTokenError):
            jwt_service.verify(forged)

    def test_expired_token_raises_expired(self, security: SecuritySettings) -> None:
        # Must exceed the 30s clock-skew leeway, or the token is still valid.
        short = security.model_copy(update={"access_token_ttl_s": -120})
        service = JWTService(short, is_production=False)
        token, _ = service.issue(
            user_id=uuid.uuid4(), organization_id=uuid.uuid4(), role=Role.VIEWER
        )
        with pytest.raises(TokenExpiredError):
            service.verify(token)

    def test_wrong_audience_is_rejected(
        self, jwt_service: JWTService, security: SecuritySettings
    ) -> None:
        forged = jwt.encode(
            {
                "iss": "conduit",
                "aud": "some-other-service",
                "sub": str(uuid.uuid4()),
                "org": str(uuid.uuid4()),
                "role": "owner",
                "jti": str(uuid.uuid4()),
                "iat": int(time.time()),
                "exp": int(time.time()) + 900,
            },
            key=security.jwt_dev_secret.get_secret_value(),
            algorithm="HS256",
        )
        with pytest.raises(InvalidTokenError):
            jwt_service.verify(forged)

    def test_garbage_is_rejected(self, jwt_service: JWTService) -> None:
        with pytest.raises(InvalidTokenError):
            jwt_service.verify("not.a.jwt")

    def test_production_refuses_development_signing(self, security: SecuritySettings) -> None:
        with pytest.raises(RuntimeError, match="RS256"):
            JWTService(security, is_production=True)
