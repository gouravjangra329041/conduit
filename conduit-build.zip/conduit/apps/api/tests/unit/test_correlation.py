from __future__ import annotations

import pytest

from conduit.infrastructure.telemetry import bind, snapshot


def test_bind_and_restore() -> None:
    assert snapshot() == {}
    with bind(run_id="r1", node_id="n1"):
        assert snapshot() == {"run_id": "r1", "node_id": "n1"}
    assert snapshot() == {}


def test_nested_binds_restore_outer_value() -> None:
    with bind(run_id="outer"):
        with bind(run_id="inner"):
            assert snapshot()["run_id"] == "inner"
        assert snapshot()["run_id"] == "outer"


def test_none_values_are_skipped() -> None:
    with bind(run_id="r1", user_id=None):
        assert "user_id" not in snapshot()


def test_unknown_field_is_rejected() -> None:
    with pytest.raises(KeyError):
        bind(nonsense="x")
