"""Authorisation policy.

No database, no HTTP, no fixtures. The entire permission matrix is asserted
here in milliseconds — which is the reason the policy lives in the domain
rather than being scattered across route handlers.
"""

from __future__ import annotations

import pytest

from conduit.domain.identity import (
    ROLE_PERMISSIONS,
    Permission,
    Principal,
    PrincipalKind,
    Role,
    can_assign_role,
    has_permission,
    role_rank,
)
from conduit.domain.ids import new_id


def test_every_role_has_a_permission_set() -> None:
    for role in Role:
        assert role in ROLE_PERMISSIONS


def test_roles_are_strictly_nested() -> None:
    """viewer ⊂ editor ⊂ admin ⊂ owner. If this breaks, role_rank lies."""
    order = [Role.VIEWER, Role.EDITOR, Role.ADMIN, Role.OWNER]
    for lower, higher in zip(order, order[1:], strict=False):
        assert ROLE_PERMISSIONS[lower] < ROLE_PERMISSIONS[higher]


def test_viewer_cannot_write_anything() -> None:
    forbidden = [
        Permission.WORKFLOW_WRITE,
        Permission.WORKFLOW_DELETE,
        Permission.RUN_TRIGGER,
        Permission.CREDENTIAL_READ,
        Permission.MEMBER_WRITE,
        Permission.ORG_DELETE,
    ]
    for permission in forbidden:
        assert not has_permission(Role.VIEWER, permission)


def test_editor_cannot_read_or_write_credential_values() -> None:
    """Building automations and holding the secrets they use are different
    grants. An editor gets the former only."""
    assert has_permission(Role.EDITOR, Permission.WORKFLOW_WRITE)
    assert not has_permission(Role.EDITOR, Permission.CREDENTIAL_WRITE)


def test_only_owner_can_delete_the_organization() -> None:
    assert has_permission(Role.OWNER, Permission.ORG_DELETE)
    for role in (Role.ADMIN, Role.EDITOR, Role.VIEWER):
        assert not has_permission(role, Permission.ORG_DELETE)


def test_admin_cannot_promote_to_owner() -> None:
    """Otherwise privilege escalation is a documented feature."""
    assert not can_assign_role(Role.ADMIN, Role.OWNER)
    assert can_assign_role(Role.ADMIN, Role.ADMIN)
    assert can_assign_role(Role.OWNER, Role.OWNER)


def test_editor_cannot_assign_roles_at_all() -> None:
    for target in Role:
        assert not can_assign_role(Role.EDITOR, target)
        assert not can_assign_role(Role.VIEWER, target)


def test_role_rank_is_total_and_ordered() -> None:
    ranks = [role_rank(r) for r in (Role.VIEWER, Role.EDITOR, Role.ADMIN, Role.OWNER)]
    assert ranks == sorted(ranks)
    assert len(set(ranks)) == len(ranks)


@pytest.mark.parametrize("role", list(Role))
def test_principal_matches_its_role(role: Role) -> None:
    principal = Principal(
        kind=PrincipalKind.USER,
        subject_id=new_id(),
        organization_id=new_id(),
        role=role,
    )
    for permission in Permission:
        assert principal.can(permission) == has_permission(role, permission)


def test_scopes_can_only_subtract_never_grant() -> None:
    """An API key scope must never widen its role, or keys become an
    escalation path."""
    principal = Principal(
        kind=PrincipalKind.API_KEY,
        subject_id=new_id(),
        organization_id=new_id(),
        role=Role.VIEWER,
        scopes=frozenset({Permission.ORG_DELETE, Permission.WORKFLOW_READ}),
    )
    assert not principal.can(Permission.ORG_DELETE)  # role lacks it
    assert principal.can(Permission.WORKFLOW_READ)  # role has it, scope allows


def test_scopes_narrow_within_the_role() -> None:
    principal = Principal(
        kind=PrincipalKind.API_KEY,
        subject_id=new_id(),
        organization_id=new_id(),
        role=Role.ADMIN,
        scopes=frozenset({Permission.RUN_READ}),
    )
    assert principal.can(Permission.RUN_READ)
    assert not principal.can(Permission.WORKFLOW_WRITE)
