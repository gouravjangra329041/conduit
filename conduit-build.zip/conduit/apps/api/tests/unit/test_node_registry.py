"""Node contract and registry."""

from __future__ import annotations

import pytest
from pydantic import BaseModel

from conduit.domain.nodes import (
    DuplicateNodeError,
    InvalidNodeDefinitionError,
    NodeCategory,
    NodeDefinition,
    NodeRegistry,
    Port,
    RegistryFrozenError,
    RetryPolicy,
    UnknownNodeError,
    build_registry,
)


class SampleConfig(BaseModel):
    value: str = "x"


class SampleNode(NodeDefinition):
    type = "sample"
    version = 1
    category = NodeCategory.ACTION
    display_name = "Sample"
    config_schema = SampleConfig


class SampleNodeV2(SampleNode):
    version = 2


class TestRegistration:
    def test_add_and_get(self) -> None:
        registry = NodeRegistry()
        registry.add(SampleNode)
        assert registry.get("sample", 1).display_name == "Sample"

    def test_duplicate_is_rejected(self) -> None:
        registry = NodeRegistry()
        registry.add(SampleNode)
        with pytest.raises(DuplicateNodeError):
            registry.add(SampleNode)

    def test_versions_coexist(self) -> None:
        """Saved workflows pin a version forever, so an old version must stay
        registered and executable after a new one ships."""
        registry = NodeRegistry()
        registry.add(SampleNode)
        registry.add(SampleNodeV2)
        assert registry.get("sample", 1).version == 1
        assert registry.latest("sample").version == 2

    def test_unknown_node_raises(self) -> None:
        with pytest.raises(UnknownNodeError):
            NodeRegistry().get("nope", 1)

    def test_frozen_registry_rejects_additions(self) -> None:
        registry = NodeRegistry()
        registry.freeze()
        with pytest.raises(RegistryFrozenError):
            registry.add(SampleNode)


class TestValidation:
    def test_trigger_with_input_ports_is_rejected(self) -> None:
        class BadTrigger(NodeDefinition):
            type = "bad_trigger"
            category = NodeCategory.TRIGGER
            display_name = "Bad"
            config_schema = SampleConfig
            input_ports = (Port(name="in", label="In"),)

        with pytest.raises(InvalidNodeDefinitionError, match="trigger"):
            NodeRegistry().add(BadTrigger)

    def test_duplicate_output_port_names_are_rejected(self) -> None:
        class BadPorts(NodeDefinition):
            type = "bad_ports"
            category = NodeCategory.LOGIC
            display_name = "Bad"
            config_schema = SampleConfig
            output_ports = (Port(name="a", label="A"), Port(name="a", label="B"))

        with pytest.raises(InvalidNodeDefinitionError, match="duplicate"):
            NodeRegistry().add(BadPorts)

    def test_missing_display_name_is_rejected(self) -> None:
        class Nameless(NodeDefinition):
            type = "nameless"
            category = NodeCategory.ACTION
            display_name = ""
            config_schema = SampleConfig

        with pytest.raises(InvalidNodeDefinitionError):
            NodeRegistry().add(Nameless)


class TestCatalog:
    def test_describe_includes_json_schema(self) -> None:
        registry = NodeRegistry()
        registry.add(SampleNode)
        described = registry.describe(registry.get("sample", 1))
        assert "properties" in described["config_schema"]

    def test_fingerprint_is_stable(self) -> None:
        a, b = NodeRegistry(), NodeRegistry()
        a.add(SampleNode)
        b.add(SampleNode)
        assert a.fingerprint() == b.fingerprint()

    def test_fingerprint_changes_with_the_node_set(self) -> None:
        """A mismatch between replicas means a partial deploy."""
        a, b = NodeRegistry(), NodeRegistry()
        a.add(SampleNode)
        b.add(SampleNode)
        b.add(SampleNodeV2)
        assert a.fingerprint() != b.fingerprint()


class TestRetryPolicy:
    def test_backoff_grows_and_is_capped(self) -> None:
        policy = RetryPolicy(initial_delay_s=1, multiplier=2, max_delay_s=10)
        assert policy.delay_for(1) == 1
        assert policy.delay_for(2) == 2
        assert policy.delay_for(3) == 4
        assert policy.delay_for(20) == 10


class TestCorePack:
    def test_all_nine_nodes_are_discovered(self) -> None:
        """Entry-point discovery, not a directory scan: the deployed node set
        is described by the lockfile."""
        registry = build_registry()
        assert len(registry) == 9
        assert registry.is_frozen

    def test_every_node_exposes_a_usable_schema(self) -> None:
        for node in build_registry():
            schema = node.config_schema.model_json_schema()
            assert schema["type"] == "object"

    def test_triggers_have_no_inputs(self) -> None:
        for node in build_registry():
            if node.is_trigger:
                assert node.input_ports == ()

    def test_if_else_has_two_labelled_branches(self) -> None:
        node = build_registry().get("if_else", 1)
        assert [p.name for p in node.output_ports] == ["true", "false"]

    def test_execution_is_not_yet_implemented(self) -> None:
        """Honest placeholder: schemas are real, execution lands in 8-10."""
        import asyncio

        node = build_registry().get("delay", 1)
        with pytest.raises(NotImplementedError):
            asyncio.run(node.execute(None))  # type: ignore[arg-type]
