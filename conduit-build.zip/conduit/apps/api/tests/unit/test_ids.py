from __future__ import annotations

from conduit.domain.ids import new_id, timestamp_of


def test_ids_are_uuid7() -> None:
    assert new_id().version == 7


def test_ids_are_monotonic() -> None:
    """Time ordering is what keeps inserts at the right edge of the index."""
    ids = [new_id() for _ in range(200)]
    assert [str(i) for i in ids] == sorted(str(i) for i in ids)


def test_ids_are_unique() -> None:
    assert len({new_id() for _ in range(5000)}) == 5000


def test_timestamp_is_extractable() -> None:
    assert timestamp_of(new_id()) > 0
