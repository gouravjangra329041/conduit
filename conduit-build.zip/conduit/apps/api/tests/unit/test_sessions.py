"""Refresh-token rotation policy.

Pure decision logic, so every branch including the theft-detection path is
tested without a database or a live session.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime, timedelta

from conduit.domain.identity import (
    RefreshOutcome,
    StoredRefreshToken,
    decide_refresh,
)

NOW = datetime(2026, 8, 5, 12, 0, tzinfo=UTC)


def make(
    *,
    consumed: bool = False,
    revoked: bool = False,
    expires_in: timedelta = timedelta(days=30),
) -> StoredRefreshToken:
    return StoredRefreshToken(
        id=uuid.uuid4(),
        user_id=uuid.uuid4(),
        family_id=uuid.uuid4(),
        expires_at=NOW + expires_in,
        revoked_at=NOW - timedelta(minutes=1) if revoked else None,
        consumed=consumed,
    )


def test_valid_token_rotates() -> None:
    assert decide_refresh(make(), NOW).outcome is RefreshOutcome.ROTATE


def test_expired_token_is_rejected() -> None:
    token = make(expires_in=timedelta(seconds=-1))
    assert decide_refresh(token, NOW).outcome is RefreshOutcome.REJECT_EXPIRED


def test_expiry_boundary_is_exclusive() -> None:
    token = make(expires_in=timedelta(0))
    assert decide_refresh(token, NOW).outcome is RefreshOutcome.REJECT_EXPIRED


def test_revoked_token_is_rejected() -> None:
    assert decide_refresh(make(revoked=True), NOW).outcome is RefreshOutcome.REJECT_REVOKED


def test_reused_token_revokes_the_whole_family() -> None:
    """Two parties hold this token. We cannot tell which is calling, so both
    lose the session."""
    token = make(consumed=True)
    decision = decide_refresh(token, NOW)
    assert decision.outcome is RefreshOutcome.REVOKE_FAMILY
    assert decision.family_id == token.family_id


def test_reuse_is_detected_even_when_also_expired() -> None:
    """A stolen token that has since expired is still evidence of compromise.
    Dismissing it as a routine timeout would hide the breach."""
    token = make(consumed=True, expires_in=timedelta(days=-5))
    assert decide_refresh(token, NOW).outcome is RefreshOutcome.REVOKE_FAMILY


def test_reuse_outranks_revocation() -> None:
    token = make(consumed=True, revoked=True)
    assert decide_refresh(token, NOW).outcome is RefreshOutcome.REVOKE_FAMILY


def test_only_rotate_is_success() -> None:
    assert decide_refresh(make(), NOW).is_success
    assert not decide_refresh(make(consumed=True), NOW).is_success
    assert not decide_refresh(make(revoked=True), NOW).is_success
