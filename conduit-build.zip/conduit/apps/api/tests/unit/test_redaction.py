from __future__ import annotations

from conduit.infrastructure.telemetry.redaction import (
    MASK,
    redaction_processor,
    register_secrets,
    scrub,
)


def test_sensitive_keys_are_masked() -> None:
    out = scrub({"password": "hunter2", "user": "bob"})
    assert out["password"] == MASK
    assert out["user"] == "bob"


def test_partial_key_matches_are_masked() -> None:
    out = scrub({"X-Api-Key": "abc", "authorization_header": "Bearer x"})
    assert out["X-Api-Key"] == MASK
    assert out["authorization_header"] == MASK


def test_nested_structures_are_traversed() -> None:
    out = scrub({"cfg": {"items": [{"token": "t"}]}})
    assert out["cfg"]["items"][0]["token"] == MASK


def test_registered_secret_values_are_masked_anywhere() -> None:
    """Key-based masking alone fails when a secret is interpolated into a URL
    or echoed back inside an upstream error string. This is the layer that
    catches it."""
    register_secrets("super-secret-value")
    out = scrub({"url": "https://api.test/?key=super-secret-value"})
    assert "super-secret-value" not in out["url"]
    assert MASK in out["url"]


def test_short_values_are_not_masked() -> None:
    register_secrets("ab")
    assert scrub({"note": "about"})["note"] == "about"


def test_processor_masks_top_level_event_keys() -> None:
    out = redaction_processor(None, "info", {"event": "login", "api_key": "k"})
    assert out["event"] == "login"
    assert out["api_key"] == MASK


def test_recursion_is_bounded() -> None:
    deep: dict[str, object] = {}
    node = deep
    for _ in range(40):
        child: dict[str, object] = {}
        node["n"] = child
        node = child
    assert scrub(deep) is not None


def test_counts_are_not_masked_by_a_sensitive_key_name() -> None:
    """Regression: `tokens_revoked=3` was masked purely because the key
    contains "token", hiding the numbers operators need during an incident.
    Only strings and bytes can carry a secret."""
    out = redaction_processor(None, "warning", {"event": "reuse_detected", "tokens_revoked": 3})
    assert out["tokens_revoked"] == 3


def test_boolean_flags_survive_redaction() -> None:
    assert scrub({"token_valid": False})["token_valid"] is False


def test_string_secrets_are_still_masked() -> None:
    assert scrub({"access_token": "abcdef123456"})["access_token"] == MASK
