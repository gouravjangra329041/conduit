# ADR-004 — Session and Authentication Model

**Status:** Accepted · **Date:** 2026-08-05 · Supersedes open question in ARCHITECTURE.md §0.11

## Context

The brief specified "Authentication: JWT". Taken literally — a long-lived
stateless JWT as the only credential — that design cannot revoke a session.
An offboarded employee keeps access until expiry, and a leaked token cannot be
withdrawn at all. Adding a server-side denylist restores revocation but
requires a lookup on every request, which removes the only advantage
statelessness offered.

## Decision

Split the two jobs across two credentials.

| | Access token | Refresh token |
|---|---|---|
| Form | Signed JWT | Opaque random value |
| Lifetime | 15 minutes | 30 days, rotating |
| Storage (server) | None | SHA-256 digest in Postgres |
| Storage (client) | Memory only | httpOnly cookie |
| Revocable | No, by design | Yes, immediately |

The short access lifetime bounds the damage of a leak; the refresh token
carries revocability. Neither tries to do both.

**Rotation with reuse detection.** Each login opens a token *family*. Every
refresh consumes the presented token and issues a successor in the same
family. Presenting an already-consumed token means two parties hold it. We
cannot distinguish the legitimate user from the thief, so the entire family is
revoked and both must re-authenticate.

**RS256 in production.** Asymmetric signing lets workers and future services
verify tokens without holding the signing key. Local development falls back to
HS256; `assert_production_ready()` refuses to boot production in that state.

## Consequences

- Logging out of one device does not end other sessions. `logout_everywhere`
  exists for the case where it should.
- Revoking a compromised session leaves a window of up to 15 minutes where the
  existing access token still works. This is the explicit price of statelessness
  and is why the lifetime is short.
- Two implementation details turned out to be load-bearing and are covered by
  named regression tests:
  1. **The revocation must be committed before the error response is raised.**
     The 401 unwinds the request transaction, which rolled back the revocation
     itself — the defence fired, logged success, and silently reverted.
  2. **Consumption is guarded by `WHERE consumed_at IS NULL`.** Two concurrent
     refreshes with the same token must not both succeed; the database decides
     the winner, not application logic.

## Rejected

- **Long-lived stateless JWT only** — no revocation. Unacceptable.
- **Server-side session store only** — a lookup per request, and it discards
  the stateless verification that lets workers check tokens independently.
- **Refresh token in `localStorage`** — readable by any injected script, which
  makes every XSS a full account takeover.
