# AI Workflow Automation Platform — Architecture & Design Specification

**Version:** 0.1 (Draft for approval)
**Status:** Pre-implementation
**Audience:** Engineering, product

---

## 0. Executive Summary & Design Challenges

Before the specification, here are the decisions in the brief I want to challenge. Each one is cheap to change now and expensive to change after the MVP ships.

### 0.1 The engine must be a durable state machine, not a graph traversal

The most common way to build this is a recursive/iterative in-memory traversal inside a FastAPI request or background task. It works for a demo and fails permanently the first time you need any of:

- A `Delay` node that waits 3 days
- A worker crash mid-run without losing the run
- Retrying node 7 of 12 without re-running nodes 1–6 (which already sent emails)
- Human-in-the-loop approval
- Resuming after a deploy

**Decision:** every node execution is a persisted row. The engine is a loop that (a) claims a run, (b) computes the next ready nodes, (c) executes them, (d) commits state, (e) either continues or yields. A run can be suspended and resumed by *any* worker at *any* time. This is the single most important structural decision in the document and everything else follows from it.

### 0.2 A `Delay` node must never occupy a worker

`await asyncio.sleep(259200)` is not a delay, it is a resource leak. Delays are implemented as **suspension with a wake-up timestamp**: the node returns `Suspend(resume_at=...)`, the run is parked, and a timer scanner re-enqueues it. Sub-second delays may sleep inline as an optimisation; anything above a configurable threshold (suggest 5s) suspends.

Generalising this: `Suspend` is a first-class node result. It is the same primitive that later powers Wait-For-Webhook, Approval, and Wait-For-Sub-Workflow. Build it in the MVP even though only `Delay` uses it.

### 0.3 Drop the `End` node

A node with no outgoing edges *is* the end. An explicit `End` node adds a concept, adds validation rules ("must every branch reach End?"), and confuses users when branches legitimately terminate early. It buys nothing the run status field doesn't already give you.

**Recommendation:** remove `End`. That frees a slot under your 10-node budget. Spend it on a **Set / Edit Fields** node (the single most-used node in every automation product) or leave the budget unspent. `JSON Transform` can cover Set if its UX is good, but a dedicated Set node is far more discoverable for non-technical users.

Similarly, consider whether `Manual Trigger` and `Webhook Trigger` are two node *types* or one `Trigger` node with a provider setting. I recommend two types — clearer schemas, clearer UI — but the engine should treat "trigger" as a node *capability flag*, not a hardcoded list.

### 0.4 Payload storage will be your first scaling wall

If you store the full input and output JSON of every node execution in Postgres, a single workflow that fetches a 5 MB API response through 8 nodes writes ~80 MB per run. At 10k runs/day that is 800 GB/day. This kills you within weeks of real usage, and it is the failure mode that most self-hosted automation tools hit.

**Decision:** introduce a `PayloadRef` indirection from day one. Payloads under a threshold (suggest 64 KB) are stored inline as `JSONB`. Above it, they are written to object storage (MinIO in dev, S3-compatible in prod) and the DB stores a pointer. Node code never sees the difference — it goes through a `PayloadStore` interface. Retrofitting this later means migrating live data.

Pair it with a retention policy: execution payloads expire (suggest 30 days default, configurable per org), metadata is kept longer.

### 0.5 Node versioning is not optional

The moment a user saves a workflow referencing `http_request`, you have made a permanent compatibility promise. If you later rename a config field, every existing workflow silently breaks.

**Decision:** node identity is `type@major_version` (e.g. `http_request@1`). A breaking schema change means shipping `http_request@2` and keeping `@1` registered and executable. Workflows pin the version at save time. Provide an opt-in migration path per node.

### 0.6 Workflow runs must pin an immutable version snapshot

If a run reads the workflow definition live from the `workflows` table, editing a workflow while a run is in flight (or in a 3-day delay) corrupts it, and execution history becomes unexplainable.

**Decision:** `workflows` holds pointer/metadata; `workflow_versions` holds immutable definitions. A run references a `workflow_version_id`. Editing creates a new version. This also gives you free audit history and rollback.

### 0.7 Separate the semantic graph from editor layout

Storing React Flow node positions inside the execution definition means every drag of a node produces a new "version" of business logic and pollutes diffs.

**Decision:** `workflow_versions.definition` (nodes, edges, config — hashed for change detection) and `workflow_versions.ui_metadata` (positions, viewport, notes) are separate columns. Position-only edits can skip version creation.

### 0.8 Plugin loading via filesystem scan is a security and reproducibility problem

Scanning a `plugins/` directory and `importlib`-ing whatever is there means (a) anything that lands on disk executes with full application privileges, (b) your deployed node set is not described by your lockfile, and (c) two replicas can disagree about what nodes exist.

**Decision for MVP:** plugins are discovered via **Python packaging entry points** (`workflow.nodes`). First-party nodes live in an in-repo package; third-party nodes are installed packages. Registry is built once at process start and is immutable thereafter. Every replica computes the same registry hash; a mismatch is a startup error.

**Explicit non-goal for MVP:** untrusted third-party plugins and user-authored code nodes. When you get there, that is a separate execution substrate (gVisor / Firecracker / WASM sandbox), not a Python import. Design the boundary now, build it later.

### 0.9 The expression language is a security decision, not a convenience

Users will immediately need `{{ $node["Fetch User"].output.email }}`. If you reach for `eval()`, Jinja2 with full context, or an unrestricted templating engine, you have shipped remote code execution to every tenant.

**Decision:** a restricted expression evaluator with no attribute access on Python objects, no imports, no builtins, a fixed function whitelist, output size limits, and evaluation timeouts. Start with JMESPath-style path resolution plus a small whitelisted function set. Pick this before writing any node, because expression syntax leaks into every node's config UI and cannot be changed later.

### 0.10 SSRF is the highest-severity risk in the product

An `HTTP Request` node is, by definition, a user-controlled server-side request. Untreated, any tenant can read your cloud metadata endpoint (`169.254.169.254`), your internal Postgres, your Redis, and your other services.

**Decision:** all outbound requests from nodes go through an egress policy layer — DNS resolution first, then IP allow/deny check against RFC1918 / loopback / link-local / metadata ranges, re-validated after every redirect (to defeat DNS rebinding), with redirect count limits, response size limits, and timeouts. This is not a "harden later" item; it is a launch blocker.

### 0.11 Stateless JWT with no revocation is the wrong default

If your access token is a long-lived JWT and a user is offboarded or a token is leaked, you cannot revoke it. "JWT" is in the brief; I am not removing it, I am scoping it.

**Decision:** short-lived access JWT (10–15 min) + rotating refresh token persisted in the DB (revocable, reuse-detection). Refresh token in an `httpOnly`, `Secure`, `SameSite=Lax` cookie; access token in memory on the client, never `localStorage`. Programmatic access uses separate, scoped, revocable API keys (hashed at rest), not user JWTs.

### 0.12 Async all the way down, or sync all the way down — never mixed

A single synchronous DB call or `requests.get()` inside an `async def` FastAPI handler blocks the entire event loop for that worker. This is the most common FastAPI performance bug and it is invisible until load testing.

**Decision:** fully async — `asyncpg` + SQLAlchemy 2.x async ORM + `httpx.AsyncClient`. Any unavoidable sync library call goes through `run_in_threadpool` explicitly. Enforce with a lint rule and a load test in CI.

### 0.13 Multi-tenancy must exist on day one

Adding `organization_id` to 14 tables with live data, and auditing 200 query sites for missing filters, is a multi-week project with a data-leak failure mode. Adding it now costs a day.

**Decision:** `organizations` from the first migration. Every tenant-scoped table carries `organization_id`. Consider Postgres Row-Level Security as defence-in-depth so a forgotten `WHERE` clause fails closed rather than leaking.

### 0.14 Be honest about at-least-once semantics

With a durable queue and worker crashes, a node can execute twice (crash after the side effect, before the state commit). `Email` and `HTTP Request` are not idempotent.

**Decision:** every node execution carries a deterministic `idempotency_key` (`run_id:node_id:attempt`). Nodes that support it forward the key to the provider (Stripe-style, or SMTP `Message-ID`). Where the provider does not support it, document the semantics honestly rather than pretending exactly-once. Do not claim exactly-once in marketing copy.

---

## 1. Software Requirements Specification (SRS)

### 1.1 Purpose

A multi-tenant platform for defining, executing, and observing AI-augmented automation workflows. The MVP is a general-purpose engine; vertical solutions (HR, support, document automation, marketing) are later built as node packs and workflow templates on top of it, with **no changes to the execution engine**.

### 1.2 Scope

**In scope (MVP):** visual workflow editor, 8–9 core nodes, durable execution, manual and webhook triggers, run history and observability, credential management, org/user/RBAC, JWT auth, Docker deployment.

**Out of scope (MVP), explicitly:** user-authored code nodes, third-party untrusted plugin marketplace, sub-workflows, loops/iterators, cron scheduling, versioned workflow diffing UI, SSO/SAML, billing, real-time collaborative editing.

### 1.3 Definitions

| Term | Meaning |
|---|---|
| Workflow | A named, versioned graph of nodes and edges owned by an organization |
| Workflow Version | An immutable snapshot of a workflow definition |
| Node | A unit of work; an instance of a Node Type placed in a graph |
| Node Type | A plugin-provided, versioned implementation (`http_request@1`) |
| Run | One execution of a specific workflow version |
| Node Execution | One attempt to execute one node within a run |
| Trigger | A node type that can start a run |
| Suspension | A run paused awaiting a timer or external event |
| Payload | JSON data flowing along an edge |

### 1.4 Functional Requirements

**Authentication & Tenancy**
- FR-1 Users register, log in, and refresh sessions via JWT.
- FR-2 Every user belongs to at least one organization; all resources are org-scoped.
- FR-3 Roles: `owner`, `admin`, `editor`, `viewer`. Permissions enforced server-side.
- FR-4 API keys can be issued per organization, scoped, and revoked.

**Workflow Authoring**
- FR-5 CRUD workflows within an organization.
- FR-6 Visual editor: add/remove/connect nodes, edit node config via schema-driven forms.
- FR-7 Saving produces an immutable workflow version; UI-only changes do not.
- FR-8 Server-side validation on save: graph connectivity, node config against JSON Schema, expression syntax, exactly one enabled trigger, no unreachable nodes, cycle-depth limits.
- FR-9 Workflows can be activated/deactivated. Only active workflows accept webhook triggers.

**Execution**
- FR-10 Manual trigger: authenticated user starts a run with optional input payload.
- FR-11 Webhook trigger: unauthenticated (or signature-verified) HTTP request to a unique URL enqueues a run and returns `202` within 100 ms.
- FR-12 Runs execute asynchronously in workers, durably, resumable after crash or restart.
- FR-13 Nodes receive resolved inputs and produce outputs; outputs are addressable by downstream nodes via expressions.
- FR-14 If/Else routes execution down exactly one branch; the untaken branch is pruned.
- FR-15 Delay suspends the run and resumes at a computed time.
- FR-16 Failed nodes retry per policy; on exhaustion the run fails or follows an error branch per node config.
- FR-17 Runs can be cancelled by a user; cancellation is honoured at node boundaries.
- FR-18 Per-organization concurrency limits prevent one tenant starving others.

**Observability**
- FR-19 Run list with status, duration, trigger source, filters.
- FR-20 Run detail: per-node status, timing, input/output payloads, error detail, retry attempts.
- FR-21 Structured logs correlated by `run_id` and `node_execution_id`.

**Credentials**
- FR-22 Credentials are stored separately from workflow definitions, encrypted at rest.
- FR-23 Node config references a credential by ID; secret values are never returned by the API and never appear in logs or run payloads.

### 1.5 Non-Functional Requirements

| ID | Requirement | Target |
|---|---|---|
| NFR-1 | Webhook ingress latency (p95) | < 100 ms |
| NFR-2 | API read latency (p95) | < 200 ms |
| NFR-3 | Trigger-to-first-node latency (p95, unloaded) | < 1 s |
| NFR-4 | Engine node dispatch overhead | < 20 ms per node |
| NFR-5 | Throughput per worker | ≥ 50 node executions/sec (I/O-bound mix) |
| NFR-6 | Horizontal scale | Workers stateless; scale by replica count |
| NFR-7 | Durability | Zero run loss on worker SIGKILL |
| NFR-8 | Availability target | 99.5% MVP |
| NFR-9 | Test coverage | ≥ 80% on engine and node packages |
| NFR-10 | New node type added | Zero changes to engine code; one package + registration |
| NFR-11 | Max run steps | Configurable cap (default 1000) to bound runaway graphs |
| NFR-12 | Max payload size per edge | Configurable cap (default 16 MB), offloaded above 64 KB |

### 1.6 Constraints & Assumptions

- Deployment target is Docker Compose for MVP, Kubernetes-ready by construction.
- PostgreSQL 15+ (uses `SKIP LOCKED`, `JSONB`, `GIN` indexes, generated columns).
- Single-region MVP.
- Assumption: initial load is < 100k runs/day. Above that, the Postgres-backed queue should be re-evaluated (see §6.8).

---

## 2. System Architecture

### 2.1 Component View

```
┌─────────────────────────────────────────────────────────────────┐
│  Next.js Frontend (App Router, RSC + client editor)             │
│  React Flow editor · schema-driven config forms · run viewer    │
└───────────────┬─────────────────────────────────────────────────┘
                │ HTTPS / REST + SSE
┌───────────────▼─────────────────────────────────────────────────┐
│  API Service (FastAPI, stateless, N replicas)                   │
│  ┌───────────┬──────────────┬────────────┬───────────────────┐  │
│  │ Auth      │ Workflow CRUD│ Run control│ Webhook Ingress   │  │
│  │ RBAC      │ + Validation │ + Query    │ (fast-ack)        │  │
│  └───────────┴──────────────┴────────────┴───────────────────┘  │
└───────┬───────────────────────────────────────┬─────────────────┘
        │ enqueue                               │ read
        │                                       │
┌───────▼───────────────────────────────────────▼─────────────────┐
│  PostgreSQL                                                      │
│  identity · workflows · versions · runs · node_executions ·      │
│  credentials · run_queue · timers · webhook_events · audit       │
└───────▲───────────────────────────────────────▲─────────────────┘
        │ claim / commit                        │
┌───────┴────────────────┐          ┌───────────┴─────────────────┐
│ Worker Service (N)     │          │ Scheduler Service (1, HA)   │
│ ┌────────────────────┐ │          │ · timer scan → re-enqueue   │
│ │ Execution Engine   │ │          │ · stale-lease reclaim       │
│ │ (state machine)    │ │          │ · retention / GC            │
│ ├────────────────────┤ │          └─────────────────────────────┘
│ │ Node Registry      │ │
│ │ (plugin entrypts)  │ │          ┌─────────────────────────────┐
│ ├────────────────────┤ │          │ Object Storage (S3/MinIO)   │
│ │ Expression Engine  │ │◄────────►│ large payloads              │
│ ├────────────────────┤ │          └─────────────────────────────┘
│ │ Egress Guard       │ │
│ │ Secret Resolver    │ │          ┌─────────────────────────────┐
│ └────────────────────┘ │◄────────►│ External: LLM APIs, SMTP,   │
└────────────────────────┘          │ customer HTTP endpoints     │
                                    └─────────────────────────────┘
```

### 2.2 Process Separation

Four deployable units, all from two images (`api` and `worker` share the Python codebase; the scheduler is the worker image with a different entrypoint):

| Process | Responsibility | Scaling |
|---|---|---|
| `web` | Next.js UI | Horizontal, stateless |
| `api` | HTTP surface, validation, webhook ingress | Horizontal, stateless |
| `worker` | Executes runs | Horizontal, stateless |
| `scheduler` | Timers, lease reclaim, GC | Leader-elected singleton (advisory lock) |

**Why API and worker are separate processes:** they have opposite resource profiles and opposite failure tolerances. A stuck LLM call must never degrade webhook ingress latency, and worker deploys must not drop HTTP connections. Running the engine as a FastAPI `BackgroundTask` couples them permanently and is the single hardest thing to unwind later.

### 2.3 Layering (Clean Architecture)

Dependencies point inward only.

```
   ┌──────────────────────────────────────────┐
   │ Interface     routers, schemas, CLI      │  ← FastAPI, Pydantic I/O
   ├──────────────────────────────────────────┤
   │ Application   use cases, orchestration   │  ← services, unit of work
   ├──────────────────────────────────────────┤
   │ Domain        entities, rules, engine    │  ← pure Python, zero I/O
   ├──────────────────────────────────────────┤
   │ Infrastructure  repos, queue, storage    │  ← implements domain ports
   └──────────────────────────────────────────┘
```

The **domain layer contains the execution engine and imports nothing from FastAPI, SQLAlchemy, or httpx**. It defines ports (`RunRepository`, `PayloadStore`, `JobQueue`, `Clock`) that infrastructure implements. This is what makes the engine unit-testable in milliseconds with an in-memory fake, and it is what lets you swap the Postgres queue for Temporal later without touching engine logic.

### 2.4 Key Architectural Decisions (ADR summary)

| # | Decision | Alternative rejected | Rationale |
|---|---|---|---|
| 1 | Durable step-level state machine | In-memory graph traversal | Resumability, delays, partial retry |
| 2 | Postgres queue (`SKIP LOCKED`) | Redis/Celery, RabbitMQ, Temporal | One less dependency; transactional enqueue with state change; ~10k jobs/min headroom is enough for MVP. Abstracted behind `JobQueue` port for later swap |
| 3 | Immutable workflow versions | Mutable definitions | Reproducible runs, audit, rollback |
| 4 | Entry-point plugin discovery | Filesystem `importlib` scan | Reproducible deploys, no arbitrary code load |
| 5 | Payload indirection from day one | Inline JSONB only | Avoids DB bloat wall |
| 6 | Restricted expression evaluator | Jinja2 / `eval` | RCE prevention |
| 7 | Async end-to-end | Sync SQLAlchemy | Event-loop blocking |
| 8 | Egress guard on all node HTTP | Trust the node | SSRF prevention |

**On decision 2 — when to revisit:** move off the Postgres queue when *any* of these is true: sustained > 200 enqueues/sec, queue table > 5M rows, or you need cross-service workflow orchestration. The migration target is Temporal (best fit — it is literally durable execution) or Redis Streams + a dispatcher. Because everything goes through the `JobQueue` port, this is a contained change.

---

## 3. Database Schema

PostgreSQL. All IDs are UUIDv7 (time-ordered — critical for index locality on high-insert tables like `node_executions`). All timestamps are `TIMESTAMPTZ`. Soft deletes only where recovery matters.

### 3.1 Identity & Tenancy

```sql
organizations (
  id              uuid PK,
  name            text NOT NULL,
  slug            citext UNIQUE NOT NULL,
  plan            text NOT NULL DEFAULT 'free',
  max_concurrent_runs   int NOT NULL DEFAULT 5,
  payload_retention_days int NOT NULL DEFAULT 30,
  created_at, updated_at, deleted_at
)

users (
  id              uuid PK,
  email           citext UNIQUE NOT NULL,
  password_hash   text,                 -- argon2id; NULL for SSO-only later
  full_name       text,
  is_active       bool NOT NULL DEFAULT true,
  last_login_at   timestamptz,
  created_at, updated_at
)

memberships (
  id              uuid PK,
  organization_id uuid FK → organizations ON DELETE CASCADE,
  user_id         uuid FK → users ON DELETE CASCADE,
  role            text NOT NULL CHECK (role IN ('owner','admin','editor','viewer')),
  created_at,
  UNIQUE (organization_id, user_id)
)

refresh_tokens (
  id              uuid PK,
  user_id         uuid FK → users ON DELETE CASCADE,
  token_hash      bytea NOT NULL,        -- sha256; never store raw
  family_id       uuid NOT NULL,         -- rotation family for reuse detection
  expires_at      timestamptz NOT NULL,
  revoked_at      timestamptz,
  user_agent, ip_address inet,
  created_at,
  INDEX (user_id, expires_at), UNIQUE (token_hash)
)

api_keys (
  id              uuid PK,
  organization_id uuid FK,
  name            text NOT NULL,
  key_prefix      text NOT NULL,         -- first 8 chars, for display/lookup
  key_hash        bytea NOT NULL,
  scopes          text[] NOT NULL DEFAULT '{}',
  last_used_at    timestamptz,
  expires_at      timestamptz,
  revoked_at      timestamptz,
  created_by      uuid FK → users,
  created_at,
  INDEX (key_prefix)
)
```

### 3.2 Credentials

```sql
credentials (
  id              uuid PK,
  organization_id uuid FK ON DELETE CASCADE,
  name            text NOT NULL,
  type            text NOT NULL,         -- 'http_header_auth','smtp','openai','anthropic'
  data_encrypted  bytea NOT NULL,        -- AES-256-GCM envelope-encrypted JSON
  data_key_encrypted bytea NOT NULL,     -- DEK wrapped by KEK
  key_version     int NOT NULL,          -- supports KEK rotation
  created_by      uuid FK → users,
  created_at, updated_at, deleted_at,
  UNIQUE (organization_id, name)
)
```

Envelope encryption: a per-credential Data Encryption Key encrypts the payload; the DEK is wrapped by a Key Encryption Key from env/KMS. `key_version` allows rotating the KEK by rewrapping DEKs without re-encrypting payloads. **The plaintext never leaves the worker process and is never written to any table, log, or run payload.**

### 3.3 Workflows

```sql
workflows (
  id                  uuid PK,
  organization_id     uuid FK ON DELETE CASCADE,
  name                text NOT NULL,
  description         text,
  is_active           bool NOT NULL DEFAULT false,
  current_version_id  uuid FK → workflow_versions DEFERRABLE,
  created_by          uuid FK → users,
  created_at, updated_at, deleted_at,
  INDEX (organization_id, deleted_at)
)

workflow_versions (
  id              uuid PK,
  workflow_id     uuid FK ON DELETE CASCADE,
  version         int NOT NULL,
  definition      jsonb NOT NULL,        -- semantic graph: nodes, edges, config
  definition_hash bytea NOT NULL,        -- sha256, dedupe no-op saves
  ui_metadata     jsonb NOT NULL DEFAULT '{}',  -- positions, viewport, notes
  created_by      uuid FK → users,
  created_at,
  UNIQUE (workflow_id, version)
)

triggers (
  id              uuid PK,
  workflow_id     uuid FK ON DELETE CASCADE,
  organization_id uuid FK,               -- denormalised for fast ingress lookup
  node_id         text NOT NULL,         -- node key within the definition
  type            text NOT NULL,         -- 'manual','webhook'
  webhook_path    text UNIQUE,           -- opaque, unguessable slug
  secret_hash     bytea,                 -- HMAC signature verification
  is_enabled      bool NOT NULL DEFAULT true,
  created_at,
  UNIQUE (workflow_id, node_id),
  INDEX (webhook_path) WHERE webhook_path IS NOT NULL
)
```

**Why `definition` is `JSONB` and not normalised `nodes`/`edges` tables:** the graph is always read and written as a whole, is never queried by individual node across workflows, and is validated as a unit. Normalising costs joins on every read and gains nothing. Should you later need cross-workflow node analytics ("which orgs use the AI node?"), add a derived index table populated on save — do not normalise the source of truth.

### 3.4 Execution

```sql
workflow_runs (
  id                  uuid PK,           -- UUIDv7
  organization_id     uuid FK,
  workflow_id         uuid FK,
  workflow_version_id uuid FK,           -- pinned; run reads THIS, never live workflow
  status              text NOT NULL,     -- see state machine §6.2
  trigger_type        text NOT NULL,
  trigger_node_id     text NOT NULL,
  triggered_by        uuid FK → users,   -- NULL for webhook
  input_payload_ref   jsonb,             -- PayloadRef
  output_payload_ref  jsonb,
  error               jsonb,             -- normalised error object
  step_count          int NOT NULL DEFAULT 0,
  queued_at, started_at, finished_at, resume_at  timestamptz,
  duration_ms         int,
  created_at,
  INDEX (organization_id, created_at DESC),
  INDEX (workflow_id, created_at DESC),
  INDEX (status) WHERE status IN ('queued','running','suspended')
)

node_executions (
  id              uuid PK,               -- UUIDv7
  run_id          uuid FK ON DELETE CASCADE,
  organization_id uuid FK,
  node_id         text NOT NULL,         -- key within definition
  node_type       text NOT NULL,         -- 'http_request'
  node_version    int NOT NULL,
  attempt         int NOT NULL DEFAULT 1,
  status          text NOT NULL,         -- pending|running|succeeded|failed|skipped|suspended|cancelled
  input_ref       jsonb,
  output_ref      jsonb,
  error           jsonb,
  idempotency_key text NOT NULL,
  started_at, finished_at  timestamptz,
  duration_ms     int,
  created_at,
  UNIQUE (run_id, node_id, attempt),
  INDEX (run_id, created_at)
)

run_state (
  run_id          uuid PK FK → workflow_runs ON DELETE CASCADE,
  ready_nodes     text[] NOT NULL DEFAULT '{}',
  completed_nodes text[] NOT NULL DEFAULT '{}',
  pruned_nodes    text[] NOT NULL DEFAULT '{}',
  node_outputs    jsonb NOT NULL DEFAULT '{}',   -- node_id → PayloadRef
  suspension      jsonb,                          -- {node_id, kind, resume_at, token}
  updated_at      timestamptz NOT NULL
)
```

Splitting the mutable frontier (`run_state`) from the append-mostly `workflow_runs` row keeps the hot-update row narrow and reduces write amplification and lock contention.

### 3.5 Queue, Timers, Idempotency

```sql
run_queue (
  id              bigserial PK,
  run_id          uuid FK ON DELETE CASCADE,
  organization_id uuid FK,               -- for fair scheduling / concurrency caps
  priority        int NOT NULL DEFAULT 100,
  available_at    timestamptz NOT NULL DEFAULT now(),
  claimed_by      text,                  -- worker id
  claimed_at      timestamptz,
  lease_expires_at timestamptz,
  attempts        int NOT NULL DEFAULT 0,
  INDEX (available_at, priority) WHERE claimed_by IS NULL,
  INDEX (lease_expires_at) WHERE claimed_by IS NOT NULL
)

timers (
  id              uuid PK,
  run_id          uuid FK ON DELETE CASCADE,
  node_id         text NOT NULL,
  fire_at         timestamptz NOT NULL,
  fired_at        timestamptz,
  INDEX (fire_at) WHERE fired_at IS NULL
)

webhook_events (
  id              uuid PK,
  trigger_id      uuid FK,
  organization_id uuid FK,
  idempotency_key text,                  -- from header, if provided
  request_ref     jsonb NOT NULL,        -- PayloadRef to headers+body
  run_id          uuid FK,
  received_at     timestamptz NOT NULL,
  UNIQUE (trigger_id, idempotency_key)   -- partial: WHERE idempotency_key IS NOT NULL
)

audit_log (
  id              bigserial PK,
  organization_id uuid,
  actor_user_id   uuid,
  actor_api_key_id uuid,
  action          text NOT NULL,         -- 'workflow.updated','credential.created'
  resource_type   text, resource_id uuid,
  metadata        jsonb,
  ip_address      inet,
  created_at      timestamptz NOT NULL,
  INDEX (organization_id, created_at DESC)
)
```

**Claim query** (the heart of the queue — no polling storm, no lock contention):

```sql
UPDATE run_queue q SET claimed_by = $1, claimed_at = now(),
       lease_expires_at = now() + interval '60 seconds', attempts = attempts + 1
WHERE q.id IN (
  SELECT id FROM run_queue
  WHERE claimed_by IS NULL AND available_at <= now()
  ORDER BY priority, id
  FOR UPDATE SKIP LOCKED
  LIMIT $2
)
RETURNING *;
```

Add `LISTEN/NOTIFY` on enqueue so idle workers wake immediately instead of polling at their floor interval — this is what gets you NFR-3 (< 1 s trigger-to-first-node) without hammering the DB.

### 3.6 Partitioning & Retention

`node_executions` is the highest-volume table. Declare it `PARTITION BY RANGE (created_at)` monthly **from the first migration** — converting a large table to partitioned later requires a full rewrite. Same for `audit_log`. Retention is then a `DROP PARTITION`, not a `DELETE` of 50M rows.

---

## 4. Folder Structure

Monorepo. `pnpm` workspace for JS, `uv`/Poetry for Python.

```
platform/
├── apps/
│   ├── web/                          # Next.js
│   │   ├── src/
│   │   │   ├── app/
│   │   │   │   ├── (auth)/login, register
│   │   │   │   ├── (dashboard)/
│   │   │   │   │   ├── workflows/[id]/edit
│   │   │   │   │   ├── runs/[id]
│   │   │   │   │   └── credentials/, settings/
│   │   │   │   └── api/              # BFF only: cookie↔token exchange
│   │   │   ├── features/
│   │   │   │   ├── editor/           # React Flow
│   │   │   │   │   ├── canvas/, nodes/, edges/
│   │   │   │   │   ├── panels/       # schema-driven config forms
│   │   │   │   │   └── store/        # zustand graph state
│   │   │   │   ├── runs/             # run viewer, timeline, payload inspector
│   │   │   │   ├── auth/, credentials/
│   │   │   ├── components/ui/        # design system primitives
│   │   │   ├── lib/
│   │   │   │   ├── api/              # generated client from OpenAPI
│   │   │   │   ├── expressions/      # editor autocomplete for {{ }}
│   │   │   │   └── node-schemas/     # runtime form generation
│   │   │   └── styles/
│   │   └── package.json, next.config.ts, tailwind.config.ts
│   │
│   └── api/                          # FastAPI + workers (one image, N entrypoints)
│       ├── src/platform/
│       │   ├── domain/               # PURE. No I/O, no framework imports.
│       │   │   ├── workflow/         # Workflow, Version, Graph, validation rules
│       │   │   ├── execution/
│       │   │   │   ├── engine.py     # ← the state machine
│       │   │   │   ├── run.py, node_execution.py
│       │   │   │   ├── router.py     # edge/branch resolution
│       │   │   │   ├── retry.py, errors.py
│       │   │   │   └── ports.py      # RunRepository, JobQueue, PayloadStore, Clock
│       │   │   ├── nodes/
│       │   │   │   ├── contract.py   # NodeDefinition, NodeContext, NodeResult
│       │   │   │   ├── registry.py
│       │   │   │   └── errors.py
│       │   │   ├── identity/         # User, Org, Membership, RBAC policy
│       │   │   └── expressions/      # parser + restricted evaluator
│       │   │
│       │   ├── application/          # use cases, transaction boundaries
│       │   │   ├── workflows/        # create, update, validate, activate
│       │   │   ├── runs/             # trigger, cancel, query
│       │   │   ├── credentials/, auth/
│       │   │   └── unit_of_work.py
│       │   │
│       │   ├── infrastructure/       # implements domain ports
│       │   │   ├── db/
│       │   │   │   ├── models/       # SQLAlchemy
│       │   │   │   ├── repositories/
│       │   │   │   ├── session.py
│       │   │   │   └── migrations/   # Alembic
│       │   │   ├── queue/            # postgres_queue.py (swap point)
│       │   │   ├── storage/          # inline_store.py, s3_store.py
│       │   │   ├── crypto/           # envelope encryption, hashing
│       │   │   ├── http/             # egress-guarded async client
│       │   │   ├── llm/              # provider adapters
│       │   │   ├── mail/             # SMTP / provider adapters
│       │   │   └── telemetry/        # logging, tracing, metrics
│       │   │
│       │   ├── interface/
│       │   │   ├── api/
│       │   │   │   ├── v1/routers/   # auth, workflows, runs, credentials, nodes
│       │   │   │   ├── deps.py       # auth, tenancy, RBAC dependencies
│       │   │   │   ├── schemas/      # request/response DTOs
│       │   │   │   ├── errors.py     # RFC 7807 handlers
│       │   │   │   └── middleware/   # request id, rate limit, CORS
│       │   │   ├── webhooks/         # ingress router (separate for isolation)
│       │   │   └── cli/
│       │   │
│       │   ├── entrypoints/
│       │   │   ├── api.py            # uvicorn app
│       │   │   ├── worker.py         # engine loop
│       │   │   └── scheduler.py      # timers, lease reclaim, GC
│       │   └── config.py             # pydantic-settings
│       │
│       └── tests/{unit,integration,e2e,fixtures}/
│
├── packages/
│   ├── nodes-core/                   # ← the first-party node plugin package
│   │   └── src/nodes_core/
│   │       ├── manual_trigger/, webhook_trigger/
│   │       ├── http_request/, ai_prompt/
│   │       ├── if_else/, delay/
│   │       ├── json_transform/, email/
│   │       └── __init__.py           # entry-point registration
│   ├── contracts/                    # shared JSON Schema + generated TS types
│   └── ui-icons/
│
├── docker/                           # Dockerfile.api, Dockerfile.web, compose files
├── docs/adr/                         # architecture decision records
└── Makefile, .github/workflows/
```

**Note the shape of `nodes-core`:** it is a *separate package* depending only on `platform.domain.nodes.contract`. If a node package can import `platform.infrastructure`, the plugin boundary is already broken. Enforce with an import-linter rule in CI.

---

## 5. API Design

REST, `/api/v1`, JSON, RFC 7807 problem details for errors, cursor pagination, OpenAPI 3.1 auto-generated → TypeScript client.

### 5.1 Conventions

- Auth: `Authorization: Bearer <jwt>` or `X-API-Key: <key>`
- Tenancy: derived from token; `X-Organization-Id` selects among memberships
- `X-Request-Id` echoed on every response, present in every log line
- Mutations accept `Idempotency-Key`
- Errors: `{ "type": "...", "title": "...", "status": 422, "detail": "...", "errors": [...] }`

### 5.2 Endpoints

**Auth**
```
POST   /auth/register
POST   /auth/login                 → access token + refresh cookie
POST   /auth/refresh               → rotates refresh token (reuse ⇒ revoke family)
POST   /auth/logout
GET    /auth/me
```

**Organizations**
```
GET    /organizations
POST   /organizations
GET    /organizations/{id}/members
POST   /organizations/{id}/members
PATCH  /organizations/{id}/members/{user_id}
DELETE /organizations/{id}/members/{user_id}
```

**Node Catalog** — drives the editor's palette and config forms
```
GET    /nodes                      → [{type, version, category, display_name,
                                        icon, config_schema, input_ports,
                                        output_ports, credential_type}]
GET    /nodes/{type}/{version}
```
This is the API that makes the plugin system real: **the frontend has zero hardcoded knowledge of node types.** Adding a node to the backend makes it appear in the UI with a working config form, no frontend deploy.

**Workflows**
```
GET    /workflows?cursor=&limit=&q=
POST   /workflows
GET    /workflows/{id}             → includes current version
PATCH  /workflows/{id}             → metadata only
DELETE /workflows/{id}
POST   /workflows/{id}/versions    → save definition; returns new version
GET    /workflows/{id}/versions
GET    /workflows/{id}/versions/{v}
POST   /workflows/{id}/activate
POST   /workflows/{id}/deactivate
POST   /workflows/{id}/validate    → dry validation, no persistence
```

**Runs**
```
POST   /workflows/{id}/runs        → manual trigger; 202 + run
GET    /runs?workflow_id=&status=&cursor=
GET    /runs/{id}
GET    /runs/{id}/node-executions
GET    /runs/{id}/node-executions/{ne_id}/payload?side=input|output
POST   /runs/{id}/cancel
POST   /runs/{id}/retry            → new run seeded from failure point
GET    /runs/{id}/events           → SSE live stream
```

**Credentials**
```
GET    /credentials                → metadata only, never secret values
POST   /credentials
PATCH  /credentials/{id}
DELETE /credentials/{id}
POST   /credentials/{id}/test
```

**Webhook Ingress** — deliberately *not* under `/api/v1`
```
ANY    /hooks/{webhook_path}       → 202 Accepted
```

Separate router, separate rate limiter, no auth dependency, minimal middleware. Ideally its own deployment later. Reason: this is your only unauthenticated public surface; keep its blast radius small and its latency independent of the authenticated API.

### 5.3 Real-time strategy

**SSE, not WebSockets.** Run progress is server→client only. SSE works through every proxy, reconnects natively with `Last-Event-ID`, needs no separate protocol handling, and does not require sticky sessions. WebSockets buy bidirectionality you do not need until collaborative editing. Fan-out across API replicas uses Postgres `LISTEN/NOTIFY` for MVP; swap to Redis pub/sub when replica count makes connection-per-replica costly.

---

## 6. Workflow Execution Engine

### 6.1 Core model

The engine is a **pure function over persisted state**:

```
step(run_state, definition, node_results) → (new_run_state, commands)
```

`commands` are declarative effects (`ExecuteNode`, `ScheduleTimer`, `CompleteRun`, `EnqueueRun`) handled by the infrastructure layer. The engine itself performs no I/O. This makes the entire execution semantics testable without a database and is what allows the same engine to run on a different queue or persistence layer.

### 6.2 Run state machine

```
                ┌──────────┐
     trigger →  │  QUEUED  │
                └────┬─────┘
                     │ worker claims
                ┌────▼─────┐  cancel  ┌───────────┐
           ┌───►│ RUNNING  ├─────────►│ CANCELLED │
           │    └──┬───┬───┘          └───────────┘
   timer / │       │   │
   event   │       │   └──── all terminal ──► ┌───────────┐
           │       │                          │ SUCCEEDED │
      ┌────┴─────┐ │                          └───────────┘
      │SUSPENDED │◄┘ Suspend(resume_at)
      └──────────┘ │
                   └──── unrecoverable ─────► ┌───────────┐
                                              │  FAILED   │
                                              └───────────┘
```

Node execution states: `pending → running → {succeeded | failed | suspended | skipped | cancelled}`.

### 6.3 The worker loop

```
loop:
  batch = queue.claim(worker_id, size=N, lease=60s)
  for run_id in batch (concurrently, bounded by semaphore):
     while true:
        state = load_run_state(run_id)          # SELECT ... FOR UPDATE
        if state.step_count > MAX_STEPS: fail("step limit exceeded")
        ready = engine.next_ready_nodes(state, definition)
        if not ready: finalise_run(); break
        results = await execute_all(ready)       # parallel within a level
        new_state, commands = engine.step(state, results)
        persist(new_state, node_executions, commands)   # single transaction
        if any command is ScheduleTimer or WaitForEvent:
           mark SUSPENDED; release lease; break
        renew_lease_if_needed()
  if batch empty: wait on LISTEN or sleep(poll_interval)
```

Three properties worth naming:

1. **Lease-based, not lock-based.** A worker holding a run past its lease loses it to the scheduler's reclaim job. No run is ever permanently stuck behind a dead worker.
2. **Level-parallel execution.** All currently-ready nodes execute concurrently, not sequentially. Independent branches after a fan-out run in parallel for free.
3. **Transactional commit.** State, node execution rows, and queue operations commit together. A crash between them is impossible.

### 6.4 Node dispatch

```
resolve config → evaluate expressions against run context
              → resolve credential (decrypt in memory)
              → build NodeContext
              → apply timeout wrapper
              → await node.execute(ctx)
              → validate output against schema
              → persist output (inline or offloaded)
              → route to outgoing edges
```

### 6.5 Data flow model

Each node produces **one output payload per output port**. Downstream nodes reference upstream outputs by expression:

```
{{ $node["Fetch User"].output.body.email }}
{{ $trigger.body.customer_id }}
{{ $run.id }}
```

**I recommend against n8n's implicit item-array model** (where an output array causes automatic per-item re-execution downstream). It is powerful but it is the single largest source of user confusion in that product — people cannot predict when a node runs once versus N times. Instead: one payload per port, and when you need iteration, add an **explicit `Loop`/`Split Items` node** post-MVP. Explicit beats magic; you can always add magic later, you cannot remove it.

### 6.6 Branching semantics (If/Else)

`If/Else` has two output ports (`true`, `false`). The engine takes exactly one. Critically, the **untaken branch must be pruned**, not left pending, or downstream join nodes wait forever.

Pruning rule: after taking branch B, walk the untaken branch and mark each node `skipped` **unless it is also reachable from a taken path**. Nodes with all inbound edges pruned are pruned; nodes with at least one live inbound edge remain live. This is the correct join semantics and it is subtle enough to deserve a dedicated test suite from day one.

### 6.7 Suspension

```python
NodeResult.Suspend(
    kind="timer" | "event",
    resume_at=datetime | None,
    resume_token=str | None,
)
```

- **Timer:** row in `timers`; scheduler scans `fire_at <= now()` and re-enqueues.
- **Event:** run parked with a token; an inbound webhook matching the token re-enqueues.

Only `Delay` uses this in the MVP — but building the primitive now means Wait-For-Approval, Wait-For-Webhook, and Wait-For-Sub-Workflow are later node additions rather than engine changes. That is the difference between a platform and a program.

### 6.8 Concurrency & fairness

Naive FIFO lets one organization queueing 10,000 runs starve everyone else. Mitigations, in order of implementation:

1. Per-org concurrency cap (`organizations.max_concurrent_runs`) checked at claim time.
2. Weighted fair claim: partition the claim query by `organization_id` so no single org takes more than K slots per batch.
3. Priority lanes: interactive (manual trigger) > webhook > backfill.

### 6.9 Cancellation

Cancellation sets run status and is checked at node boundaries — the engine does not kill in-flight node work mid-flight (you cannot un-send an email). A cooperative `ctx.cancelled` flag lets long-running nodes (LLM streaming) abort early.

---

## 7. Plugin Architecture

### 7.1 The contract

A node type is a class implementing one interface. This is the entire public surface a node author touches.

```python
class NodeDefinition(Protocol):
    type: str                       # "http_request"
    version: int                    # 1
    category: NodeCategory          # TRIGGER | ACTION | LOGIC | TRANSFORM
    display_name: str
    description: str
    icon: str
    config_schema: type[BaseModel]  # Pydantic → JSON Schema → UI form
    output_schema: type[BaseModel] | None
    input_ports: list[Port]
    output_ports: list[Port]        # If/Else declares two
    credential_type: str | None
    default_retry_policy: RetryPolicy
    default_timeout_s: float

    async def execute(self, ctx: NodeContext) -> NodeResult: ...
    async def validate_config(self, config, ctx: ValidationContext) -> None: ...
```

`NodeContext` is the node's **only** access to the outside world:

```python
class NodeContext:
    config: BaseModel               # validated, expressions already resolved
    input: dict                     # resolved input payload
    run: RunInfo                    # id, workflow_id, org_id — read-only
    node: NodeInfo
    idempotency_key: str
    credential: Credential | None   # decrypted, in-memory only
    http: GuardedHttpClient         # egress-policy enforced
    llm: LLMClient
    logger: BoundLogger             # pre-bound with correlation ids
    cancelled: bool
    deadline: datetime
```

**Nodes get no database session, no queue handle, no filesystem, no raw socket.** This is what makes the plugin boundary real rather than aspirational: a badly written node cannot corrupt run state, cannot leak across tenants, cannot SSRF, and cannot exhaust connections, because it has no access to the objects that would let it.

### 7.2 Node results

```python
NodeResult =
  | Success(outputs: dict[PortName, Payload])
  | Suspend(kind, resume_at?, resume_token?)
  | Failure(error: NodeError, retryable: bool)
```

A node returns `Failure`; it does not decide retry timing or run outcome. **Routing and retry are the engine's job, never the node's.** This is the rule that satisfies "add nodes without modifying the execution engine" — the engine's logic depends only on the result variant, never on the node type.

### 7.3 Registration & discovery

```toml
# packages/nodes-core/pyproject.toml
[project.entry-points."workflow.nodes"]
core = "nodes_core:register"
```

```python
def register(registry: NodeRegistry) -> None:
    registry.add(HttpRequestNodeV1)
    registry.add(AiPromptNodeV1)
    ...
```

At process start:
1. Enumerate `workflow.nodes` entry points.
2. Call each `register`.
3. Validate: unique `(type, version)`, schema well-formedness, port declarations.
4. Freeze the registry; compute a registry hash.
5. Log the hash. **API and worker replicas with mismatched hashes fail readiness** — this catches partial deploys where the UI offers a node the workers cannot execute.

### 7.4 Frontend integration

The editor renders node config forms from `config_schema` returned by `GET /nodes`. JSON Schema → form via a renderer with widget hints (`x-ui: {widget: "code", language: "json"}`). Only genuinely bespoke nodes register a custom React component, keyed by node type in a lazy-loaded map.

**Consequence:** adding a node requires a backend package change and no frontend change. That is the test of whether the plugin system actually works.

### 7.5 Extension points beyond nodes

Design these as the same shape now, implement later: `workflow.credentials` (credential types), `workflow.triggers` (trigger sources — cron, polling), `workflow.storage` / `workflow.queue` (backend swaps).

### 7.6 The trust boundary (future work, decided now)

MVP plugins are **first-party and trusted** — same process, full Python. Untrusted plugins require process isolation, and the honest options are: a subprocess with seccomp/rlimits (weak), a container per execution (slow, ~200ms+ cold start), gVisor/Firecracker (good, complex), or WASM via Wasmtime/Extism (best isolation, restricted language support).

**Recommendation when you get there:** WASM for user code nodes, containers for arbitrary-language nodes. The `NodeContext` interface above was designed to be marshalable across a process boundary precisely so this migration does not require rewriting nodes. Do not let anyone ship a "run Python code" node in the MVP process.

---

## 8. Node Lifecycle

### 8.1 Design time
1. Author defines class, schema, ports.
2. Registered via entry point.
3. Exposed at `GET /nodes`.
4. Rendered in the palette; config form generated from schema.
5. `validate_config` runs on workflow save (catches bad URLs, missing credentials, invalid JSONPath *before* runtime).

### 8.2 Runtime

```
 SCHEDULED   engine marks node ready (all inbound satisfied)
     ↓
 RESOLVING   expressions evaluated; credential decrypted; context built
     ↓       (failure here → ConfigurationError, non-retryable)
 EXECUTING   execute() under timeout + cancellation
     ↓
 VALIDATING  output checked against output_schema
     ↓
 PERSISTING  payload stored (inline or offloaded); node_execution committed
     ↓
 ROUTING     engine maps outputs → outgoing edges; downstream marked ready
     ↓
 TERMINAL    succeeded | failed | suspended | skipped | cancelled
```

Retry re-enters at RESOLVING with `attempt + 1` and a **new row** in `node_executions` — attempts are never overwritten, so the run detail view shows the full attempt history including what each failure said.

### 8.3 Suspension path

`EXECUTING → Suspend → node_execution status = suspended`, run suspended, lease released. On resume the engine re-enters at ROUTING (the node's work is done — a delay does not re-execute).

---

## 9. Error Handling Strategy

### 9.1 Taxonomy

Every error is classified, and classification determines behaviour. This is the whole strategy — everything else is mechanics.

| Class | Retryable | Examples | Behaviour |
|---|---|---|---|
| `ValidationError` | No | Bad config, schema mismatch | Fail node immediately, 422 at save time where possible |
| `ConfigurationError` | No | Missing credential, unresolvable expression | Fail node, clear user-facing message |
| `TransientError` | Yes | 429, 502/503, connection reset, timeout | Backoff + retry |
| `PermanentError` | No | 400, 401, 403, 404 from a well-formed request | Fail node |
| `TimeoutError` | Conditional | Node deadline exceeded | Retry if node is idempotent |
| `ResourceLimitError` | No | Payload too large, step limit, token budget | Fail run |
| `CancellationError` | No | User cancelled | Terminal, not an error state |
| `InternalError` | Yes | Engine bug, DB blip | Retry; alert |

Node authors raise typed errors; unclassified exceptions default to `InternalError` and are logged with full traceback but a **redacted, generic user-facing message** (never leak stack traces to tenants).

### 9.2 Retry policy

Per-node defaults, per-instance override:

```
max_attempts: 3
initial_delay: 1s
multiplier: 2.0
max_delay: 60s
jitter: full          # not optional — synchronised retries cause thundering herds
retry_on: [TransientError, TimeoutError, InternalError]
```

Retries with delay > ~5s use the suspension mechanism rather than in-process sleep, for the same reason `Delay` does.

### 9.3 Failure handling policy per node

User-configurable, defaulting to `stop`:

- **`stop`** — run fails (default)
- **`continue`** — node output becomes an error object; downstream proceeds (for "best effort" enrichment steps)
- **`error_output`** — node exposes a second output port taken on failure; enables explicit compensation/notification branches

`error_output` is the one that makes the product feel professional. Recommend including it in the MVP.

### 9.4 Circuit breaking

Per (organization, host) breaker on outbound HTTP. After N consecutive failures, fast-fail for a cooldown. Protects both your workers and the customer's endpoint from a workflow that retries a dead host 10,000 times.

### 9.5 Poison runs

A run that repeatedly fails to *start* (as opposed to failing during execution) — e.g. a corrupted state row — gets moved to a dead-letter status after `queue.attempts > 5` with an alert, rather than looping forever.

### 9.6 API error contract

RFC 7807 everywhere, with stable machine-readable `type` URIs so the frontend can react to specific errors rather than parsing strings.

---

## 10. Logging & Observability

### 10.1 Two distinct streams — do not conflate them

| | Application logs | Execution logs |
|---|---|---|
| Audience | Operators | End users |
| Content | Engine internals, DB, infra | Node inputs/outputs, node errors |
| Store | stdout → aggregator (Loki/CloudWatch) | Postgres + object storage |
| Retention | 14–30 days | Per-org policy, 30 days default |
| Access | Internal only | Tenant-scoped API |

Serving user-facing run history out of your log aggregator is a mistake that becomes very expensive at volume and makes tenant isolation a query-filter problem instead of a schema problem.

### 10.2 Structured logging

JSON via `structlog`. Every line carries: `timestamp, level, event, service, version, request_id, organization_id, user_id, workflow_id, run_id, node_id, node_execution_id, attempt, duration_ms`. Correlation IDs are bound once via context vars and inherited automatically — never passed manually.

### 10.3 Redaction

A redaction processor sits in the logging pipeline and is not bypassable:
- Known-secret keys (`password`, `token`, `api_key`, `authorization`, `secret`) → `***`
- Credential values registered in a per-run redaction set at decrypt time, matched against all outbound log strings
- `Authorization` headers stripped from HTTP node logs
- AI prompts/completions logged at `DEBUG` only, off by default (they contain customer PII and are expensive to store)

### 10.4 Metrics (Prometheus)

```
runs_started_total{org, workflow, trigger_type}
runs_completed_total{org, status}
run_duration_seconds (histogram)
node_executions_total{node_type, status}
node_duration_seconds{node_type} (histogram)
node_retries_total{node_type, error_class}
queue_depth{status}
queue_claim_latency_seconds
queue_oldest_available_age_seconds     ← primary saturation alarm
worker_active_runs{worker_id}
suspended_runs_total
llm_tokens_total{org, provider, model}
llm_cost_usd_total{org, provider}
http_egress_blocked_total{reason}      ← security signal
```

`queue_oldest_available_age_seconds` is the metric that tells you the platform is falling behind before users do. Alert on it.

### 10.5 Tracing

OpenTelemetry. One trace per run: span per node execution, child spans for HTTP/LLM/DB. Trace context propagates from the triggering HTTP request through the queue via a `traceparent` stored on the run — otherwise the queue hop severs your trace and you lose end-to-end visibility exactly where you need it.

### 10.6 Cost accounting

The AI node makes cost a first-class concern from day one. Record tokens and computed cost per node execution, aggregate per org and per workflow, and enforce a configurable per-org monthly budget. Retrofitting cost attribution after customers have bills is unpleasant.

---

## 11. Security Considerations

### 11.1 Threat model summary

Primary adversaries: (a) a malicious tenant using workflow nodes as a weapon against your infrastructure or other tenants, (b) an external attacker via the unauthenticated webhook surface, (c) an attacker who has obtained a DB dump.

### 11.2 SSRF — highest severity

The `HTTP Request` node is user-controlled server-side request forgery *by design*. Required controls:

1. Resolve DNS first; validate **every** resolved IP.
2. Deny: loopback, RFC1918, link-local (`169.254.0.0/16` — cloud metadata), CGNAT, IPv6 ULA/link-local, `::1`, and configured internal CIDRs.
3. Re-validate after **every** redirect (defeats DNS rebinding); cap redirects at 5.
4. Scheme allowlist: `http`, `https` only.
5. Response size cap (streamed, aborted on exceed) and connect/read timeouts.
6. Deny requests to the platform's own API and DB hosts explicitly.
7. Optional per-org egress allowlist for enterprise.

Best practice beyond this: run workers in a network namespace with **no route to internal services**, forcing all egress through a controlled proxy. Then the guard is defence-in-depth rather than the only defence.

### 11.3 Secrets

- Argon2id for user passwords.
- Envelope encryption (AES-256-GCM) for credentials; KEK from env in dev, KMS/Vault in prod; `key_version` for rotation.
- Decrypted only in worker memory, for the duration of one node execution; registered in the run's redaction set.
- Secrets never in `workflow_versions.definition`, never in payloads, never in API responses (write-only fields), never in logs.
- API keys and refresh tokens stored hashed; displayed once at creation.

### 11.4 Expression evaluation

No `eval`, no `exec`, no Jinja2 with object access, no `__builtins__`. Restricted grammar, whitelisted functions, no attribute traversal into Python objects, output size cap, evaluation timeout, recursion depth limit. Treat the expression evaluator as security-critical code: dedicated fuzzing, dedicated review.

### 11.5 Webhook ingress

- Unguessable path (≥128 bits entropy), rotatable.
- Optional HMAC signature verification with timestamp window (replay protection).
- Aggressive rate limiting per path and per source IP.
- Hard body size cap, enforced before parse.
- Fast ack (`202`) — never execute inline.
- Idempotency via `webhook_events` unique constraint.
- Payload stored as opaque bytes; never interpolated into anything executable.

### 11.6 AI node specifics

- **Prompt injection is unsolved.** Data flowing from an `HTTP Request` into an `AI Prompt` may contain instructions. Mitigations: clear system/user separation, structured output schemas rather than free-form instruction-following, and — most importantly — **never let an LLM output determine a control-flow or credential decision without a deterministic node in between.** Document this for users; it is a shared-responsibility issue.
- Per-org token budgets and rate limits (cost DoS is a real attack).
- Per-node timeout and max output tokens.
- Provider keys are platform-level or org-level credentials, never in prompts.

### 11.7 Tenant isolation

- `organization_id` on every tenant table.
- Repository layer takes a tenant context; no repository method can be called without one (enforce by constructor, not convention).
- Postgres RLS as defence-in-depth so a missing filter fails closed.
- Integration tests that assert cross-tenant access returns 404 (not 403 — do not leak existence).
- Object storage keys prefixed by `org_id`; presigned URLs short-lived and scoped.

### 11.8 Authentication & session

- Access JWT 10–15 min, `RS256` (asymmetric — workers verify without the signing key), `kid` header for rotation.
- Refresh token rotating, DB-persisted, revocable, reuse-detection revokes the whole family.
- `httpOnly` `Secure` `SameSite=Lax` cookie for refresh; access token in memory only, **never `localStorage`**.
- CSRF: double-submit token on cookie-authenticated mutations.
- Rate limit login/register/refresh; account lockout with backoff.

### 11.9 RBAC

Enforced in the application layer, never in the frontend. Matrix:

| Action | owner | admin | editor | viewer |
|---|:--:|:--:|:--:|:--:|
| View workflows/runs | ✓ | ✓ | ✓ | ✓ |
| Create/edit workflows | ✓ | ✓ | ✓ | |
| Activate workflow | ✓ | ✓ | ✓ | |
| Trigger run manually | ✓ | ✓ | ✓ | |
| Cancel run | ✓ | ✓ | ✓ | |
| Manage credentials | ✓ | ✓ | | |
| Manage members | ✓ | ✓ | | |
| Delete organization | ✓ | | | |

### 11.10 Platform hardening

- Containers: non-root, read-only root filesystem, dropped capabilities, resource limits.
- Dependency scanning (`pip-audit`, `npm audit`) and image scanning (Trivy) in CI; build fails on high severity.
- Security headers on the frontend: strict CSP, HSTS, `X-Content-Type-Options`, `Referrer-Policy`.
- Audit log for every privileged action, append-only, retained ≥ 1 year.
- Rate limiting per org and per IP at the edge.
- No stack traces or internal identifiers in API error responses.

---

## 12. Delivery Plan

Suggested module order, each independently testable and reviewable:

| # | Module | Delivers |
|---|---|---|
| 1 | Foundation | Repo, Docker Compose, config, migrations, CI, logging skeleton |
| 2 | Identity | Users, orgs, memberships, JWT, refresh rotation, RBAC deps |
| 3 | Node contract + registry | `NodeDefinition`, `NodeContext`, entry-point discovery, `GET /nodes` |
| 4 | Workflow domain | Graph model, validation, versions, CRUD API |
| 5 | Expression engine | Parser, restricted evaluator, fuzz tests |
| 6 | Execution engine (core) | State machine, `step()`, routing, pruning — **pure, no I/O, fully unit-tested** |
| 7 | Persistence + queue | Repositories, Postgres queue, leases, worker entrypoint |
| 8 | Core nodes I | Manual Trigger, Webhook Trigger, JSON Transform, If/Else |
| 9 | Suspension + scheduler | Timers, Delay node, lease reclaim, GC |
| 10 | Core nodes II | HTTP Request (+ egress guard), Email, AI Prompt |
| 11 | Credentials | Envelope encryption, credential API, node integration |
| 12 | Frontend editor | React Flow canvas, schema-driven forms, save/validate |
| 13 | Run observability | Run list/detail, SSE stream, payload inspector |
| 14 | Hardening | Rate limits, RLS, load test, security review, retention jobs |

Module 6 before module 7 is deliberate: writing the engine as a pure state machine with in-memory fakes, *before* any database exists, is what forces the abstraction to be honest. If the engine is written against SQLAlchemy first, it will never be cleanly separable afterward.

---

## 13. Open Questions for Approval

1. **Drop `End` node?** (recommend yes) — and if so, add `Set / Edit Fields`?
2. **Item-array fan-out vs. single payload + explicit Loop?** (recommend the latter)
3. **Postgres queue vs. Redis/Celery for MVP?** (recommend Postgres, abstracted)
4. **`error_output` port in MVP?** (recommend yes)
5. **Object storage in MVP or `PayloadRef` interface with inline-only implementation?** (recommend the interface now, MinIO in compose, S3 driver at hardening)
6. **Expression syntax:** `{{ }}` with JMESPath-style paths, or a different surface? Locking this early matters most.
7. **Self-hosted single-tenant deployments** — is that a near-term requirement? It changes credential key management significantly.
8. **AI provider scope:** one provider behind an adapter, or multi-provider from day one?
