# Conduit

An AI-powered workflow automation platform. Users compose workflows from
typed nodes on a canvas; the engine executes them durably, survives restarts,
and can pause for days without occupying a worker.

**Status:** Modules 1–3 of 14, plus an early workflow canvas.

The canvas was pulled forward ahead of the execution engine so progress is
visible while the engine is built. You can compose a workflow today; running
one arrives with Modules 6–10.

---

## Quick start

```bash
cp .env.example .env
make up
```

- API — http://localhost:8000/docs
- Web — http://localhost:3000
- Editor — http://localhost:3000/editor
- MinIO console — http://localhost:9001

Local development without Docker:

```bash
make install
make migrate
make test
```

Tests that need PostgreSQL skip themselves when none is reachable, so
`pytest` gives useful signal on a machine with no database installed. The
security-critical logic — the permission matrix, refresh-token rotation,
token handling — lives in the pure domain and is covered either way.

---

## Repository layout

```
apps/
  api/       FastAPI service, execution engine, workers
  web/       Next.js frontend
packages/
  nodes-core/  First-party node pack (plugin, installed separately)
  contracts/   Shared schemas
docker/      Container definitions
docs/        Architecture spec and decision records
```

## Processes

Four processes, two images. `api`, `worker`, and `scheduler` share one image
with different entrypoints.

| Process | Role | Scaling |
|---|---|---|
| `api` | HTTP surface, validation, webhook ingress | Horizontal, stateless |
| `worker` | Executes workflow runs | Horizontal, stateless |
| `scheduler` | Timers, lease reclaim, retention | Singleton via advisory lock |
| `web` | Next.js UI | Horizontal, stateless |

The API and workers are separate processes because they have opposite
resource profiles and opposite failure tolerances. A stuck LLM call must
never degrade webhook ingress latency, and worker deploys must not drop HTTP
connections.

---

## Architecture in one page

Dependencies point inward only:

```
entrypoints  →  interface  →  application  →  domain
                                  ↑
                          infrastructure (implements domain ports)
```

The **domain layer contains the execution engine and imports no framework**.
It defines ports — `RunRepository`, `JobQueue`, `PayloadStore`, `Clock` —
which infrastructure implements. That is what makes the engine testable in
milliseconds against in-memory fakes, and what allows the Postgres queue to
be swapped for Temporal later without touching execution logic.

This is enforced, not documented: `make lint` runs import contracts that fail
the build if the domain imports SQLAlchemy or a node package reaches into
infrastructure.

### Load-bearing decisions

| Decision | Why |
|---|---|
| Durable step-level state machine | Resumability, long delays, partial retry, crash recovery |
| `Suspend` as a first-class node result | A 3-day delay must not occupy a worker |
| Immutable workflow versions | A run pins its definition; editing mid-run cannot corrupt it |
| `PayloadRef` indirection | Storing every payload inline in Postgres is the first scaling wall |
| Entry-point plugin discovery | Reproducible deploys; nothing executes because it landed on disk |
| One payload per port | Users can predict how many times a node runs |
| Egress guard on all node HTTP | An HTTP node is user-controlled SSRF by design |
| UUIDv7 identifiers | Time-ordered inserts; v4 fragments high-volume indexes |
| Multi-tenancy from migration 0001 | Retrofitting tenancy has a data-leak failure mode |
| Permission matrix in the domain | Scattered role checks drift; one table can be read and tested |
| Refresh rotation with reuse detection | A replayed token means theft, so the family is revoked |
| Refresh token in an httpOnly cookie | Removes XSS-based session theft entirely |

Full reasoning: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).
Locked decisions: [`docs/adr/`](docs/adr/).

---

## Adding a node

The measure of the plugin system is that this list contains no engine changes
and no frontend changes:

1. Add a class implementing `NodeDefinition` to `packages/nodes-core`.
2. Register it in that package's `register()` function.
3. Restart.

Node config forms are generated from each node's Pydantic schema, served at
`GET /nodes`. The frontend holds no hardcoded knowledge of node types.

Nodes receive a `NodeContext` and nothing else — no database session, no
queue handle, no filesystem, no raw sockets. A badly written node cannot
corrupt run state, leak across tenants, or exhaust the connection pool,
because it never holds the objects that would let it.

---

## Development

```bash
make help      # list targets
make check     # everything CI runs
make lint      # ruff, mypy, architecture contracts
make test      # pytest
make migration m="add widgets"
```

### Conventions

- Async end to end. A sync call inside `async def` blocks the event loop;
  unavoidable sync libraries go through `run_in_threadpool` explicitly.
- Correlation IDs are bound at the edge and inherited, never passed by hand.
- Secrets never enter workflow definitions, run payloads, or logs. The
  redaction processor masks both known-sensitive keys and registered secret
  values wherever they appear.
- Every model module must be imported in `models/__init__.py`, or Alembic
  autogenerate silently cannot see it.

---

## Security

Reviewed in full in `docs/ARCHITECTURE.md` §11. The three highest-severity
areas:

1. **SSRF** — the HTTP Request node is user-controlled server-side request
   forgery by design. DNS is resolved and every IP validated before connect,
   re-validated after each redirect to defeat rebinding.
2. **Expression evaluation** — no `eval`, no Jinja, no attribute access. The
   evaluator only ever touches plain JSON values, so there is no Python object
   graph to escape through.
3. **Credentials** — envelope encrypted, decrypted only in worker memory for
   the duration of one node execution, never written anywhere.

Authentication specifics:

- Argon2id password hashing, with an equal-cost dummy verification on the
  "no such user" branch so response timing does not enumerate accounts.
- Access tokens are short-lived and stateless; revocation lives on the
  persisted refresh token. Presenting an already-rotated refresh token is
  treated as theft and revokes the whole token family.
- The refresh token is delivered as an httpOnly, SameSite=Lax cookie and is
  never returned in a response body. The access token is held in memory by
  the client — never in localStorage, which any injected script can read.
- The JWT verifier pins its algorithm. Trusting the token's own header is the
  classic confusion attack.

`Settings.assert_production_ready()` refuses to boot production with a
development key or a disabled egress guard.
